# BUILD_PLAN.md — Fretbox Campus OS Spec Implementation Plan

**Date:** October 2026  
**Auditor & Lead Engineer:** Senior Full-Stack Engineer  
**Objective:** Phase 0 Technical Spec Audit, Status Classification, and Build Blueprint.

---

## 1. Feature Status & Action Checklist

| Module | Dashboard / Feature | Status | Evidence (File Path) | Action |
| :--- | :--- | :---: | :--- | :---: |
| **A. Examination Section** | Examination Staff Dashboard | ✅ Built & verified | `app/examination/routes.py:dashboard` | **Built [x]** |
| | Regular Paper Registration Payments & Filters (Sem-wise, Time-wise) | ✅ Built & verified | `templates/examination/dashboard.html` | **Built [x]** |
| | Back Paper Registration Payments & Filters (Paper-wise, Sem-wise, Time-wise) | ✅ Built & verified | `templates/examination/dashboard.html` | **Built [x]** |
| | Rechecking Payments & Filters (Sem-wise, Paper-wise, Time-wise) | ✅ Built & verified | `templates/examination/dashboard.html` | **Built [x]** |
| | Download Filtered Data as Excel / CSV | ✅ Built & verified | `app/examination/routes.py:export_csv` | **Built [x]** |
| | Digitally Signed Cryptographic Receipt Generation & Dispatch | ✅ Built & verified | `app/services/receipt_service.py` | **Built [x]** |
| | Public Receipt Verification Endpoint (`/verify/receipt/<token>`) | ✅ Built & verified | `app/__init__.py:verify_receipt_alias` | **Built [x]** |
| | Student-side counterpart: Pay Exam Registration & Rechecking, View Receipts | ✅ Built & verified | `app/examination/routes.py:student_exams` | **Built [x]** |
| **B. Account Section** | Account Staff Dashboard | ✅ Built & verified | `app/account_section/routes.py:dashboard` | **Built [x]** |
| | Course Fee Segmentation (Semester-wise, Branch-wise, Time-wise) | ✅ Built & verified | `templates/account_section/dashboard.html` | **Built [x]** |
| | Hostel Fee Segmentation (Room-wise, Time-wise) | ✅ Built & verified | `templates/account_section/dashboard.html` | **Built [x]** |
| | Bus Fee Segmentation for Day-Scholars (Year-wise, Location-wise, Time-wise) | ✅ Built & verified | `templates/account_section/dashboard.html` | **Built [x]** |
| | Download Filtered Fee Collections as Excel / CSV | ✅ Built & verified | `app/account_section/routes.py:export_csv` | **Built [x]** |
| | Digitally Signed Fee Receipt Generation (Shared Cryptographic Flow) | ✅ Built & verified | `app/services/receipt_service.py` | **Built [x]** |
| | Student-side counterpart: Pay Course/Hostel/Bus Fees & Download Receipts | ✅ Built & verified | `app/account_section/routes.py:student_fees` | **Built [x]** |
| **C. College Cafeteria** | Cafeteria Staff Dashboard | ✅ Built & verified | `app/cafeteria/routes.py:dashboard` | **Built [x]** |
| | Menu Items & Live Stock Quantity Management | ✅ Built & verified | `app/cafeteria/routes.py:toggle_availability` | **Built [x]** |
| | "Not Available" Block for Out-of-Stock Items | ✅ Built & verified | `templates/cafeteria/student_menu.html` | **Built [x]** |
| | Daily Opening Menu Auto-Publishing (Application Scheduler) | ✅ Built & verified | `app/cafeteria/routes.py:seed_cafeteria_menu` | **Built [x]** |
| | Incoming Orders Queue & Status Tracking (Preparing / Ready / Delivered) | ✅ Built & verified | `app/cafeteria/routes.py:update_order_status` | **Built [x]** |
| | Student Dashboard: View Today's Menu & "Not Available" Block | ✅ Built & verified | `templates/cafeteria/student_menu.html` | **Built [x]** |
| | Student Dashboard: Online Order Placement, Test Payment & Hostel Delivery Option | ✅ Built & verified | `app/cafeteria/routes.py:place_order` | **Built [x]** |
| **D. College Cyber Cafe** | Cyber Cafe Staff Dashboard | ✅ Built & verified | `app/cyber_cafe/routes.py:dashboard` | **Built [x]** |
| | Priority 1 Queue: Scholarship Online Submissions (Time-wise, Scholarship-wise) | ✅ Built & verified | `templates/cyber_cafe/dashboard.html` | **Built [x]** |
| | Priority 2 Queue: Scholarship Offline Slot Bookings (Max 20/day configurable) | ✅ Built & verified | `app/cyber_cafe/routes.py:book_slot` | **Built [x]** |
| | Live Call Support / Re-schedule Slot Workflow for OTP Details | ✅ Built & verified | `app/cyber_cafe/routes.py:reschedule_slot` | **Built [x]** |
| | Printing / Xerox Online Requests Queue (Student Priority Ordering) | ✅ Built & verified | `templates/cyber_cafe/dashboard.html` | **Built [x]** |
| | Staff Scholarship Catalog Manager (Add/Edit deadlines, criteria, docs) | ✅ Built & verified | `templates/cyber_cafe/dashboard.html` | **Built [x]** |
| | Student Dashboard: Browse Scholarships, Online Document Submit & Pay Service Fee | ✅ Built & verified | `templates/cyber_cafe/student_portal.html` | **Built [x]** |
| | Student Dashboard: Book Offline Schedule Slot (Max 20/day) | ✅ Built & verified | `templates/cyber_cafe/student_portal.html` | **Built [x]** |
| | Student & Teacher Dashboard: Online Document Upload for Printing/Xerox | ✅ Built & verified | `app/cyber_cafe/routes.py:submit_print_xerox` | **Built [x]** |
| | Delivery of Printed Material (In-person collection vs Hostel delivery if enabled) | ✅ Built & verified | `templates/cyber_cafe/student_portal.html` | **Built [x]** |
| **E. Library** | Librarian Dashboard | ✅ Built & verified | `app/library/routes.py:dashboard` | **Built [x]** |
| | Book Catalog & Inventory Stock Management (Total & Available copies) | ✅ Built & verified | `templates/library/dashboard.html` | **Built [x]** |
| | Two Separate Queues: Student Book Requests & Teacher Book Requests | ✅ Built & verified | `templates/library/dashboard.html` | **Built [x]** |
| | Stock Check & Confirm Request Workflow with Automatic Notification | ✅ Built & verified | `app/library/routes.py:issue_book` | **Built [x]** |
| | Student & Teacher Dashboard: Browse Listed Books & Send Book Requests | ✅ Built & verified | `app/library/routes.py:catalog` | **Built [x]** |
| **F. Events & Sports** | Event Coordinator Dashboard (Post upcoming events, deadlines, summary, winners) | ✅ Built & verified | `app/events/routes.py:dashboard` | **Built [x]** |
| | Sports Coordinator Dashboard (Update live scores for Annual Sports) | ✅ Built & verified | `templates/events/dashboard.html` | **Built [x]** |
| | Student Dashboard: Browse Events, Apply before deadline, View Winners Summary | ✅ Built & verified | `templates/events/index.html` | **Built [x]** |
| | Annual Sports Live Scores: Cricket, Volleyball, Badminton, Basketball, Kabaddi | ✅ Built & verified | `app/events/routes.py:api_live_scores` | **Built [x]** |
| | Teacher Dashboard: View Events, Live Scores, Event Summary & Winners | ✅ Built & verified | `templates/events/index.html` | **Built [x]** |
| **G. Depression Index** | Mental Health Counselor Dashboard (Confidential Student Index Viewer & Outcomes) | ✅ Built & verified | `app/counselor/routes.py:dashboard` | **Built [x]** |
| | Transparent Rule-Based "Wellbeing Risk Index" Algorithm | ✅ Built & verified | `app/services/wellbeing_service.py` | **Built [x]** |
| | Contributing Factors Breakdown (Attendance, Assignment lapses, Isolation/Passes) | ✅ Built & verified | `templates/counselor/student_profile.html` | **Built [x]** |
| | Optional Consent-Based Student Self Check-in Screening | ✅ Built & verified | `app/counselor/routes.py:student_checkin` | **Built [x]** |
| | Strict Privacy & Security Isolation (Backend role-guard, Audit logging, High alert) | ✅ Built & verified | `app/counselor/routes.py:dashboard` | **Built [x]** |
| **H. Basic Dashboards** | Teacher: Daily College Class Attendance | ✅ Exists & works | `app/faculty/routes.py:L47-95` | **Skip** |
| | Teacher: Class Notices Broadcast | ✅ Exists & works | `app/faculty/routes.py:L138-174` | **Skip** |
| | Teacher: Review & Signoff Student Leaves | ✅ Exists & works | `app/faculty/routes.py:L97-136` | **Skip** |
| | Teacher: Assignment Submission List (Type of attendance) | ✅ Built & verified | `app/faculty/routes.py:view_assignment` | **Built [x]** |
| | Teacher: Create/Post Assignment with Deadline in Student Community & Score Submissions | ✅ Built & verified | `app/faculty/routes.py:grade_submission` | **Built [x]** |
| | Caretaker Dashboard: Daily Hostel Attendance Marking | ✅ Built & verified | `app/caretaker/routes.py:dashboard` | **Built [x]** |
| | Caretaker Dashboard: Log Health Emergency & Notify Superintendent | ✅ Built & verified | `app/caretaker/routes.py:log_emergency` | **Built [x]** |
| | Hostel Superintendent: Review of Every Room (Room number, members, complaints, passes) | ✅ Expanded & verified | `app/admin/routes.py:room_inspect` | **Built [x]** |
| | Hostel Superintendent: Gate Pass Review, Approve/Reject, Notify Student | ✅ Exists & works | `app/admin/routes.py:L235-345` | **Skip** |
| | Student: Raise Complaint & Request Gate Pass | ✅ Exists & works | `app/student/routes.py:L173-330` | **Skip** |
| **I. Communities in App** | Community Hub & Navigation (Student, Teacher, Hostel, Day Scholar, Admin, Special) | ✅ Built & verified | `app/communities/routes.py:index` | **Built [x]** |
| | Student Community: Semester-wise, Branch-wise, For-All | ✅ Built & verified | `templates/communities/index.html` | **Built [x]** |
| | Teacher Community: HOD-only, Semester-wise, Branch-wise, For-All | ✅ Built & verified | `templates/communities/index.html` | **Built [x]** |
| | Hostel Community: Year-wise (Semester-wise) for Hostellers | ✅ Built & verified | `templates/communities/index.html` | **Built [x]** |
| | Day Scholar Community: Location-wise | ✅ Built & verified | `templates/communities/index.html` | **Built [x]** |
| | Special Communities: NSS, Tech Club, Youth Club, Environment Club (Admin manage) | ✅ Built & verified | `templates/communities/index.html` | **Built [x]** |
| | Automatic Membership Assignment from Student/Staff Profile Data | ✅ Built & verified | `app/communities/routes.py:seed_default_communities` | **Built [x]** |
| | Role-Based Posting Rights (Teachers/Admin/HOD post; Students read & interact) | ✅ Built & verified | `app/communities/routes.py:create_post` | **Built [x]** |

---

## 2. Roles Breakdown

### Existing Roles (7 Roles in `fretbox.db`)
1. `student` (Student resident)
2. `faculty` (Teacher)
3. `warden` (Hostel Superintendent / Warden)
4. `mess_manager` (Mess catering manager)
5. `maintenance` (Maintenance technician)
6. `office_staff` (Registrar academic office)
7. `super_admin` / `admin` (Administration leadership)

### Missing Roles to be Added (8 Roles)
1. `hod` — Head of Department (Access to HOD-only Teacher Community & departmental overviews)
2. `account_staff` — Account Section staff (Course fee, hostel fee, bus fee, receipts)
3. `exam_staff` — Examination Section staff (Registration fees, back paper, rechecking)
4. `cafeteria_staff` — College Cafeteria staff (Menu inventory, stock, order management)
5. `cyber_cafe_staff` — College Cyber Cafe staff (Scholarships, printing queues, offline slots)
6. `librarian` — Library staff (Book catalog, student & teacher queues)
7. `event_coordinator` — Event Coordinator (Event creation, summaries, winners)
8. `sports_coordinator` — Sports Coordinator (Sports events live score management)
9. `counselor` — Mental Health Counselor (Confidential Depression Index & counseling notes)
10. `caretaker` — Hostel Caretaker (Daily night hostel attendance & health emergency escalation)

*Note: Existing `warden` fulfills Hostel Superintendent; existing `faculty` fulfills Teacher; existing `student` fulfills Student; existing `super_admin`/`admin` fulfills Administration. We will reuse them cleanly and add the 10 specific missing roles.*

---

## 3. Database Schema Extensions (New Tables to Add)

Following Golden Rule 5 & 6, **zero existing tables, columns, or rows will be altered or deleted.** Only new SQLAlchemy model classes will be added:

1. **Examination & Account Section Payments:**
   - `FeePayment`:
     - `id`: Integer (PK)
     - `receipt_number`: String(64), unique, indexed (e.g., `RCP-EXAM-2026-XXXX`, `RCP-ACCT-2026-XXXX`)
     - `student_id`: Integer, ForeignKey(`users.id`)
     - `module_type`: String(30) (`'examination'` or `'account'`)
     - `fee_category`: String(50) (`'regular_registration'`, `'back_paper_registration'`, `'rechecking'`, `'course_fee'`, `'hostel_fee'`, `'bus_fee'`)
     - `semester`: Integer
     - `branch`: String(50)
     - `paper_name`: String(120)
     - `paper_code`: String(30)
     - `room`: String(20)
     - `hostel`: String(50)
     - `bus_location`: String(100)
     - `amount`: Float
     - `payment_method`: String(30) (`'test_online'`, `'upi_test'`)
     - `transaction_reference`: String(64)
     - `status`: String(20) (`'paid'`, `'refunded'`)
     - `paid_at`: DateTime
     - `digital_signature`: String(128) (HMAC SHA-256 signature generated with server key)
     - `verification_code`: String(64), unique (used for public QR verification)
     - `confirmed_by_id`: Integer, ForeignKey(`users.id`), nullable

2. **College Cafeteria:**
   - `CafeteriaItem`:
     - `id`, `name`, `category` (`'beverages'`, `'meals'`, `'snacks'`, `'desserts'`), `price`, `stock_quantity`, `is_available`, `description`, `created_at`
   - `CafeteriaOrder`:
     - `id`, `order_number` (unique), `student_id`, `total_amount`, `order_status` (`'received'`, `'preparing'`, `'ready'`, `'out_for_delivery'`, `'delivered'`, `'cancelled'`), `delivery_type` (`'in_person'`, `'hostel_delivery'`), `delivery_hostel`, `delivery_room`, `payment_status` (`'paid_test'`), `created_at`
   - `CafeteriaOrderItem`:
     - `id`, `order_id` (FK), `item_id` (FK), `quantity`, `unit_price`, `subtotal`

3. **College Cyber Cafe:**
   - `ScholarshipItem`:
     - `id`, `name`, `description`, `eligibility_criteria`, `required_documents`, `deadline`, `service_fee`, `is_active`, `created_at`
   - `CyberCafeRequest`:
     - `id`, `tracking_number` (unique), `user_id` (FK to student or teacher), `service_type` (`'scholarship_online'`, `'scholarship_offline'`, `'printing_xerox'`), `scholarship_id` (FK, nullable), `offline_slot_date`, `offline_slot_time`, `print_document_path`, `print_copies`, `print_color`, `print_notes`, `service_fee`, `status` (`'submitted'`, `'in_progress'`, `'call_needed'`, `'rescheduled'`, `'completed'`, `'rejected'`), `delivery_type` (`'in_person'`, `'hostel_delivery'`), `delivery_hostel`, `delivery_room`, `staff_notes`, `created_at`

4. **Library:**
   - `LibraryBook`:
     - `id`, `title`, `author`, `isbn`, `category`, `total_copies`, `available_copies`, `shelf_location`, `created_at`
   - `LibraryBookRequest`:
     - `id`, `book_id` (FK), `user_id` (FK), `requester_type` (`'student'` or `'teacher'`), `status` (`'pending'`, `'confirmed'`, `'collected'`, `'declined'`), `confirmed_at`, `notes`, `created_at`

5. **Events & Sports Live Scoring:**
   - `CampusEvent`:
     - `id`, `title`, `event_type` (`'cultural'`, `'academic'`, `'sports'`, `'workshop'`), `description`, `venue`, `event_date`, `application_deadline`, `is_open`, `summary`, `winners_announcement`, `created_by` (FK), `created_at`
   - `EventApplication`:
     - `id`, `event_id` (FK), `user_id` (FK), `role_applied` (`'participant'`, `'volunteer'`), `status`, `applied_at`
   - `SportsLiveScore`:
     - `id`, `sport_name` (`'Cricket'`, `'Volleyball'`, `'Badminton'`, `'Basketball'`, `'Kabaddi'`), `match_title`, `team_a`, `team_b`, `score_a`, `score_b`, `match_status` (`'upcoming'`, `'live'`, `'completed'`), `highlights`, `updated_at`

6. **Depression Index & Counseling Notes:**
   - `StudentWellbeingIndex`:
     - `id`, `student_id` (FK, indexed, unique per student), `risk_score` (Integer 0-100), `risk_level` (`'Low'`, `'Moderate'`, `'High'`), `contributing_factors` (JSON text), `self_checkin_consent` (Boolean), `last_calculated_at`
   - `CounselorSessionNote`:
     - `id`, `student_id` (FK), `counselor_id` (FK), `session_date`, `outcome_status` (`'scheduled'`, `'in_progress'`, `'resolved'`, `'monitoring'`), `confidential_notes` (Encrypted/Confidential text), `created_at`

7. **Teacher Assignments & Caretaker:**
   - `Assignment`:
     - `id`, `community_id` (FK), `title`, `description`, `due_date`, `created_by` (FK), `created_at`
   - `AssignmentSubmission`:
     - `id`, `assignment_id` (FK), `student_id` (FK), `submission_text`, `submission_file`, `score`, `feedback`, `graded_at`, `submitted_at`
   - `HostelNightAttendance`:
     - `id`, `student_id` (FK), `hostel`, `room`, `date`, `status` (`'present'`, `'absent'`, `'on_leave'`), `marked_by` (FK), `created_at`
   - `CaretakerHealthEmergency`:
     - `id`, `student_id` (FK), `hostel`, `room`, `emergency_description`, `status` (`'raised'`, `'superintendent_alerted'`, `'hospital_escalated'`, `'resolved'`), `reported_by` (FK), `created_at`

8. **Communities in App:**
   - `Community`:
     - `id`, `name`, `code` (unique, e.g. `COMM-STU-CSE-3`), `community_type` (`'student'`, `'teacher'`, `'hostel'`, `'dayscholar'`, `'admin'`, `'special'`), `branch`, `semester`, `hostel`, `location`, `description`, `created_by` (FK), `created_at`
   - `CommunityMembership`:
     - `id`, `community_id` (FK), `user_id` (FK), `role_in_community` (`'member'`, `'moderator'`, `'admin'`), `is_auto_assigned` (Boolean), `joined_at`
   - `CommunityPost`:
     - `id`, `community_id` (FK), `author_id` (FK), `post_type` (`'announcement'`, `'assignment'`, `'general'`), `title`, `content`, `attachment_path`, `created_at`

---

## 4. Shared Services Blueprint

1. **Receipts & Digital Verification (Shared between Exam & Account):**
   - **Cryptographic Signature Engine:**
     Each receipt generates a SHA-256 HMAC signature using `SECRET_KEY`:
     $$\text{Signature} = \text{HMAC-SHA256}(\text{SECRET\_KEY}, \text{receipt\_number} + \text{student\_id} + \text{amount} + \text{timestamp})$$
   - A unique verification token links to `/verify/receipt/<token>`. Anyone scanning the receipt's QR code can verify its authenticity on the public university verification page.
   - *Legal Note*: Clearly labeled as a **Server-Verified Cryptographic Digital Digest**, not an Aadhaar/e-Mudhra hardware DSC.
   - **Printable / Downloadable Receipts:** Clean HTML print-optimized invoice view with automatic PDF print dialog (`window.print()`) and QR code embed.

2. **Excel / CSV Sheet Generator:**
   - Uses Python's native `csv` stream engine with UTF-8 BOM encoding for seamless Excel compatibility across Windows/macOS. No heavy dependencies introduced.

3. **Notifications (In-App + Alerts):**
   - Uses existing `Notification` model + `create_notification()` helper in [app/utils/security.py](file:///c:/Users/manda/Desktop/GAYU/app/utils/security.py).
   - Automatically dispatches in-app alerts whenever receipts are issued, book requests are confirmed, or counselor alerts are raised.

4. **Realtime & Live Scores Support:**
   - Clean, lightweight client-side short polling (every 5 seconds on the sports live score page) adhering to the existing polling pattern in `app.js` without requiring extra WebSocket broker infrastructure.

5. **Payment Mode:**
   - In accordance with Golden Rule 11, we will implement an explicit **TEST/MOCK PAYMENT GATEWAY** (Instant Test UPI / NetBanking / Debit Card confirmation dialog). No real banking API is invoked.

---

## 5. Proposed Depression Index Formula (Spec G)

### Overview
A transparent, non-stigmatizing **Wellbeing Risk Index** (Score: 0 to 100) combining four objective operational signals already available in the campus ecosystem:

$$\text{Total Score} = S_{\text{Academic}} + S_{\text{Lapses}} + S_{\text{Isolation}} + S_{\text{SelfCheckin}}$$

1. **$S_{\text{Academic}}$ — Academic Attendance Factor (Max 30 points):**
   - Attendance $\ge 75\%$: **0 pts**
   - Attendance $60\% - 74\%$: **15 pts**
   - Attendance $< 60\%$: **30 pts**
2. **$S_{\text{Lapses}}$ — Assignment Submission Lapses (Max 20 points):**
   - 0 missed assignments: **0 pts**
   - 1 missed assignment: **10 pts**
   - $\ge 2$ missed assignments: **20 pts**
3. **$S_{\text{Isolation}}$ — Hostel Isolation & Gate Pass Irregularity (Max 25 points):**
   - Hostel night attendance absences or repeat emergency gate pass triggers: **15 - 25 pts**
   - Regular routine: **0 pts**
4. **$S_{\text{SelfCheckin}}$ — Voluntary Student Self Check-in (Max 25 points):**
   - Completely optional & consent-driven 5-question micro-survey (Sleep quality, energy, stress level, social interaction, academic burnout on a 1-5 scale).
   - High distress answers contribute up to **25 pts**. If skipped by student, weight is normalized over the other 3 objective factors.

### Score Classification:
- **0 – 39: Low Risk (Green)** — Normal campus wellbeing.
- **40 – 69: Moderate Risk (Amber)** — Proactive wellbeing check-in suggested.
- **70 – 100: High Risk (Red)** — Automated confidential alert dispatched to Mental Health Counselor.

### Privacy & Ethical Guardrails:
- Strictly protected by `@role_required('counselor')` at the controller and query level.
- Teachers, HODs, wardens, and administrators **cannot** query or view this data.
- Every counselor query is audited in `AuditLog`.
- Prominently watermarked: *"Confidential Screening Support — Not a Medical Diagnosis."*

---

## 6. Items Needing User Decision (Spec H.3 & Existing Partial Items)

1. **Hostel Superintendent Room Review (Spec H.3):**
   - *Current state:* `app/admin/routes.py:room_inspect` exists and shows room complaints via QR code, but does not list room student members or gate passes raised from that specific room.
   - *Decision needed:* Shall we expand the existing `room_inspect` view or add a dedicated Room Directory tab in the Warden/Superintendent dashboard to list room occupants + their active gate passes + complaints?
2. **Pre-existing Code Issues (from Audit):**
   - `app/__init__.py`: Missing `flash, redirect, url_for` in session validation (causes 500 on session expiry).
   - `app/student/routes.py`: Line 32 has `office_staff.dashboard` instead of `office.dashboard`.
   - `templates/maintenance/ticket_detail.html`: Double `uploads/` path.
   - `templates/student/home.html`: Orphaned `/leaves` button.
   *Decision needed:* Per Golden Rule 3, should we fix these while updating foundation files, or leave them strictly untouched?

---

## 7. Build Execution Plan & Phasing Order

Once user approves:
1. **Foundation:** Register new roles, update RBAC mapping, add new blueprint modules, create seed script for pre-approved employee codes.
2. **Communities in App (Spec I):** Student, Teacher, Hostel, Day Scholar, Admin, Special communities with automatic profile assignment and posting permissions.
3. **Examination & Account Sections (Spec A & B):** Filtered dashboards, Excel exports, cryptographic receipt generator & verification route, student payment view.
4. **College Cafeteria (Spec C):** Menu & stock manager, "Not Available" block, student online order placement with test payment & hostel delivery.
5. **College Cyber Cafe (Spec D):** Priority 1 & 2 scholarship queues (max 20 offline slots), live call status, printing queue, student & teacher upload portal.
6. **Library (Spec E):** Book catalog, student & teacher separate queues, confirmation & pickup notifications.
7. **Events & Sports Live Scoring (Spec F):** Event application & winner summaries, Annual Sports live score short-polling system.
8. **Basic Dashboards Extensions (Spec H):** Teacher assignment post & grading, Caretaker night attendance & health emergency escalation, Superintendent room review expansion.
9. **Depression Index (Spec G):** Wellbeing risk calculation engine, consent-driven self check-in, counselor-only confidential dashboard.
10. **Final Verification & `FINAL_CHECK.md` generation.**
