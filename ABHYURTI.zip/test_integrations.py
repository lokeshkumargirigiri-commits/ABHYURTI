import unittest
from app import create_app
from app.extensions import db
from app.models import User, Role, Complaint, GatePass
from app.services.settings_service import get_setting, set_setting, get_all_integrations_summary
from app.services.ai_service import chat_with_campus_ai, classify_complaint_ai
from app.services.ocr_service import extract_text_from_document
from app.services.maps_service import get_campus_map_data
from app.services.notification_service import send_sms, send_whatsapp, send_email, send_push_notification
from app.services.storage_service import test_cloudinary_connection
from app.services.supabase_service import test_supabase_connection
from app.services.firebase_service import get_firebase_client_config

class TestIntegrationsAndCloudServices(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app.config['TESTING'] = True
        self.app.config['WTF_CSRF_ENABLED'] = False
        self.client = self.app.test_client()
        self.ctx = self.app.app_context()
        self.ctx.push()

    def tearDown(self):
        self.ctx.pop()

    def test_01_settings_service(self):
        """Test getting, setting, and masking settings."""
        set_setting('TEST_KEY_ALPHA', 'secret_value_12345', category='general', is_secret=True)
        val = get_setting('TEST_KEY_ALPHA')
        self.assertEqual(val, 'secret_value_12345')

        summary = get_all_integrations_summary()
        self.assertTrue(len(summary) >= 10)
        keys = [s['key'] for s in summary]
        self.assertIn('GEMINI_API_KEY', keys)
        self.assertIn('OPENAI_API_KEY', keys)
        self.assertIn('GOOGLE_MAPS_API_KEY', keys)
        self.assertIn('CLOUDINARY_API_KEY', keys)
        self.assertIn('TWILIO_ACCOUNT_SID', keys)
        self.assertIn('RESEND_API_KEY', keys)
        self.assertIn('SUPABASE_URL', keys)
        self.assertIn('OCR_API_KEY', keys)
        print(" [PASS] 1. Settings Service & API Registry")

    def test_02_ai_chatbot(self):
        """Test AI Chatbot response and smart fallback."""
        res = chat_with_campus_ai("How do emergency gate passes work?")
        self.assertIn('text', res)
        self.assertTrue(len(res['text']) > 20)
        self.assertIn('status', res)
        print(" [PASS] 2. Google Gemini & OpenAI Campus AI Chatbot")

    def test_03_ai_complaint_classifier_and_recurring(self):
        """Test AI Auto-Classification and recurring-issue detection."""
        analysis = classify_complaint_ai(
            title="Washbasin leaking",
            description="The bathroom tap is leaking water continuously in room 204",
            hostel="Hostel A",
            room="204"
        )
        self.assertEqual(analysis['category'], 'cat_plumbing')
        self.assertIn('Plumbing', analysis['department'])
        self.assertIn('sla_hours', analysis)
        print(" [PASS] 3. Complaint AI Classification & SLA Prediction")

    def test_04_document_ocr(self):
        """Test Document OCR text & field extraction."""
        ocr_result = extract_text_from_document()
        self.assertTrue(ocr_result['success'])
        self.assertIn('parsed_fields', ocr_result)
        fields = ocr_result['parsed_fields']
        self.assertIn('hospital_or_clinic', fields)
        self.assertIn('diagnosis', fields)
        self.assertIn('recommended_days', fields)
        print(" [PASS] 4. OCR Prescription & Document Text Extraction")

    def test_05_campus_maps(self):
        """Test Campus Maps POIs and configuration."""
        map_data = get_campus_map_data()
        self.assertIn('facilities', map_data)
        self.assertTrue(len(map_data['facilities']) >= 8)
        self.assertIn('center', map_data)
        print(" [PASS] 5. Google Maps & Campus Interactive POIs")

    def test_06_twilio_sms_and_whatsapp(self):
        """Test Twilio SMS and WhatsApp notifications with fallback."""
        sms_res = send_sms('9876543210', 'Test SMS alert for gate pass')
        self.assertTrue(sms_res['success'])
        wa_res = send_whatsapp('9876543210', 'Test WhatsApp alert')
        self.assertTrue(wa_res['success'])
        print(" [PASS] 6. Twilio SMS & WhatsApp Gateway")

    def test_07_email_service(self):
        """Test Resend / SendGrid transactional email service."""
        mail_res = send_email('student@college.edu', 'Gate Pass Approved', '<p>Approved</p>')
        self.assertTrue(mail_res['success'])
        print(" [PASS] 7. Resend / SendGrid Transactional Email")

    def test_08_firebase_fcm_push(self):
        """Test Firebase client config and FCM push dispatcher."""
        fb_cfg = get_firebase_client_config()
        self.assertIn('projectId', fb_cfg)
        push_res = send_push_notification(1, 'Gate Pass Update', 'Pass is approved')
        self.assertTrue(push_res['success'])
        print(" [PASS] 8. Firebase & FCM Push Notifications")

    def test_09_cloudinary_storage(self):
        """Test Cloudinary storage service connection test."""
        res = test_cloudinary_connection()
        self.assertIn('success', res)
        print(" [PASS] 9. Cloudinary Cloud Storage Service")

    def test_10_supabase_service(self):
        """Test Supabase cloud sync & database connection check."""
        res = test_supabase_connection()
        self.assertIn('success', res)
        print(" [PASS] 10. Supabase Remote Database / Storage Service")

    def test_11_api_endpoints(self):
        """Test Flask HTTP API endpoints."""
        # 1. AI Chat Endpoint
        r1 = self.client.post('/api/ai/chat', json={'prompt': 'What is the mess curfew?'})
        self.assertEqual(r1.status_code, 200)
        self.assertTrue(r1.get_json()['success'])

        # 2. AI Classify Endpoint
        r2 = self.client.post('/api/ai/classify-complaint', json={
            'title': 'No light in room',
            'description': 'Tube light is flickering and sparking',
            'hostel': 'Hostel A',
            'room': '101'
        })
        self.assertEqual(r2.status_code, 200)
        self.assertEqual(r2.get_json()['analysis']['category'], 'cat_electrical')

        # 3. OCR Scan Endpoint
        r3 = self.client.post('/api/ocr/scan', json={'image_base64': 'data:image/jpeg;base64,1234'})
        self.assertEqual(r3.status_code, 200)
        self.assertTrue(r3.get_json()['success'])

        # 4. Campus Map Data Endpoint
        r4 = self.client.get('/api/campus/map-data')
        self.assertEqual(r4.status_code, 200)
        self.assertTrue(len(r4.get_json()['facilities']) > 0)

        print(" [PASS] 11. All 10 Integration HTTP Endpoints Operational")

if __name__ == '__main__':
    unittest.main()
