import os
import sys
from datetime import datetime, date, timedelta

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__))))

from app import create_app
from app.extensions import db
from app.models import (
    User, Role, FeePayment, CafeteriaItem, CafeteriaOrder, CafeteriaOrderItem,
    CyberCafeRequest, LibraryBook, LibraryBookRequest, CampusEvent, EventApplication,
    SportsLiveScore, StudentWellbeingIndex, CounselorSessionNote, Assignment,
    AssignmentSubmission, HostelNightAttendance, CaretakerHealthEmergency,
    Community, CommunityMembership, CommunityPost, GatePass, Complaint, StudentProfile, StaffProfile
)
from app.services.wellbeing_service import calculate_student_wellbeing_index

def seed_demo_data():
    app = create_app()
    with app.app_context():
        print("[SEED] Seeding Demo Users and Spec Records...")

        # 1. Users & Roles
        users_config = [
            {
                'email': 'aarav.student@fretbox.internal',
                'name': 'Aarav Sharma',
                'phone': '9900000001',
                'role': 'student',
                'roll': '21CS101',
                'branch': 'Computer Science',
                'hostel': 'Himalaya Boys Hostel',
                'room': 'B-201'
            },
            {
                'email': 'priya.student@fretbox.internal',
                'name': 'Priya Nair',
                'phone': '9900000002',
                'role': 'student',
                'roll': '21CS102',
                'branch': 'Computer Science',
                'hostel': 'Ganga Girls Hostel',
                'room': 'G-104'
            },
            {
                'email': 'account.staff@fretbox.internal',
                'name': 'R. K. Gupta',
                'phone': '9900000003',
                'role': 'account_staff',
                'emp_id': 'ACC-101'
            },
            {
                'email': 'exam.staff@fretbox.internal',
                'name': 'Dr. V. Raman',
                'phone': '9900000004',
                'role': 'exam_staff',
                'emp_id': 'EXM-101'
            },
            {
                'email': 'cafeteria.staff@fretbox.internal',
                'name': 'Chef Suresh Kumar',
                'phone': '9900000005',
                'role': 'cafeteria_staff',
                'emp_id': 'CAF-101'
            },
            {
                'email': 'cybercafe.staff@fretbox.internal',
                'name': 'M. Anand',
                'phone': '9900000006',
                'role': 'cyber_cafe_staff',
                'emp_id': 'CYB-101'
            },
            {
                'email': 'librarian.staff@fretbox.internal',
                'name': 'Mrs. Sunita Verma',
                'phone': '9900000007',
                'role': 'librarian',
                'emp_id': 'LIB-101'
            },
            {
                'email': 'event.coord@fretbox.internal',
                'name': 'Prof. Ananya Sen',
                'phone': '9900000008',
                'role': 'event_coordinator',
                'emp_id': 'EVT-101'
            },
            {
                'email': 'sports.coord@fretbox.internal',
                'name': 'Coach D. Singh',
                'phone': '9900000009',
                'role': 'sports_coordinator',
                'emp_id': 'SPT-101'
            },
            {
                'email': 'counselor.staff@fretbox.internal',
                'name': 'Dr. Neha Kapoor (PhD)',
                'phone': '9900000010',
                'role': 'counselor',
                'emp_id': 'CNS-101'
            },
            {
                'email': 'caretaker.staff@fretbox.internal',
                'name': 'Ram Prasad Caretaker',
                'phone': '9900000011',
                'role': 'caretaker',
                'emp_id': 'CRK-101'
            },
            {
                'email': 'superintendent.staff@fretbox.internal',
                'name': 'Hostel Superintendent Roy',
                'phone': '9900000012',
                'role': 'superintendent',
                'emp_id': 'SUP-101'
            },
            {
                'email': 'prof.mathur@fretbox.internal',
                'name': 'Prof. K. Mathur',
                'phone': '9900000013',
                'role': 'faculty',
                'emp_id': 'FAC-101'
            }
        ]

        created_users = {}
        for udata in users_config:
            u = User.query.filter_by(email=udata['email']).first()
            if not u:
                u = User(
                    name=udata['name'],
                    email=udata['email'],
                    phone=udata['phone'],
                    role=udata['role'],
                    status='approved',
                    is_active=True,
                    hostel=udata.get('hostel'),
                    room=udata.get('room'),
                    branch=udata.get('branch'),
                    roll_number=udata.get('roll')
                )
                u.set_password('Password123')
                db.session.add(u)
                db.session.flush()

                # Assign role relation
                role_obj = Role.query.filter_by(name=udata['role']).first()
                if role_obj and role_obj not in u.roles:
                    u.roles.append(role_obj)

                if udata['role'] == 'student':
                    sp = StudentProfile(
                        user_id=u.id,
                        roll_number=udata.get('roll'),
                        branch=udata.get('branch'),
                        semester=5,
                        hostel=udata.get('hostel'),
                        room=udata.get('room')
                    )
                    db.session.add(sp)
                else:
                    stf = StaffProfile(
                        user_id=u.id,
                        department='Academic Affairs' if udata['role'] in ('faculty', 'counselor') else 'Administration',
                        designation=udata['role'].replace('_', ' ').title(),
                        requested_role=udata['role'],
                        employee_id=udata.get('emp_id') or f"EMP-{u.id}"
                    )
                    db.session.add(stf)

            created_users[udata['role']] = u
        db.session.commit()

        aarav = User.query.filter_by(email='aarav.student@fretbox.internal').first()
        prof = User.query.filter_by(email='prof.mathur@fretbox.internal').first()

        # 2. Seed Fee Demands
        if not FeePayment.query.filter_by(student_id=aarav.id).first():
            fee1 = FeePayment(
                student_id=aarav.id,
                fee_type='Semester 5 Tuition Fee',
                academic_year='2025-2026',
                semester=5,
                amount=35000.0,
                status='pending'
            )
            fee2 = FeePayment(
                student_id=aarav.id,
                fee_type='Hostel & Mess Maintenance Fee',
                academic_year='2025-2026',
                semester=5,
                amount=12000.0,
                status='pending'
            )
            db.session.add_all([fee1, fee2])

        # 3. Seed Cafeteria Items
        if CafeteriaItem.query.count() == 0:
            items = [
                CafeteriaItem(name='Paneer Butter Masala Roll', category='snack', price=80.0, is_available=True, description='Hot rolled paratha with spiced cottage cheese'),
                CafeteriaItem(name='Cold Coffee with Ice Cream', category='beverage', price=60.0, is_available=True, description='Blended cold brew with vanilla scoop'),
                CafeteriaItem(name='Cheese Veg Grilled Sandwich', category='snack', price=70.0, is_available=True, description='Grilled triple layer sandwich'),
                CafeteriaItem(name='South Indian Masala Dosa', category='meal', price=65.0, is_available=True, description='Crispy crepe with aloo masala and sambar'),
                CafeteriaItem(name='Fresh Lime Soda (Sweet & Salt)', category='beverage', price=35.0, is_available=True, description='Refreshing fizzy lemon drink'),
                CafeteriaItem(name='Special Chole Bhature Combo', category='meal', price=95.0, is_available=False, description='Punjabi chole with fluffy bhature')
            ]
            db.session.add_all(items)

        # 4. Seed Library Books
        if LibraryBook.query.count() == 0:
            books = [
                LibraryBook(title='Introduction to Algorithms (4th Edition)', author='Thomas H. Cormen, Charles E. Leiserson', isbn='9780262046305', category='Computer Science', total_copies=6, available_copies=5),
                LibraryBook(title='Modern Operating Systems (5th Edition)', author='Andrew S. Tanenbaum, Herbert Bos', isbn='9780133591620', category='Operating Systems', total_copies=4, available_copies=4),
                LibraryBook(title='Clean Code: A Handbook of Agile Software Craftsmanship', author='Robert C. Martin', isbn='9780132350884', category='Software Engineering', total_copies=5, available_copies=3),
                LibraryBook(title='Database System Concepts', author='Abraham Silberschatz, Henry F. Korth', isbn='9780078022159', category='Databases', total_copies=5, available_copies=5)
            ]
            db.session.add_all(books)

        # 5. Seed Campus Events & Sports
        if CampusEvent.query.count() == 0:
            ev1 = CampusEvent(
                title='InnovateX: Annual University Hackathon 2026',
                category='technical',
                description='48-hour prototype building contest with INR 1,00,000 in prizes and industry mentors.',
                event_date=datetime.utcnow() + timedelta(days=12),
                venue='Auditorium Complex - Hall B',
                max_participants=200,
                is_active=True
            )
            ev2 = CampusEvent(
                title='Spardha: Inter-Hostel Cricket Trophy',
                category='sports',
                description='Annual cricket championship between Himalaya, Aravali, Nilgiri, and Vindhya blocks.',
                event_date=datetime.utcnow() + timedelta(days=2),
                venue='Main University Sports Grounds',
                max_participants=60,
                is_active=True
            )
            db.session.add_all([ev1, ev2])

        if SportsLiveScore.query.count() == 0:
            match = SportsLiveScore(
                match_title='Spardha Cricket Trophy 2026',
                sport_type='cricket',
                team_a='Himalaya Boys Hostel',
                team_b='Aravali Warriors',
                score_a='146/4 (16.2 ov)',
                score_b='98/6 (14.0 ov)',
                current_status='live',
                summary='Himalaya needs 12 runs in 22 balls to reach finals. Top scorer: Aarav (54*)'
            )
            db.session.add(match)

        # 6. Seed Faculty Assignment
        if Assignment.query.count() == 0:
            assg = Assignment(
                faculty_id=prof.id,
                subject='CS301 Operating Systems',
                title='Process Synchronization & Mutexes Lab',
                description='Implement Dekker and Peterson algorithms in C/Python and measure race conditions.',
                department='Computer Science',
                semester=5,
                due_date=datetime.utcnow() + timedelta(days=5),
                max_score=50
            )
            db.session.add(assg)

        # 7. Seed Gate-pass & Complaint for room B-201
        gp_existing = GatePass.query.filter_by(student_id=aarav.id).first()
        if not gp_existing:
            gp = GatePass(
                student_id=aarav.id,
                reason='Weekend family visit to home town',
                destination='Home - Jaipur',
                from_date=datetime.utcnow() + timedelta(days=1),
                to_date=datetime.utcnow() + timedelta(days=3),
                status='pending'
            )
            db.session.add(gp)

        comp_existing = Complaint.query.filter_by(student_id=aarav.id).first()
        if not comp_existing:
            c1 = Complaint(
                student_id=aarav.id,
                hostel=aarav.hostel,
                room=aarav.room,
                category='electrical',
                description='Ceiling fan making clicking sound on speed 3 & 4',
                status='pending'
            )
            c2 = Complaint(
                student_id=aarav.id,
                hostel=aarav.hostel,
                room=aarav.room,
                category='carpentry',
                description='Study desk drawer handle fixed',
                status='resolved'
            )
            db.session.add_all([c1, c2])

        # 8. Seed Communities
        if Community.query.count() == 0:
            c_cse = Community(
                name='Computer Science & Engineering',
                slug='cse-department',
                description='Official circle for Computer Science students and faculty.',
                type='department'
            )
            c_hostel = Community(
                name='Himalaya Boys Hostel Community',
                slug='himalaya-boys-hostel',
                description='Residential block discussion, maintenance notices, and events.',
                type='hostel'
            )
            c_robotics = Community(
                name='Campus Robotics & IoT Club',
                slug='robotics-iot-club',
                description='Open club for hardware hackers, drones, and ROS robotics enthusiasts.',
                type='interest_club'
            )
            db.session.add_all([c_cse, c_hostel, c_robotics])
            db.session.flush()

            m1 = CommunityMembership(community_id=c_cse.id, user_id=aarav.id, role='member')
            m2 = CommunityMembership(community_id=c_hostel.id, user_id=aarav.id, role='member')
            p1 = CommunityPost(
                community_id=c_cse.id,
                author_id=aarav.id,
                title='Welcome to Semester 5 CS Circle!',
                content='Feel free to share notes, lab assignments, and study materials here.',
                is_pinned=True
            )
            db.session.add_all([m1, m2, p1])

        # Commit all base seed data
        db.session.commit()

        # Recalculate Aarav's wellbeing score
        calculate_student_wellbeing_index(aarav.id)
        db.session.commit()

        print("[SEED SUCCESS] Demo Data Seeded Successfully!")

if __name__ == '__main__':
    seed_demo_data()
