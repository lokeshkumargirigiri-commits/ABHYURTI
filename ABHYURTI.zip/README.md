# ABHYURTI Campus OS

**ABHYURTI Campus OS** is a unified, multi-role campus operations and student lifecycle management platform designed for universities, colleges, and higher education institutions.

---

## 🏛️ Overview & Core Philosophy

ABHYURTI replaces fragmented paper diaries, manual queue slips, and unverified chat groups with automated, auditable, and SLA-driven institutional workflows:

- **18 Distinct Portals & Role-Based Access Control (RBAC)**: Complete isolation across Student, Faculty, Warden / Superintendent, Caretaker, Mess Manager, Maintenance, Office Staff, Accounts Section, Examination Section, College Cafeteria, Cyber Cafe, Library, Events & Sports, Counselor (Student Wellbeing), and Super Admin.
- **Auditable Cryptographic Ledger**: HMAC-SHA256 digital signatures on all institutional fee payments and examination clearance receipts with instant public QR verification.
- **Zero-Failure Operations & Kiosk Fallback**: Offline-first touch kiosk terminal for students without active smartphones or low network coverage.
- **7-Language Localization**: Full native multi-language interface with dynamic one-click switching across English, Hindi (हिन्दी), Odia (ଓଡ଼ିଆ), Tamil (தமிழ்), Bengali (বাংলা), Telugu (తెలుగు), and Marathi (मराठी).
- **Proactive Student Wellbeing Early Warning System**: Algorithmic depression index engine evaluating academic stress, attendance patterns, and social isolation.

---

## 🚀 Quick Start & Local Execution

### 1. Requirements
- Python 3.10+ (tested on Python 3.11)
- SQLite3

### 2. Environment Setup
```bash
# Clone or navigate to the repository directory
cd GAYU

# Install dependencies
pip install -r requirements.txt

# Run database setup & spec demo seed (optional)
python seed_spec_demo.py
```

### 3. Start Application
```bash
python run.py
```
Access the application locally at `http://127.0.0.1:5000`.

---

## 👥 Default Demo Credentials

All roles can sign in directly from the login portal (`/login`):

| Role / Section | Demo Email / Identifier | Password | Access Route |
| :--- | :--- | :--- | :--- |
| **Student** | `aarav.student@fretbox.internal` | `Pass@123` | `/` |
| **Faculty / Teacher** | `dr.sharma.faculty@fretbox.internal` | `Pass@123` | `/faculty/dashboard` |
| **Hostel Superintendent / Warden** | `superintendent.staff@fretbox.internal` | `Pass@123` | `/admin/dashboard` |
| **Accounts Section** | `account.staff@fretbox.internal` | `Pass@123` | `/account-section/dashboard` |
| **Examination Section** | `exam.staff@fretbox.internal` | `Pass@123` | `/examination/dashboard` |
| **College Cafeteria** | `cafeteria.staff@fretbox.internal` | `Pass@123` | `/cafeteria/dashboard` |
| **Cyber Cafe** | `cybercafe.staff@fretbox.internal` | `Pass@123` | `/cyber-cafe/dashboard` |
| **Library** | `librarian.staff@fretbox.internal` | `Pass@123` | `/library/dashboard` |
| **Events & Sports** | `event.coord@fretbox.internal` | `Pass@123` | `/events/dashboard` |
| **Counselor (Wellbeing)** | `counselor.staff@fretbox.internal` | `Pass@123` | `/counselor/dashboard` |
| **Hostel Caretaker** | `caretaker.staff@fretbox.internal` | `Pass@123` | `/caretaker/dashboard` |
| **Super Admin** | `admin@fretbox.internal` | `Admin@123` | `/super-admin/dashboard` |

---

## 🔒 Security & Privacy Architecture
- **Role Isolation**: Strict `@role_required` guards across blueprints preventing cross-role privilege escalation.
- **HMAC Signatures**: Official receipt validation ensuring receipts cannot be spoofed or altered.
- **CSRF & Rate Limiting**: Token-protected form submissions and API throttling against brute-force attempts.
- **Client Cache Privacy**: `Cache-Control: no-store` headers on private authenticated views preventing browser back-button cache leaks.

---

## 📄 License
Internal Institutional License — ABHYURTI Campus Operations.
