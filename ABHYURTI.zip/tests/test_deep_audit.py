import unittest
import os
import json
from app import create_app
from app.extensions import db
from app.models import (
    User, FeePayment, CafeteriaItem, CyberCafeRequest, LibraryBook,
    SportsLiveScore, CampusEvent, StudentWellbeingIndex, Assignment, Community
)

class DeepAuditTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config['TESTING'] = True
        cls.app.config['WTF_CSRF_ENABLED'] = False
        cls.app.config['RATELIMIT_ENABLED'] = False
        from app.extensions import limiter
        limiter.enabled = False
        cls.client = cls.app.test_client()

    def login_as(self, email):
        self.client.get('/logout', follow_redirects=True)
        with self.client.session_transaction() as sess:
            sess.clear()
        res = self.client.post('/login', data={'identifier': email, 'password': 'Password123' if 'admin@' not in email else 'Admin@123'}, follow_redirects=True)
        return res

    def test_01_all_dashboards_render_200_and_contain_abhyurti(self):
        roles_and_dashboards = [
            ('aarav.student@fretbox.internal', '/', 'Student Home'),
            ('dr.sharma.faculty@fretbox.internal', '/faculty/dashboard', 'Faculty Dashboard'),
            ('superintendent.staff@fretbox.internal', '/admin/dashboard', 'Superintendent Dashboard'),
            ('caretaker.staff@fretbox.internal', '/caretaker/dashboard', 'Caretaker Dashboard'),
            ('account.staff@fretbox.internal', '/account/dashboard', 'Account Section Dashboard'),
            ('exam.staff@fretbox.internal', '/examination/dashboard', 'Examination Dashboard'),
            ('cafeteria.staff@fretbox.internal', '/cafeteria/dashboard', 'Cafeteria Dashboard'),
            ('cybercafe.staff@fretbox.internal', '/cyber-cafe/dashboard', 'Cyber Cafe Dashboard'),
            ('librarian.staff@fretbox.internal', '/library/dashboard', 'Library Dashboard'),
            ('event.coord@fretbox.internal', '/events/dashboard', 'Events Dashboard'),
            ('counselor.staff@fretbox.internal', '/counselor/dashboard', 'Counselor Dashboard'),
            ('admin@fretbox.internal', '/super-admin/dashboard', 'Super Admin Dashboard'),
            ('chef.ramesh@fretbox.internal', '/mess-manager/dashboard', 'Mess Manager Dashboard'),
            ('tech.kumar@fretbox.internal', '/maintenance/dashboard', 'Maintenance Dashboard'),
            ('office.patel@fretbox.internal', '/office/dashboard', 'Office Staff Dashboard'),
        ]
        for email, path, label in roles_and_dashboards:
            with self.subTest(role=label):
                self.login_as(email)
                res = self.client.get(path, follow_redirects=True)
                self.assertEqual(res.status_code, 200, f"Dashboard {path} for {label} returned {res.status_code}")
                self.assertIn(b'ABHYURTI', res.data, f"Brand 'ABHYURTI' missing in dashboard {path} for {label}")

    def test_02_rbac_cross_access_strict_403(self):
        # A student must NEVER access staff or admin dashboards
        self.login_as('aarav.student@fretbox.internal')
        protected_staff_routes = [
            '/faculty/dashboard',
            '/admin/dashboard',
            '/caretaker/dashboard',
            '/account/dashboard',
            '/examination/dashboard',
            '/cafeteria/dashboard',
            '/cyber-cafe/dashboard',
            '/library/dashboard',
            '/counselor/dashboard',
            '/super-admin/dashboard',
            '/mess-manager/dashboard',
            '/maintenance/dashboard',
            '/office/dashboard'
        ]
        for path in protected_staff_routes:
            with self.subTest(path=path):
                res = self.client.get(path)
                self.assertEqual(res.status_code, 403, f"Student accessed {path} with code {res.status_code}")

    def test_03_receipts_and_hall_tickets_contain_abhyurti(self):
        with self.app.app_context():
            payment = FeePayment.query.filter_by(status='paid').first()
            self.assertIsNotNone(payment, "Paid FeePayment not found in test db")
            payment_id = payment.id
            token = payment.receipt_token

        # Student receipt
        self.login_as('aarav.student@fretbox.internal')
        res = self.client.get(f'/account/receipt/{payment_id}', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'ABHYURTI', res.data)
        self.assertNotIn(b'Fretbox', res.data)

        # Public receipt verification
        self.client.get('/logout')
        res = self.client.get(f'/verify/receipt/{token}', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'ABHYURTI', res.data)
        self.assertNotIn(b'Fretbox', res.data)

        # Hall ticket
        self.login_as('aarav.student@fretbox.internal')
        res = self.client.get('/examination/hall-ticket', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'ABHYURTI CAMPUS AUTONOMOUS EXAMINATIONS', res.data)
        self.assertNotIn(b'Fretbox', res.data)

    def test_04_csv_exports_content_and_headers(self):
        # Account fee ledger CSV
        self.login_as('account.staff@fretbox.internal')
        res = self.client.get('/account/export', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.mimetype, 'text/csv')
        disposition = res.headers.get('Content-Disposition', '')
        self.assertTrue('abhyurti_fee_collections_export_' in disposition, f"Unexpected header: {disposition}")

        # Warden / Superintendent complaints CSV
        self.login_as('superintendent.staff@fretbox.internal')
        res = self.client.get('/admin/complaints/export')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.mimetype, 'text/csv')
        disposition = res.headers.get('Content-Disposition', '')
        self.assertTrue('abhyurti_complaints_' in disposition, f"Unexpected header: {disposition}")

        # Examination clearance ledger CSV
        self.login_as('exam.staff@fretbox.internal')
        res = self.client.get('/examination/export?department=CSE&semester=6')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.mimetype, 'text/csv')
        disposition = res.headers.get('Content-Disposition', '')
        self.assertTrue('abhyurti_exam_clearance_ledger_' in disposition, f"Unexpected header: {disposition}")
        self.assertIn(b'Roll Number', res.data)
        self.assertIn(b'Fee Clearance Status', res.data)

    def test_05_sports_live_scores_api(self):
        res = self.client.get('/events/api/live-scores')
        self.assertEqual(res.status_code, 200)
        data = res.get_json()
        self.assertTrue(data.get('success'), f"Sports API missing success=True: {data}")
        self.assertIn('matches', data)

    def test_06_theme_and_all_7_languages_branding(self):
        langs = ['en', 'hi', 'or', 'ta', 'bn', 'te', 'mr']
        for lang in langs:
            res = self.client.get(f'/login?lang={lang}', follow_redirects=True)
            self.assertEqual(res.status_code, 200)
            self.assertIn(b'ABHYURTI', res.data, f"ABHYURTI missing in language {lang}")
            self.assertNotIn(b'Fretbox', res.data, f"Old name Fretbox found in language {lang}")

if __name__ == '__main__':
    unittest.main()
