import unittest
import os
import sys
from datetime import datetime, date, timedelta

# Add parent dir to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from app import create_app
from app.extensions import db
from app.models import (
    User, Role, FeePayment, CafeteriaItem, CafeteriaOrder, CafeteriaOrderItem,
    CyberCafeRequest, LibraryBook, LibraryBookRequest, CampusEvent, EventApplication,
    SportsLiveScore, StudentWellbeingIndex, CounselorSessionNote, Assignment,
    AssignmentSubmission, HostelNightAttendance, CaretakerHealthEmergency,
    Community, CommunityMembership, CommunityPost, GatePass, Complaint, AuditLog
)
from app.services.receipt_service import sign_fee_payment, verify_fee_payment
from app.services.wellbeing_service import calculate_student_wellbeing_index


class ComprehensiveCampusOSTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config['TESTING'] = True
        cls.app.config['WTF_CSRF_ENABLED'] = False  # Disable CSRF for programmatic HTTP calls
        cls.app.config['RATELIMIT_ENABLED'] = False
        from app.extensions import limiter
        limiter.enabled = False
        cls.client = cls.app.test_client()
        cls.ctx = cls.app.app_context()
        cls.ctx.push()

    @classmethod
    def tearDownClass(cls):
        cls.ctx.pop()

    def login_as(self, email):
        user = User.query.filter_by(email=email).first()
        if not user:
            raise ValueError(f"User with email {email} not found in database!")
        self.logout()
        res = self.client.post('/login', data={'identifier': email, 'password': 'Password123'}, follow_redirects=True)
        return user

    def logout(self):
        self.client.get('/logout', follow_redirects=True)
        with self.client.session_transaction() as sess:
            sess.clear()

    # =========================================================================
    # 1. Baseline Bug Fixes Verification
    # =========================================================================
    def test_01_baseline_bug_fixes(self):
        print("\n--- Testing Baseline Bug Fixes ---")
        # Fix 1: Session expiry imports in app/__init__.py
        with open(os.path.join(self.app.root_path, '__init__.py'), 'r', encoding='utf-8') as f:
            content = f.read()
            self.assertIn("flash('Your session has expired.", content)
            self.assertIn("from flask import", content)

        # Fix 2: app/student/routes.py line 32 redirect to office.dashboard
        with open(os.path.join(self.app.root_path, 'student', 'routes.py'), 'r', encoding='utf-8') as f:
            content = f.read()
            self.assertIn("redirect(url_for('office.dashboard'))", content)
            self.assertNotIn("office_staff.dashboard", content)

        # Fix 3: templates/maintenance/ticket_detail.html uploads path
        template_path = os.path.join(self.app.root_path, '..', 'templates', 'maintenance', 'ticket_detail.html')
        with open(template_path, 'r', encoding='utf-8') as f:
            content = f.read()
            self.assertNotIn("uploads/uploads/", content)

        # Fix 4: templates/student/home.html leaves route connected
        home_path = os.path.join(self.app.root_path, '..', 'templates', 'student', 'home.html')
        with open(home_path, 'r', encoding='utf-8') as f:
            content = f.read()
            self.assertIn("url_for('student.leaves_list')", content)
        print("[PASS] Baseline Bug Fixes verified successfully.")

    # =========================================================================
    # 2. Spec A & B: Accounts & Cryptographic Receipts
    # =========================================================================
    def test_02_accounts_and_receipts(self):
        print("\n--- Testing Accounts & Cryptographic Receipts ---")
        student = self.login_as('aarav.student@fretbox.internal')

        # Check student fee view
        res = self.client.get('/account/student/fees')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Student Fee Portal', res.data)

        # Get pending fee (or create one for testing if already paid)
        with self.app.app_context():
            pending_fee = FeePayment.query.filter_by(student_id=student.id, status='pending').first()
            if not pending_fee:
                pending_fee = FeePayment(
                    student_id=student.id,
                    fee_type='semester',
                    academic_year='2026-27',
                    semester=6,
                    amount=45000.0,
                    status='pending'
                )
                db.session.add(pending_fee)
                db.session.commit()
            fee_id = pending_fee.id

        # Submit mock payment
        res = self.client.post(f'/account/student/pay/{fee_id}', data={
            'payment_method': 'UPI'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # Fetch latest payment
        with self.app.app_context():
            payment = FeePayment.query.get(fee_id)
            self.assertEqual(payment.status, 'paid')
            self.assertIsNotNone(payment.receipt_token)
            self.assertIsNotNone(payment.receipt_signature)

            token = payment.receipt_token

        # Check receipt page as student
        res = self.client.get(f'/account/receipt/{payment.id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Fee Receipt', res.data)

        # Public verification route (no login required)
        self.logout()
        res = self.client.get(f'/verify/receipt/{token}')
        self.assertEqual(res.status_code, 302)  # Redirects to account_section.verify_receipt
        res = self.client.get(f'/account/verify/{token}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'OFFICIALLY VERIFIED & AUTHENTIC', res.data)

        # Test RBAC: student cannot view account staff dashboard
        self.login_as('aarav.student@fretbox.internal')
        res = self.client.get('/account/dashboard')
        self.assertEqual(res.status_code, 403)

        # Account staff can view dashboard and export CSV
        # Account staff can view dashboard and export CSV
        self.login_as('account.staff@fretbox.internal')
        res = self.client.get('/account/dashboard')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Account Section & Collections Ledger', res.data)

        res = self.client.get('/account/export-csv')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.content_type, 'text/csv; charset=utf-8')
        print("[PASS] Accounts & Receipts verified successfully.")

    # =========================================================================
    # 3. Spec A & B: Examination & Hall Ticket Withholding
    # =========================================================================
    def test_03_examination_and_hall_tickets(self):
        print("\n--- Testing Examination & Hall Ticket Withholding ---")
        student = self.login_as('aarav.student@fretbox.internal')

        # Check examination student portal
        res = self.client.get('/examination/my-exams')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'End-Semester Examinations', res.data)

        # Check hall ticket view (student has completed payments, so dues check operates)
        res = self.client.get('/examination/hall-ticket')
        self.assertEqual(res.status_code, 200)

        # Test RBAC: student cannot access exam staff dashboard
        res = self.client.get('/examination/dashboard')
        self.assertEqual(res.status_code, 403)

        # Exam staff can access dashboard
        self.login_as('exam.staff@fretbox.internal')
        res = self.client.get('/examination/dashboard')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Controller of Examinations', res.data)
        print("[PASS] Examination & Hall Tickets verified successfully.")

    # =========================================================================
    # 4. Spec C: Cafeteria Operations
    # =========================================================================
    def test_04_cafeteria_operations(self):
        print("\n--- Testing Cafeteria Operations ---")
        student = self.login_as('aarav.student@fretbox.internal')

        # Check student menu
        res = self.client.get('/cafeteria/menu')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Campus Dining & Cafeteria', res.data)

        # Place order
        with self.app.app_context():
            item = CafeteriaItem.query.filter_by(is_available=True).first()
            item_id = item.id if item else 1

        res = self.client.post('/cafeteria/order', data={
            f'qty_{item_id}': '2',
            'special_instructions': 'Extra spicy'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # Get latest order
        with self.app.app_context():
            order = CafeteriaOrder.query.filter_by(student_id=student.id).order_by(CafeteriaOrder.id.desc()).first()
            self.assertIsNotNone(order)
            self.assertIsNotNone(order.order_token)
            order_id = order.id

        # RBAC: student cannot access cafeteria staff dashboard
        res = self.client.get('/cafeteria/dashboard')
        self.assertEqual(res.status_code, 403)

        # Staff can update order status
        self.login_as('cafeteria.staff@fretbox.internal')
        res = self.client.get('/cafeteria/dashboard')
        self.assertEqual(res.status_code, 200)

        # Update order to 'preparing' then 'ready'
        res = self.client.post(f'/cafeteria/order/{order_id}/status', data={'status': 'preparing'}, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        with self.app.app_context():
            order = CafeteriaOrder.query.get(order_id)
            self.assertEqual(order.status, 'preparing')

        # Toggle item availability
        res = self.client.post(f'/cafeteria/item/{item_id}/toggle-stock', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        print("[PASS] Cafeteria Operations verified successfully.")

    # =========================================================================
    # 5. Spec D: Cyber Cafe Terminals & Priority Queues
    # =========================================================================
    def test_05_cyber_cafe(self):
        print("\n--- Testing Cyber Cafe Terminals ---")
        student = self.login_as('aarav.student@fretbox.internal')

        # Student cyber cafe portal
        res = self.client.get('/cyber-cafe/portal')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Student IT & Printing Center', res.data)

        # Book a terminal slot
        tomorrow = (date.today() + timedelta(days=1)).strftime('%Y-%m-%d')
        res = self.client.post('/cyber-cafe/book-slot', data={
            'booking_date': tomorrow,
            'time_slot': '14:00 - 15:00',
            'terminal_type': 'standard',
            'purpose': 'Assignment research'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # RBAC: student cannot view cyber cafe staff dashboard
        res = self.client.get('/cyber-cafe/dashboard')
        self.assertEqual(res.status_code, 403)

        # Staff dashboard
        self.login_as('cybercafe.staff@fretbox.internal')
        res = self.client.get('/cyber-cafe/dashboard')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Cyber Cafe & Printing Services', res.data)
        print("[PASS] Cyber Cafe Terminals verified successfully.")

    # =========================================================================
    # 6. Spec E: Central Library & Dues/Fine Engine
    # =========================================================================
    def test_06_library_operations(self):
        print("\n--- Testing Library Operations ---")
        student = self.login_as('aarav.student@fretbox.internal')

        # Student catalog
        res = self.client.get('/library/catalog')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'University Library Catalog', res.data)

        # Reserve book
        with self.app.app_context():
            book = LibraryBook.query.filter(LibraryBook.available_copies > 0).first()
            self.assertIsNotNone(book)
            book_id = book.id

        res = self.client.post(f'/library/reserve/{book_id}', follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # RBAC: student cannot access librarian dashboard
        res = self.client.get('/library/dashboard')
        self.assertEqual(res.status_code, 403)

        # Librarian dashboard
        self.login_as('librarian.staff@fretbox.internal')
        res = self.client.get('/library/dashboard')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Central Library & Archives Desk', res.data)
        print("[PASS] Library Operations verified successfully.")

    # =========================================================================
    # 7. Spec F: Events & Sports Scoreboard
    # =========================================================================
    def test_07_events_and_sports(self):
        print("\n--- Testing Events & Sports Scoreboard ---")
        student = self.login_as('aarav.student@fretbox.internal')

        # Events index
        res = self.client.get('/events/')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Campus Events & Sports Arena', res.data)

        # Test live score polling endpoint
        res = self.client.get('/events/api/live-scores')
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.content_type, 'application/json')
        data = res.get_json()
        self.assertTrue(data.get('success'))
        self.assertIn('matches', data)

        # Register for an event
        with self.app.app_context():
            evt = CampusEvent.query.filter_by(is_active=True).first()
            evt_id = evt.id if evt else 1

        res = self.client.post(f'/events/register/{evt_id}', data={'notes': 'Enthusiastic participant'}, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # RBAC: student cannot access event coordinator dashboard
        res = self.client.get('/events/dashboard')
        self.assertEqual(res.status_code, 403)

        # Event coordinator access
        self.login_as('event.coord@fretbox.internal')
        res = self.client.get('/events/dashboard')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Campus Events & Sports Coordinator', res.data)
        print("[PASS] Events & Sports verified successfully.")

    # =========================================================================
    # 8. Spec G: Depression Index & Counselor Desk
    # =========================================================================
    def test_08_wellbeing_and_counselor(self):
        print("\n--- Testing Depression Index & Counselor Desk ---")
        student = self.login_as('aarav.student@fretbox.internal')

        # Student confidential check-in
        res = self.client.get('/counselor/checkin')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'How are you doing today?', res.data)

        res = self.client.post('/counselor/checkin', data={
            'stress_level': '3',
            'overwhelmed': 'no',
            'sleep_hours': '7.5',
            'thoughts': 'Feeling okay, keeping up with course load.'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # Test RBAC: student CANNOT access counselor dashboard or case profile
        res = self.client.get('/counselor/dashboard')
        self.assertEqual(res.status_code, 403)

        res = self.client.get(f'/counselor/student/{student.id}')
        self.assertEqual(res.status_code, 403)

        # Counselor logs in
        self.login_as('counselor.staff@fretbox.internal')
        res = self.client.get('/counselor/dashboard')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Student Wellbeing & Depression Index', res.data)

        # Check confidential audit log was registered
        with self.app.app_context():
            audit = AuditLog.query.filter_by(entity_type='mental_health_records', action='counselor_access').first()
            self.assertIsNotNone(audit)

        # View student case file
        res = self.client.get(f'/counselor/student/{student.id}')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Case File:', res.data)

        # Add session note
        tomorrow = (date.today() + timedelta(days=7)).strftime('%Y-%m-%d')
        res = self.client.post(f'/counselor/session/{student.id}', data={
            'observations': 'Student is actively adapting to new semester.',
            'action_plan': 'Maintain sleep routine; follow up in one week.',
            'follow_up_date': tomorrow
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        print("[PASS] Wellbeing & Counselor Desk verified successfully.")

    # =========================================================================
    # 9. Spec H: Caretaker, Superintendent Room Review & Faculty Assignments
    # =========================================================================
    def test_09_caretaker_and_superintendent(self):
        print("\n--- Testing Caretaker, Superintendent Room Review & Assignments ---")
        student = self.login_as('aarav.student@fretbox.internal')

        # Student assignments view
        res = self.client.get('/student/assignments')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Course Assignments & Submissions', res.data)

        # RBAC: student cannot access caretaker dashboard
        res = self.client.get('/caretaker/dashboard')
        self.assertEqual(res.status_code, 403)

        # Caretaker dashboard access
        self.login_as('caretaker.staff@fretbox.internal')
        res = self.client.get('/caretaker/dashboard')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Hostel Caretaker Night Operations', res.data)

        # Submit night attendance
        res = self.client.post('/caretaker/night-attendance', data={
            'hostel_name': 'Himalaya Boys Hostel',
            f'status_{student.id}': 'present',
            f'remarks_{student.id}': 'Checked at 10 PM'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)

        # Superintendent room review view: /admin/room/<hostel>/<room>
        self.login_as('superintendent.staff@fretbox.internal')
        res = self.client.get('/admin/room/Himalaya Boys Hostel/B-201')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Room B-201', res.data)
        self.assertIn(b'Room Members', res.data)
        self.assertIn(b'Complaints Status', res.data)
        self.assertIn(b'Gate-Pass Requests', res.data)
        print("[PASS] Caretaker & Superintendent Room Review verified successfully.")

    # =========================================================================
    # 10. Spec I: Communities & Discussions
    # =========================================================================
    def test_10_communities(self):
        print("\n--- Testing Communities ---")
        student = self.login_as('aarav.student@fretbox.internal')

        # Communities index
        res = self.client.get('/communities/')
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Campus Communities & Clubs', res.data)

        # Post in first community
        with self.app.app_context():
            comm = Community.query.first()
            self.assertIsNotNone(comm)
            comm_id = comm.id

        res = self.client.post(f'/communities/{comm_id}/post', data={
            'title': 'Hackathon Team Formation',
            'content': 'Looking for 2 frontend developers to build with Flask and Tailwind/Vanilla CSS!'
        }, follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        self.assertIn(b'Hackathon Team Formation', res.data)
        print("[PASS] Communities verified successfully.")

    # =========================================================================
    # 11. i18n & Theme Integrity
    # =========================================================================
    def test_11_i18n_and_theme(self):
        print("\n--- Testing i18n & Theme ---")
        res = self.client.get('/?lang=hi', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        with self.client.session_transaction() as sess:
            self.assertEqual(sess.get('locale'), 'hi')

        res = self.client.get('/?lang=en', follow_redirects=True)
        self.assertEqual(res.status_code, 200)
        with self.client.session_transaction() as sess:
            self.assertEqual(sess.get('locale'), 'en')
        print("[PASS] i18n & Theme verified successfully.")


if __name__ == '__main__':
    unittest.main()
