// ABHYURTI Campus OS - Client Logic, Theme Manager & Realtime Poller
document.addEventListener('DOMContentLoaded', () => {
  // Theme Manager
  const themeToggleBtn = document.getElementById('theme-toggle-btn');

  function getEffectiveTheme() {
    const saved = localStorage.getItem('abhyurti_theme') || localStorage.getItem('fretbox_theme');
    if (saved === 'dark' || saved === 'light') return saved;
    return (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) ? 'dark' : 'light';
  }

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    if (themeToggleBtn) {
      themeToggleBtn.setAttribute('aria-pressed', theme === 'dark' ? 'true' : 'false');
      themeToggleBtn.setAttribute('aria-label', theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
      themeToggleBtn.innerHTML = theme === 'dark' ? '<i class="bi bi-sun-fill" style="color: #FFD166;"></i>' : '<i class="bi bi-moon-stars"></i>';
    }
  }

  // Initial apply
  applyTheme(getEffectiveTheme());

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') || getEffectiveTheme();
      const nextTheme = current === 'dark' ? 'light' : 'dark';
      localStorage.setItem('abhyurti_theme', nextTheme);
      localStorage.setItem('fretbox_theme', nextTheme);
      applyTheme(nextTheme);
    });
  }

  // Listen for system theme changes if user has not set a preference
  if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
      if (!localStorage.getItem('abhyurti_theme') && !localStorage.getItem('fretbox_theme')) {
        applyTheme(e.matches ? 'dark' : 'light');
      }
    });
  }

  // Language Switcher Dropdown
  const langBtn = document.getElementById('lang-dropdown-btn');
  const langMenu = document.getElementById('lang-dropdown-menu');
  if (langBtn && langMenu) {
    langBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      langMenu.classList.toggle('show');
    });

    document.addEventListener('click', (e) => {
      if (!langMenu.contains(e.target) && e.target !== langBtn) {
        langMenu.classList.remove('show');
      }
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        langMenu.classList.remove('show');
      }
    });
  }

  // Flash message dismiss
  setTimeout(() => {
    document.querySelectorAll('.alert-dismissible').forEach(el => {
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 300);
    });
  }, 5000);

  // Background badge poller (lightweight: checks every 60s)
  function pollBadges() {
    fetch('/api/unread-count')
      .then(res => res.json())
      .then(data => {
        const noticeBadge = document.getElementById('nav-unread-badge');
        if (noticeBadge) {
          if (data.unread_notices > 0) {
            // Strictly Latin digits
            noticeBadge.textContent = String(data.unread_notices);
            noticeBadge.style.display = 'inline-flex';
          } else {
            noticeBadge.style.display = 'none';
          }
        }

        const emergencyBadge = document.getElementById('admin-emergency-badge');
        if (emergencyBadge) {
          if (data.emergency_passes > 0) {
            // Strictly Latin digits
            emergencyBadge.textContent = String(data.emergency_passes);
            emergencyBadge.style.display = 'inline-flex';
          } else {
            emergencyBadge.style.display = 'none';
          }
        }
      })
      .catch(() => {});
  }

  setInterval(pollBadges, 60000);
});
