// ABHYURTI Camera & Media Capture Handler
// Supports: Live WebCam stream capture, Mobile native camera capture, and Storage file picking

class AbhyurtiCamera {
  constructor(options = {}) {
    this.videoEl = document.getElementById(options.videoId || 'camera-video');
    this.previewBox = document.getElementById(options.previewBoxId || 'camera-preview-box');
    this.thumbnailEl = document.getElementById(options.thumbnailId || 'captured-thumbnail');
    this.hiddenDataInput = document.getElementById(options.dataInputId || 'photo_camera_data');
    this.fileInput = document.getElementById(options.fileInputId || 'photo_file');
    this.nativeCameraInput = document.getElementById(options.nativeCameraInputId || 'photo_camera');
    
    this.btnStart = document.getElementById(options.btnStartId || 'btn-start-camera');
    this.btnSnap = document.getElementById(options.btnSnapId || 'btn-snap-photo');
    this.btnRetake = document.getElementById(options.btnRetakeId || 'btn-retake-photo');
    this.mediaStream = null;

    this.init();
  }

  init() {
    if (this.btnStart) {
      this.btnStart.addEventListener('click', () => this.startLiveCamera());
    }

    if (this.btnSnap) {
      this.btnSnap.addEventListener('click', () => this.captureSnapshot());
    }

    if (this.btnRetake) {
      this.btnRetake.addEventListener('click', () => this.resetCapture());
    }

    // Storage file input change listener
    if (this.fileInput) {
      this.fileInput.addEventListener('change', (e) => this.handleFileSelection(e));
    }

    // Native mobile camera input listener
    if (this.nativeCameraInput) {
      this.nativeCameraInput.addEventListener('change', (e) => this.handleFileSelection(e));
    }
  }

  async startLiveCamera() {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        this.mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: 'environment' } },
          audio: false
        });
        if (this.videoEl) {
          this.videoEl.srcObject = this.mediaStream;
          this.videoEl.play();
        }
        if (this.previewBox) this.previewBox.style.display = 'block';
        if (this.btnStart) this.btnStart.style.display = 'none';
        if (this.btnSnap) this.btnSnap.style.display = 'inline-flex';
        if (this.thumbnailEl) this.thumbnailEl.style.display = 'none';
      } else {
        alert("Live webcam capture not supported on this browser. Falling back to native camera picker.");
        if (this.nativeCameraInput) this.nativeCameraInput.click();
      }
    } catch (err) {
      console.warn("Camera access error:", err);
      alert("Unable to access camera directly. Please choose a file or use native camera.");
      if (this.nativeCameraInput) this.nativeCameraInput.click();
    }
  }

  captureSnapshot() {
    if (!this.videoEl || !this.mediaStream) return;

    const canvas = document.createElement('canvas');
    canvas.width = this.videoEl.videoWidth || 640;
    canvas.height = this.videoEl.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(this.videoEl, 0, 0, canvas.width, canvas.height);

    const base64Jpg = canvas.toDataURL('image/jpeg', 0.85);

    // Save to hidden input
    if (this.hiddenDataInput) {
      this.hiddenDataInput.value = base64Jpg;
    }

    // Show thumbnail
    if (this.thumbnailEl) {
      this.thumbnailEl.src = base64Jpg;
      this.thumbnailEl.style.display = 'block';
    }

    // Stop live camera stream
    this.stopStream();
    if (this.previewBox) this.previewBox.style.display = 'none';
    if (this.btnSnap) this.btnSnap.style.display = 'none';
    if (this.btnRetake) this.btnRetake.style.display = 'inline-flex';
  }

  handleFileSelection(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;

    this.stopStream();
    if (this.previewBox) this.previewBox.style.display = 'none';
    if (this.btnStart) this.btnStart.style.display = 'inline-flex';
    if (this.btnSnap) this.btnSnap.style.display = 'none';

    // Clear base64 data to prioritize uploaded file
    if (this.hiddenDataInput) this.hiddenDataInput.value = '';

    const reader = new FileReader();
    reader.onload = (e) => {
      if (this.thumbnailEl) {
        this.thumbnailEl.src = e.target.result;
        this.thumbnailEl.style.display = 'block';
      }
      if (this.btnRetake) this.btnRetake.style.display = 'inline-flex';
    };
    reader.readAsDataURL(file);
  }

  resetCapture() {
    this.stopStream();
    if (this.hiddenDataInput) this.hiddenDataInput.value = '';
    if (this.fileInput) this.fileInput.value = '';
    if (this.nativeCameraInput) this.nativeCameraInput.value = '';
    if (this.thumbnailEl) {
      this.thumbnailEl.src = '';
      this.thumbnailEl.style.display = 'none';
    }
    if (this.btnRetake) this.btnRetake.style.display = 'none';
    if (this.btnStart) this.btnStart.style.display = 'inline-flex';
    if (this.previewBox) this.previewBox.style.display = 'none';
  }

  stopStream() {
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }
  }
}

document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('camera-preview-box') || document.getElementById('btn-start-camera')) {
    window.abhyurtiCam = window.fretboxCam = new AbhyurtiCamera();
  }
});
