// Firebase Cloud Messaging (FCM) Background Service Worker
importScripts('https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.22.0/firebase-messaging-compat.js');

// Initialize Firebase in worker with fallback defaults
firebase.initializeApp({
  apiKey: "AIzaSy_FretboxDefault",
  authDomain: "fretbox-campus.firebaseapp.com",
  projectId: "fretbox-campus",
  storageBucket: "fretbox-campus.appspot.com",
  messagingSenderId: "1234567890",
  appId: "1:1234567890:web:abcdef"
});

const messaging = firebase.messaging();

// Handle background notifications
messaging.onBackgroundMessage((payload) => {
  console.log('[FCM SW] Received background message:', payload);
  const notificationTitle = payload.notification.title || 'ABHYURTI Campus Alert';
  const notificationOptions = {
    body: payload.notification.body || 'New campus update.',
    icon: '/static/img/icon-192.png',
    badge: '/static/img/badge-72.png',
    data: payload.data || {}
  };

  self.registration.showNotification(notificationTitle, notificationOptions);
});
