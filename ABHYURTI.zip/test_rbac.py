import time
import re
from datetime import datetime, timedelta
from app import create_app
from app.extensions import db
from app.models import (
    User, Role, Permission, StudentProfile, StaffProfile,
    OTPVerification, UserSession, ApprovalRequest, Notification, AuditLog,
    MaintenanceTicket, Complaint, GatePass, LeaveRequest, DocumentRequest
)
from app.utils.security import generate_numeric_otp, hash_otp, verify_otp

def run_rbac_test_suite():
    print("\n" + "="*70)
    print("STARTING FRETBOX CAMPUS OS - HARDENED RBAC & SECURITY VERIFICATION SUITE")
    print("="*70)

    app = create_app()
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False  # Disabled by default for standard tests; enabled in explicit CSRF test
    app.config['RATELIMIT_ENABLED'] = False # Limiter tested separately
    client = app.test_client()

    with app.app_context():
        # Clean state for testing
        print("\n[FIXTURES] Initializing test roles and permissions...")
        db.create_all()
        roles_data = [
            ('student', 'Student'),
            ('faculty', 'Faculty / Teacher'),
            ('warden', 'Hostel Warden'),
            ('mess_manager', 'Mess Manager'),
            ('maintenance', 'Maintenance Staff'),
            ('office_staff', 'Office / Admin Staff'),
            ('super_admin', 'Super Admin')
        ]
        for r_name, r_disp in roles_data:
            if not Role.query.filter_by(name=r_name).first():
                db.session.add(Role(name=r_name, display_name=r_disp, is_system_role=True))
        db.session.commit()

        # Helper to generate unique identifiers
        ts = int(time.time() * 1000) % 10000000

        # =========================================================
        # 1. TEST OLD DEMO ROUTES RETURN 404
        # =========================================================
        print("\n[TEST 1] Old Demo Auth Bypass Routes Return 404")
        demo_roles = ['student', 'faculty', 'warden', 'mess_manager', 'maintenance', 'office_staff', 'super_admin', 'admin']
        for r in demo_roles:
            res = client.get(f'/quick-login/{r}')
            assert res.status_code == 404, f"Expected 404 for /quick-login/{r}, got {res.status_code}"
        print(" [PASS] All /quick-login/<role> routes return 404 Not Found")

        # =========================================================
        # 2. TEST ROLE TAMPERING: REGISTERING WITH role=admin STILL CREATES STUDENT
        # =========================================================
        print("\n[TEST 2] Public Registration Role Tampering Defense")
        tamper_email = f"tamper_{ts}@campus.edu"
        tamper_phone = f"98765{ts % 100000:05d}"
        tamper_roll = f"TAMP{ts % 10000:04d}"

        res = client.post('/register', data={
            'role': 'super_admin',
            'user_type': 'admin',
            'requested_role': 'admin',
            'name': 'Hacker Bob',
            'email': tamper_email,
            'phone': tamper_phone,
            'roll_number': tamper_roll,
            'branch': 'CSE',
            'year': 2,
            'semester': 3,
            'hostel': 'Hostel A',
            'room': '101',
            'password': 'StrongPassword2026',
            'confirm_password': 'StrongPassword2026'
        }, follow_redirects=False)

        assert res.status_code == 302, f"Expected 302 redirect after registration, got {res.status_code}"
        assert '/login' in res.headers.get('Location', '')

        # Verify in database that role is forced to student
        user_created = User.query.filter_by(email=tamper_email).first()
        assert user_created is not None, "Registered user not found in database"
        assert user_created.role == 'student', f"Role must be forced to 'student', got '{user_created.role}'"
        assert user_created.primary_role == 'student', f"Primary role must be 'student', got '{user_created.primary_role}'"
        assert not user_created.has_role('super_admin', 'admin'), "User must NOT have administrative role"
        print(" [PASS] Server strictly forces role='student' ignoring form payload role/user_type")

        # =========================================================
        # 3. TEST STUDENT GETS 403 ON ADMINISTRATIVE AND STAFF ROUTES
        # =========================================================
        print("\n[TEST 3] Role-Based Access Control: Student Access Forbidden (403)")
        # Log in as the student
        login_res = client.post('/login', data={
            'identifier': tamper_email,
            'password': 'StrongPassword2026'
        }, follow_redirects=True)
        assert login_res.status_code == 200

        restricted_routes = [
            '/super-admin/',
            '/super-admin/users',
            '/admin/',
            '/admin/complaints',
            '/admin/gate-passes',
            '/faculty/',
            '/mess-manager/',
            '/maintenance/',
            '/office/'
        ]
        for route in restricted_routes:
            res = client.get(route)
            assert res.status_code == 403, f"Expected 403 Forbidden for student accessing {route}, got {res.status_code}"
        client.post('/logout')
        print(" [PASS] Student receives HTTP 403 Forbidden on all administrative and staff routes")

        # =========================================================
        # 4. TEST IDOR DEFENSE: STUDENT A CANNOT ACCESS STUDENT B DATA
        # =========================================================
        print("\n[TEST 4] Insecure Direct Object Reference (IDOR) Defense")
        # Create Student A
        email_a = f"student_a_{ts}@campus.edu"
        phone_a = f"98111{ts % 100000:05d}"
        roll_a = f"ROLA{ts % 10000:04d}"
        user_a = User(name="Student A", email=email_a, phone=phone_a, roll_number=roll_a, role='student', status='active')
        user_a.set_password('PassA1234')
        user_a.roles.append(Role.query.filter_by(name='student').first())
        db.session.add(user_a)
        db.session.flush()

        # Create Student B
        email_b = f"student_b_{ts}@campus.edu"
        phone_b = f"98222{ts % 100000:05d}"
        roll_b = f"ROLB{ts % 10000:04d}"
        user_b = User(name="Student B", email=email_b, phone=phone_b, roll_number=roll_b, role='student', status='active')
        user_b.set_password('PassB1234')
        user_b.roles.append(Role.query.filter_by(name='student').first())
        db.session.add(user_b)
        db.session.flush()

        # Create a private complaint and gate pass belonging to Student B
        complaint_b = Complaint(
            student_id=user_b.id,
            category='cat_plumbing',
            hostel='Hostel B',
            room='305',
            description='Private medical issue in room'
        )
        gate_pass_b = GatePass(
            student_id=user_b.id,
            destination='Confidential Clinic',
            reason='Confidential Medical Examination',
            from_date=datetime.utcnow(),
            to_date=datetime.utcnow() + timedelta(days=1)
        )
        db.session.add(complaint_b)
        db.session.add(gate_pass_b)
        db.session.commit()

        # Sign in as Student A and attempt to access Student B's complaint and gate pass
        client.post('/login', data={'identifier': email_a, 'password': 'PassA1234'}, follow_redirects=True)

        res_comp = client.get(f'/complaints/{complaint_b.id}')
        assert res_comp.status_code == 404, f"IDOR Vulnerability! Student A accessed Student B's complaint: {res_comp.status_code}"

        res_gp = client.get(f'/gate-pass/{gate_pass_b.id}')
        assert res_gp.status_code == 404, f"IDOR Vulnerability! Student A accessed Student B's gate pass: {res_gp.status_code}"

        client.post('/logout')
        print(" [PASS] Scoped database queries prevent IDOR: Student A receives 404 attempting to inspect Student B's records")

        # =========================================================
        # 5. TEST DUPLICATE ROLL NUMBER, MOBILE, AND EMAIL REJECTION
        # =========================================================
        print("\n[TEST 5] Duplicate Roll Number, Mobile, and Email Validation")
        # 5a. Duplicate Email
        res = client.post('/register', data={
            'name': 'Duplicate Email Tester',
            'email': email_a,
            'phone': f"98333{ts % 100000:05d}",
            'roll_number': f"DIFF{ts % 10000:04d}",
            'password': 'ValidPass123',
            'confirm_password': 'ValidPass123'
        }, follow_redirects=True)
        assert b"already exists" in res.data.lower()

        # 5b. Duplicate Phone
        res = client.post('/register', data={
            'name': 'Duplicate Phone Tester',
            'email': f"diff_{ts}@campus.edu",
            'phone': phone_a,
            'roll_number': f"DIF2{ts % 10000:04d}",
            'password': 'ValidPass123',
            'confirm_password': 'ValidPass123'
        }, follow_redirects=True)
        assert b"already exists" in res.data.lower()

        # 5c. Duplicate Roll Number
        res = client.post('/register', data={
            'name': 'Duplicate Roll Tester',
            'email': f"diff2_{ts}@campus.edu",
            'phone': f"98444{ts % 100000:05d}",
            'roll_number': roll_a,
            'password': 'ValidPass123',
            'confirm_password': 'ValidPass123'
        }, follow_redirects=True)
        assert b"already exists" in res.data.lower()
        print(" [PASS] Duplicate email, phone number, and student roll number are rejected")

        # =========================================================
        # 6. TEST CSRF PROTECTION: REJECT POST WITHOUT CSRF TOKEN
        # =========================================================
        print("\n[TEST 6] Cross-Site Request Forgery (CSRF) Defense")
        csrf_app = create_app()
        csrf_app.config['TESTING'] = True
        csrf_app.config['WTF_CSRF_ENABLED'] = True  # Explicitly enforce CSRF
        csrf_client = csrf_app.test_client()

        # Attempt POST to /login without CSRF token
        csrf_res = csrf_client.post('/login', data={
            'identifier': email_a,
            'password': 'PassA1234'
        })
        assert csrf_res.status_code == 400, f"Expected 400 Bad Request for missing CSRF token, got {csrf_res.status_code}"
        print(" [PASS] POST without CSRF token is rejected with HTTP 400 Bad Request")

        # =========================================================
        # 7. TEST UNAUTHENTICATED USERS REDIRECTED TO LOGIN
        # =========================================================
        print("\n[TEST 7] Authentication Guard: Unauthenticated Redirections")
        anon_client = app.test_client()
        protected_urls = ['/timeline', '/complaints', '/gate-pass', '/profile', '/super-admin/']
        for url in protected_urls:
            res = anon_client.get(url, follow_redirects=False)
            assert res.status_code == 302, f"Expected 302 redirect for unauthenticated access to {url}, got {res.status_code}"
            assert '/login' in res.headers.get('Location', '')
        print(" [PASS] Unauthenticated access to protected routes redirected to /login")

        # =========================================================
        # 8. TEST GENERIC LOGIN ERROR PREVENTS USER ENUMERATION
        # =========================================================
        print("\n[TEST 8] Generic Login Error (Anti-Account Enumeration)")
        # 8a. Non-existent account
        res_nonexistent = client.post('/login', data={
            'identifier': 'ghost_user_9999999@notfound.edu',
            'password': 'AnyPassword123'
        }, follow_redirects=True)
        assert b"Invalid credentials." in res_nonexistent.data

        # 8b. Real account, wrong password
        res_wrongpass = client.post('/login', data={
            'identifier': email_a,
            'password': 'TotallyWrongPassword999'
        }, follow_redirects=True)
        assert b"Invalid credentials." in res_wrongpass.data

        # Verify exact same error string for both cases
        assert b"Invalid credentials." in res_nonexistent.data and b"Invalid credentials." in res_wrongpass.data
        print(" [PASS] Generic 'Invalid credentials.' displayed for both non-existent users and wrong passwords")

        # =========================================================
        # 9. TEST INDIAN MOBILE FORMAT & PASSWORD COMPLEXITY
        # =========================================================
        print("\n[TEST 9] Server-Side Input Validation: Indian Mobile & Password Complexity")
        # 9a. Invalid Mobile (starts with 1)
        res_bad_phone = client.post('/register', data={
            'name': 'Bad Phone User',
            'email': f"badphone_{ts}@campus.edu",
            'phone': '1234567890',
            'roll_number': f"BP{ts % 10000:04d}",
            'password': 'ValidPassword123',
            'confirm_password': 'ValidPassword123'
        }, follow_redirects=True)
        assert b"valid 10-digit indian mobile" in res_bad_phone.data.lower()

        # 9b. Weak Password (< 8 chars)
        res_short_pass = client.post('/register', data={
            'name': 'Short Pass User',
            'email': f"shortpass_{ts}@campus.edu",
            'phone': f"98555{ts % 100000:05d}",
            'roll_number': f"SP{ts % 10000:04d}",
            'password': 'Abc1',
            'confirm_password': 'Abc1'
        }, follow_redirects=True)
        assert b"at least 8 characters" in res_short_pass.data.lower()

        # 9c. Weak Password (letters only, no digit)
        res_letters_only = client.post('/register', data={
            'name': 'No Digits User',
            'email': f"nodigits_{ts}@campus.edu",
            'phone': f"98666{ts % 100000:05d}",
            'roll_number': f"ND{ts % 10000:04d}",
            'password': 'LettersOnlyPassword',
            'confirm_password': 'LettersOnlyPassword'
        }, follow_redirects=True)
        assert b"both letters and numbers" in res_letters_only.data.lower()
        print(" [PASS] Server strictly validates Indian mobile numbers and password complexity")

        # =========================================================
        # 10. TEST DATA PRIVACY CACHE HEADERS (NO-STORE ON AUTHENTICATED PAGES)
        # =========================================================
        print("\n[TEST 10] Session & Cache Headers Privacy")
        # Login
        client.post('/login', data={'identifier': email_a, 'password': 'PassA1234'})
        auth_resp = client.get('/timeline')
        assert 'no-store' in auth_resp.headers.get('Cache-Control', '').lower(), "Cache-Control header missing 'no-store'"
        assert 'private' in auth_resp.headers.get('Cache-Control', '').lower(), "Cache-Control header missing 'private'"
        client.post('/logout')
        print(" [PASS] Authenticated responses include 'Cache-Control: no-store, no-cache, must-revalidate, private'")

        # =========================================================
        # 11. TEST LOGOUT VIA POST & FULL SESSION CLEARANCE
        # =========================================================
        print("\n[TEST 11] POST Logout & Full Session Termination")
        client.post('/login', data={'identifier': email_a, 'password': 'PassA1234'})
        # Perform POST logout
        logout_res = client.post('/logout', follow_redirects=False)
        assert logout_res.status_code == 302
        assert '/login' in logout_res.headers.get('Location', '')
        # Verify subsequent access is unauthenticated
        after_logout = client.get('/timeline', follow_redirects=False)
        assert after_logout.status_code == 302, "Session not cleared after logout"
        print(" [PASS] POST /logout terminates user session and clears cookies")

        # =========================================================
        # 12. TEST SUPER ADMIN CREATES STAFF ACCOUNT (FORCED PASSWORD CHANGE)
        # =========================================================
        print("\n[TEST 12] Super Admin Staff Account Creation")
        # Create Super Admin
        sa_email = f"superadmin_{ts}@campus.edu"
        sa = User(name="Super Admin", email=sa_email, phone=f"98777{ts % 100000:05d}", role='super_admin', status='active')
        sa.set_password('AdminMaster2026')
        sa.roles.append(Role.query.filter_by(name='super_admin').first())
        db.session.add(sa)
        db.session.commit()

        client.post('/login', data={'identifier': sa_email, 'password': 'AdminMaster2026'})

        staff_email = f"warden_new_{ts}@campus.edu"
        staff_res = client.post('/super-admin/users/create-staff', data={
            'name': 'Warden Ramesh',
            'email': staff_email,
            'phone': f"98888{ts % 100000:05d}",
            'role_name': 'warden',
            'employee_id': f"WRD-{ts % 10000}",
            'department': 'Hostel Administration',
            'assigned_hostel': 'Hostel A',
            'temporary_password': 'TempPass2026'
        }, follow_redirects=True)
        assert staff_res.status_code == 200

        staff_created = User.query.filter_by(email=staff_email).first()
        assert staff_created is not None, "Staff user not created"
        assert staff_created.role == 'warden'
        assert staff_created.must_change_password is True, "Must change password flag should be set for staff"
        print(" [PASS] Super Admin successfully provisions staff account with forced password change on first login")

        # =========================================================
        # 13. TEST TEACHER / FACULTY PUBLIC REGISTRATION
        # =========================================================
        print("\n[TEST 13] Teacher / Faculty Self-Registration")
        client.post('/logout', follow_redirects=True)
        u_suffix = f"{int(time.time() * 1000) % 100000000}"
        teacher_email = f"prof_sharma_{u_suffix}@campus.edu"
        teacher_phone = f"981{u_suffix[-7:]}"
        teacher_emp_id = f"FAC-{u_suffix}"

        from app.models import PreApprovedEmployeeCode
        code_t = PreApprovedEmployeeCode(
            employee_code=teacher_emp_id,
            role='faculty',
            name='Prof. Sharma',
            department='CSE',
            status='unused'
        )
        db.session.add(code_t)
        db.session.commit()

        reg_teacher_res = client.post('/register', data={
            'role': 'faculty',
            'name': 'Prof. Sharma',
            'email': teacher_email,
            'phone': teacher_phone,
            'employee_id': teacher_emp_id,
            'department': 'CSE',
            'designation': 'Assistant Professor',
            'assigned_sections': 'CSE-3A, CSE-3B',
            'password': 'TeacherPass2026',
            'confirm_password': 'TeacherPass2026'
        }, follow_redirects=False)
        assert reg_teacher_res.status_code == 302, f"Expected 302, got {reg_teacher_res.status_code} with body: {reg_teacher_res.data.decode('utf-8')[:300]}"
        assert '/login' in reg_teacher_res.headers.get('Location', '')

        # Verify teacher user in DB with StaffProfile
        teacher_user = User.query.filter_by(email=teacher_email).first()
        assert teacher_user is not None, "Teacher user not found in database"
        assert teacher_user.role == 'faculty'
        assert teacher_user.has_role('faculty')
        assert teacher_user.staff_profile is not None
        assert teacher_user.staff_profile.employee_id == teacher_emp_id
        assert teacher_user.staff_profile.department == 'CSE'
        print(" [PASS] Teacher successfully registers as faculty with full StaffProfile")

        # =========================================================
        # 14. TEST TEACHER ROLE LOGIN & PRIVATE DASHBOARD ACCESS
        # =========================================================
        print("\n[TEST 14] Teacher Role-Based Login & Private Interface Access")
        # Log in choosing 'faculty' role with Employee ID
        login_teacher_res = client.post('/login', data={
            'selected_role': 'faculty',
            'identifier': teacher_emp_id,  # Login using Employee ID!
            'password': 'TeacherPass2026'
        }, follow_redirects=False)
        assert login_teacher_res.status_code == 302
        assert '/faculty' in login_teacher_res.headers.get('Location', ''), "Teacher must be redirected to /faculty/"

        # Follow into the private faculty dashboard
        fac_page = client.get('/faculty/', follow_redirects=True)
        assert fac_page.status_code == 200
        assert b"Prof. Sharma" in fac_page.data or b"Faculty" in fac_page.data
        print(" [PASS] Teacher logs in via Employee ID and enters private /faculty/ dashboard")

        # =========================================================
        # 15. TEST ROLE ISOLATION: STUDENT CANNOT LOGIN TO TEACHER PORTAL
        # =========================================================
        print("\n[TEST 15] Portal Role Isolation on Login")
        client.post('/logout', follow_redirects=True)
        # Attempt to log in with Student credentials but selecting 'faculty' portal
        mismatch_res = client.post('/login', data={
            'selected_role': 'faculty',
            'identifier': tamper_email,  # This was created as a student
            'password': 'StrongPassword2026'
        }, follow_redirects=True)
        assert mismatch_res.status_code == 200
        assert b"Access Denied" in mismatch_res.data
        assert b"Student" in mismatch_res.data
        print(" [PASS] Student account attempting to enter Teacher portal is cleanly blocked with Access Denied")

        # =========================================================
        # 16. TEST HOSTEL SUPERINTENDENT (WARDEN) & MANAGING STAFF REGISTRATION
        # =========================================================
        print("\n[TEST 16] Managing Staff & Superintendent Registration")
        u_suffix_w = f"{(int(time.time() * 1000) + 7) % 100000000}"
        warden_reg_email = f"warden_self_{u_suffix_w}@campus.edu"
        warden_reg_phone = f"982{u_suffix_w[-7:]}"
        warden_reg_emp = f"WRD-{u_suffix_w}"

        code_w = PreApprovedEmployeeCode(
            employee_code=warden_reg_emp,
            role='warden',
            name='Superintendent Verma',
            department='Hostel Administration',
            status='unused'
        )
        db.session.add(code_w)
        db.session.commit()

        reg_wrd_res = client.post('/register', data={
            'role': 'warden',
            'name': 'Superintendent Verma',
            'email': warden_reg_email,
            'phone': warden_reg_phone,
            'employee_id': warden_reg_emp,
            'assigned_hostel': 'Hostel B',
            'designation': 'Hostel Superintendent',
            'password': 'WardenPass2026',
            'confirm_password': 'WardenPass2026'
        }, follow_redirects=False)
        assert reg_wrd_res.status_code == 302
        assert '/login' in reg_wrd_res.headers.get('Location', '')

        warden_user = User.query.filter_by(email=warden_reg_email).first()
        assert warden_user is not None
        assert warden_user.role == 'warden'
        assert warden_user.staff_profile.assigned_hostel == 'Hostel B'

        # Login as warden with selected_role='warden'
        login_wrd_res = client.post('/login', data={
            'selected_role': 'warden',
            'identifier': warden_reg_email,
            'password': 'WardenPass2026'
        }, follow_redirects=False)
        assert login_wrd_res.status_code == 302
        assert '/admin' in login_wrd_res.headers.get('Location', ''), "Warden must be routed to /admin/"
        print(" [PASS] Hostel Superintendent registers and logs in directly to /admin/ private portal")

        # =========================================================
        # 17. TEST SECURE EMPLOYEE CODE VALIDATION & ROLE TAMPERING DEFENSE
        # =========================================================
        print("\n[TEST 17] Pre-Approved Employee Code Security & Role Tampering Defense")
        client.post('/logout', follow_redirects=True)
        ts_ec = int(time.time() * 1000) % 100000000

        # Sub-test 1: Staff registration without code -> Rejected
        res_no_code = client.post('/register', data={
            'role': 'faculty',
            'name': 'No Code Faculty',
            'email': f'nocode_{ts_ec}@campus.edu',
            'phone': f'983{ts_ec % 10000000:07d}',
            'password': 'SecurePass2026',
            'confirm_password': 'SecurePass2026'
        }, follow_redirects=True)
        assert res_no_code.status_code == 200
        assert b"Employee Code is required" in res_no_code.data
        print("   [17.1 PASS] Non-student registration without employee code is rejected")

        # Sub-test 2: Registration with invalid/fake code -> Rejected
        res_fake_code = client.post('/register', data={
            'role': 'faculty',
            'name': 'Fake Code Faculty',
            'email': f'fakecode_{ts_ec}@campus.edu',
            'phone': f'984{ts_ec % 10000000:07d}',
            'employee_code': 'EMP-FAKE-99999',
            'password': 'SecurePass2026',
            'confirm_password': 'SecurePass2026'
        }, follow_redirects=True)
        assert res_fake_code.status_code == 200
        assert b"Invalid Employee Code" in res_fake_code.data
        print("   [17.2 PASS] Non-student registration with invalid/fake code is rejected")

        # Sub-test 3: Seed an unused employee code for mess_manager
        mess_code_val = f"EMP-MESS-TEST-{ts_ec}"
        mess_code_rec = PreApprovedEmployeeCode(
            employee_code=mess_code_val,
            role='mess_manager',
            name='Test Mess Manager',
            status='unused'
        )
        db.session.add(mess_code_rec)
        db.session.commit()

        # Sub-test 4: Attempt role mismatch (use mess code to register as admin) -> Rejected
        res_mismatch = client.post('/register', data={
            'role': 'admin',
            'name': 'Mismatch Attacker',
            'email': f'mismatch_{ts_ec}@campus.edu',
            'phone': f'985{ts_ec % 10000000:07d}',
            'employee_code': mess_code_val,
            'password': 'SecurePass2026',
            'confirm_password': 'SecurePass2026'
        }, follow_redirects=True)
        assert res_mismatch.status_code == 200
        assert b"Role mismatch" in res_mismatch.data
        print("   [17.3 PASS] Registration with mismatched role code is rejected")

        # Sub-test 5: Register with correct role for the code -> Success
        mess_user_email = f'mess_valid_{ts_ec}@campus.edu'
        res_valid = client.post('/register', data={
            'role': 'mess_manager',
            'name': 'Valid Mess Manager',
            'email': mess_user_email,
            'phone': f'986{ts_ec % 10000000:07d}',
            'employee_code': mess_code_val,
            'password': 'SecurePass2026',
            'confirm_password': 'SecurePass2026'
        }, follow_redirects=False)
        assert res_valid.status_code == 302
        assert '/login' in res_valid.headers.get('Location', '')

        # Confirm code is now marked 'used' in the database
        db.session.expire_all()
        refreshed_code = PreApprovedEmployeeCode.query.filter_by(employee_code=mess_code_val).first()
        assert refreshed_code.status == 'used'
        assert refreshed_code.used_by_id is not None
        print("   [17.4 PASS] Registration with valid pre-approved code marks code as 'used'")

        # Sub-test 6: Attempt to reuse the already used employee code -> Rejected
        res_reuse = client.post('/register', data={
            'role': 'mess_manager',
            'name': 'Reuser Hacker',
            'email': f'reuse_{ts_ec}@campus.edu',
            'phone': f'987{ts_ec % 10000000:07d}',
            'employee_code': mess_code_val,
            'password': 'SecurePass2026',
            'confirm_password': 'SecurePass2026'
        }, follow_redirects=True)
        assert res_reuse.status_code == 200
        assert b"already been used" in res_reuse.data
        print("   [17.5 PASS] Attempting to re-use an already used employee code is strictly rejected")
        print(" [PASS] All Pre-Approved Employee Code validation and role enforcement rules verified")

    print("\n" + "="*70)
    print("ALL 17 RBAC, REGISTRATION & PORTAL ISOLATION TESTS PASSED!")
    print("="*70 + "\n")

if __name__ == '__main__':
    run_rbac_test_suite()

