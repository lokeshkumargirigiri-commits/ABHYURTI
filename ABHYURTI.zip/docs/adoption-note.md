# ABHYURTI Campus Operations: Campus Adoption & Scaling Strategy

## 1. Executive Summary & Problem Framing
The typical college campus suffers from extreme operational fragmentation—dubbed the **"Tuesday Story"**: a student spends an entire afternoon visiting four physical administrative offices (Hostel Warden, Estate Maintenance, Security Gate, and Department Notice Board) for routine requests that require zero discretionary human intervention.

ABHYURTI solves this with a mobile-first, low-friction operations layer combining:
1. **Hostel Complaints Triage** with photo evidence, auto-repeat detection, and ageing buckets.
2. **Emergency Gate Pass System** with enforceable 30-minute SLA countdowns and parent notification logging.
3. **Targeted Notice Broadcasts** with per-student read and action tracking, permanently eliminating WhatsApp noise.
4. **Self-Service Kiosk Fallback** for students without smartphones, dead batteries, or poor connectivity.

---

## 2. Phased Rollout Roadmap

### Phase 0: System Mapping & Audit (Weeks 1–2)
- **Roster & Directory Mapping**: Extract student cohort data from the existing University Registrar ERP into standard CSV format (Roll No, Name, Hostel, Room, Branch, Year, Phone).
- **Physical Register Audit**: Catalog legacy paper logbooks in Estate Maintenance and Hostel Warden desks.
- **Role Assignment**: Designate Hostel Wardens, Estate Supervisors, and General Campus Administrators.

### Phase 1: Single-Hostel Pilot (Weeks 3–4)
- **Pilot Scope**: Launch exclusively in **Hostel A (Boys)** covering 250 residents.
- **Core Workflow Focus**: Hostel Maintenance Complaints triage.
- **Warden Training**: Conduct a 30-minute training on sorting queues by age (0-3d, 4-7d, 8d+), assigning contractors, and logging resolution notes.
- **Physical QR Deployment**: Affix room QR code stickers inside rooms for 10-second inspection logging by floor wardens.

### Phase 2: Targeted Notices & Gate-Pass Rollout (Weeks 5–6)
- **Notice Board Migration**: Mandate that official hostel announcements (water cuts, electricity shutdowns, exam circulars) be published via ABHYURTI rather than unverified WhatsApp forwards.
- **Curfew & Gate Security**: Train main gate security guards on the **Kiosk Mode** and digital pass verification.
- **Emergency Gate Pass Activation**: Implement 30-minute SLA policy for medical leaves.

### Phase 3: Campus-Wide Scaling & ERP Integration (Weeks 7+)
- Onboard remaining hostel blocks (Hostel B, Hostel C, Faculty Quarters).
- Activate self-service Kiosks at the Student Affairs desk and Library foyer.
- Introduce breadth modules (Mess feedback, Biometric attendance sync, Bonafide certificates).

---

## 3. Data Migration & Legacy System Ingestion
- **Student Roster Import**: Using `python -m app.seed` or `app/utils/import_roster.py`, existing registrar Excel/CSV rosters are automatically ingested into the SQLAlchemy datastore.
- **Open Ticket Transition**: Outstanding complaints from physical registers are logged during Phase 1 with their backdated timestamps to establish baseline ageing metrics.

---

## 4. Production Architecture & Cloud Transition Path
While the prototype runs entirely offline with zero external cloud dependencies using **Flask + SQLite + Jinja2 SSR**, the system is architected for clean enterprise transition:

| Component | Prototype (v1) | Enterprise Production (v2) | Transition Complexity |
|---|---|---|---|
| **Database** | SQLite (`fretbox.db`) | Managed PostgreSQL (AWS RDS / GCP Cloud SQL) | **Zero-code**: SQLAlchemy connection string change |
| **Media Storage** | Local `static/uploads/` | AWS S3 / Cloudflare R2 / GCS bucket | Drop-in boto3 storage adapter |
| **App Server** | Flask dev server / Waitress | Gunicorn + Nginx reverse proxy in Docker | Containerized standard Dockerfile |
| **Authentication** | Flask-Login session cookies | College SAML / LDAP / Google Workspace SSO | Pluggable Flask auth middleware |
| **Parent Notifications** | Local console queue | Twilio / Exotel / Gupshup SMS Gateway | Webhook implementation in `app/api/` |

---

## 5. Overcoming Behavioral Inertia (Habit Change)
Campuses historically struggle to decommission WhatsApp groups. ABHYURTI ensures lasting adoption through three psychological triggers:
1. **Accountability & Status Timelines**: Students stop using WhatsApp because complaints sent on WhatsApp have no audit trail. On ABHYURTI, students see exact ageing badges (e.g. "8d old") and warden acknowledgments.
2. **Action Confirmation Loop**: Administrative circulars require explicit student confirmation buttons (e.g., *"I Acknowledge Water Cut Timings"*), giving wardens verifiable compliance lists before maintenance.
3. **No-Smartphone Guarantee**: The kiosk terminal ensures no student is excluded due to phone loss, low battery, or low data balances.
