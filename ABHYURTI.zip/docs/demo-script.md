# ABHYURTI Campus Operations: Official Demo Script (5–7 Minutes)

## Goal
Demonstrate how ABHYURTI replaces four administrative offices, fragmented paper diaries, and chaotic WhatsApp groups with 3 high-speed end-to-end workflows, an executive admin visibility dashboard with SLA timers, and a no-smartphone kiosk fallback.

---

## ⚡ Demo Quick Logins (1-Click Switchers)
Navigate to `http://localhost:5000/login` to use the instant 1-click login buttons:
- **Student Profile**: `student@demo.com` (Aarav Sharma - Hostel A, Room 204)
- **Hostel Warden Profile**: `warden@demo.com` (Ramesh Kumar - Hostel A Warden)
- **General Campus Admin**: `admin@demo.com` (Dr. Vikram Malhotra - Dean)
- Password for all accounts: `demo123`

---

## Step-by-Step Demo Flow

### 1. The Student Experience: Solving the "Tuesday Story" (2 Minutes)
1. **Login as Aarav Sharma**: Click the **"Student (Aarav)"** 1-click login button.
2. **Review Student Home Dashboard (`/`)**:
   - Point out the active KPI cards: Active Complaints, Active Gate Pass, Unread Targeted Notices.
   - Show the bottom navigation bar built for mobile-first thumb access.
3. **Workflow 1: Report a Maintenance Issue with Camera Support (`/complaints/new`)**:
   - Click **"Report Issue"**.
   - Show the dual photo capture options:
     - **Live Camera**: Click **"Live Camera Capture"** to open browser webcam stream with reticle and snap a real-time photo.
     - **Storage/File**: Pick an existing photo or choose from device gallery.
   - Select Category: `🚰 Plumbing & Water`.
   - Enter Room: `204`.
   - Notice the automatic **Repeat Issue detection banner**—because Room 204 had a previous plumbing complaint within 30 days!
   - Click **Submit Request**.
   - View the detailed status timeline stepper: *Submitted &rarr; Acknowledged &rarr; In Progress &rarr; Resolved*.
4. **Workflow 2: Emergency Gate-Pass with 30-Min SLA (`/gate-pass/new`)**:
   - Click **Gate Pass** &rarr; **Apply for Gate Pass**.
   - Check the **"🚨 Emergency Gate Pass"** checkbox.
   - Emphasize the narrative: *"It's 11:30 PM, a student has acute medical cramps. Instead of running across 3 warden quarters, they apply digitally with parent SMS notification."*
   - Enter Destination: `City Care Multi-Speciality Hospital`.
   - Click **Submit Request**. Show the digital pass card marked with the emergency pulse badge.
5. **Unified Student Activity Timeline (`/timeline`)**:
   - Click **Timeline** in the bottom navigation.
   - Highlight the single source of truth: unified chronological stream of complaints, gate-pass requests, and circulars in one scrollable feed.

---

### 2. The Administrator & Warden Control Room (2 Minutes)
1. **Switch to Warden Ramesh**: Click Logout &rarr; 1-Click **"Warden (Hostel A)"**.
2. **Admin Dashboard (`/admin`)**:
   - **Emergency SLA Monitor**: At the very top, observe the red emergency alert with the 30-minute SLA countdown and breach alert!
   - **Ageing Buckets**: Show the 3 triage buckets:
     - `0-3 Days (Fresh)`
     - `4-7 Days (Amber)`
     - `8+ Days (Critical Ageing)` &rarr; Contains the famous **9-day-old leaking tap ticket** from the Tuesday story!
   - Click on the **"8+ Days"** bucket to immediately filter the queue to overdue tickets.
   - Show the **Chart.js** Ageing Distribution and Category breakdown graphs.
3. **Approve Emergency Gate Pass in 1 Click (`/admin/gate-passes`)**:
   - Navigate to Gate Passes queue.
   - See the emergency pass for Aarav Sharma pinned at the top.
   - Click **Approve** in one click. Instant status transition and audit log entry recorded.
4. **Workflow 3: Targeted Circulars Broadcast (`/admin/notices/new`)**:
   - Click **Compose Notice**.
   - Type Title: *"3rd Year Campus Placement Interview Round 1"*.
   - Target filters: Select `Target Year: 3rd Year` and `Target Branch: CSE`.
   - Notice the **Live Audience Counter** in real-time updating to show exact matching students!
   - Click **Publish**. View the **Notice Read Funnel** displaying real-time Read % and Action confirmation %!
5. **Warden On-Floor QR Inspection (`/admin/room/Hostel A/204`)**:
   - Show the generated room QR code sticker for door mounting.
   - Shows all active complaints and repeat flags for that specific room.

---

### 3. Accessibility & Low-Bandwidth Layer (1–2 Minutes)
1. **Hindi Localization Toggle**:
   - Click the **"हिंदी"** language button in the top navigation.
   - Instantly observe all headers, status badges, forms, and bottom navigation labels translate seamlessly into Hindi.
2. **Kiosk Fallback Mode (`/kiosk`)**:
   - Navigate to `/kiosk` (simulate a tablet mounted at the hostel security desk).
   - Enter Roll Number: `2024CS101`, PIN: `1234`.
   - Student profile opens instantly without requiring any smartphone or cellular data.
   - Click **Submit Complaint** or **Apply Gate Pass**.
   - Show the generated **Printable Thermal Slip Receipt** (`/kiosk/receipt/...`) with barcode frame and signature lines ready for `@media print`!
3. **PWA & Offline Readiness**:
   - Show `manifest.json` and active service worker (`sw.js`).
   - Mention that server-side rendered HTML is under 35KB, loading smoothly on simulated **"Slow 3G"** networks.
