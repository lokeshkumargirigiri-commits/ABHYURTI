# Fretbox Campus OS — Decisions & Assumptions Log (DECISIONS.md)

This document records architectural, UX, and security decisions made during the Phase 1 build and Phase 2 verification.

---

## 1. Role System Architecture
- **Decision:** Maintain existing user roles (`student`, `admin`, `warden`, `faculty`, `mess_manager`, `maintenance`, `office_staff`, `super_admin`) and add new specialized roles:
  - `hod`: Head of Department view (examination, faculty assignments, attendance monitoring)
  - `account_staff`: Fees management, fee concessions, exportable collections ledger
  - `exam_staff`: Examination schedules, hall tickets, fee clearance checks
  - `cafeteria_staff`: Menu items, live stock toggle, order preparation pipeline
  - `cyber_cafe_staff`: Scholarship applications, computer terminal slots, Xerox/print request queue
  - `librarian`: Book catalog, fine ledger, separate student and faculty request queues
  - `event_coordinator`: Cultural/technical event registration, winner certificates
  - `sports_coordinator`: Annual sports day events, live score updates
  - `counselor`: Sensitive student wellbeing monitoring, strictly role-guarded session logs
  - `caretaker`: Night hostel roll-call attendance, hostel health emergency escalations
  - `superintendent`: Hostel room-level inspection, complaint tracking, student gate-pass approval
- **Assumption:** Each user has a primary role in `users.role`. Multi-role capabilities can be granted through permissions if needed, but primary routing directs them to their role-specific dashboard.

---

## 2. Hostel Superintendent Room Review (User Directive 1)
- **Directive:** Expand the existing `/admin/room/<hostel>/<room>` view. Do NOT create a separate Warden dashboard or duplicate page. Keep everything the existing page already shows, and ADD:
  1. Room members (all students currently assigned to this room).
  2. Complaints related to this room (separated into unresolved vs resolved).
  3. Gate-pass requests submitted by the room's students.
  4. Allow the Superintendent role to open this page and execute the gate-pass workflow (view request -> view reason -> approve/reject -> notify student).
  5. Preserve the Warden's access to this route unchanged.

---

## 3. Cryptographic Receipts for Fee Payments (Spec A & B)
- **Decision:** Fee receipts are signed with HMAC-SHA256 using the application's `SECRET_KEY`.
- **Token Structure:** An encrypted or cryptographically hashed token (`receipt_token`) is stored on each `FeePayment` record. A public verification route `/verify/receipt/<token>` allows anyone (e.g. via QR code or link) to verify the authenticity of the receipt (student name, roll number, amount paid, transaction ID, date, status) without requiring login.

---

## 4. Payment Gateway Integration
- **Directive:** Test/Mock mode only. No real payment gateways, charges, or banking credentials.
- **Decision:** A mock payment gateway simulation is built for both Tuition/Exam fees (`/student/fees/pay/<id>`) and Cafeteria orders (`/student/cafeteria/checkout`), supporting Simulated UPI, Simulated Netbanking, and Instant Mock Approval.

---

## 5. College Cafeteria Order Flow (Spec C)
- **Decision:** Items are categorized into Meal, Beverage, Snack, Dessert. Cafeteria staff can toggle availability (`is_available`). Items marked unavailable are grouped into a dedicated "Not Available" section on the student ordering view. When students place an order, they receive an Order Token and staff transition status through `placed` -> `preparing` -> `ready` -> `delivered`.

---

## 6. College Cyber Cafe Workflow (Spec D)
- **Priority 1 (Online Scholarship):** Direct upload and status tracking for scholarship schemes.
- **Priority 2 (Offline Slots):** Maximum 20 physical terminal slots per day. If a student misses their slot, the staff can initiate a live reschedule or call notification.
- **Printing / Xerox:** Document upload queue with page count, color/B&W choice, and pickup token.

---

## 7. Library Management (Spec E)
- **Decision:** Separate request queues for Students vs Teachers. Teachers receive extended borrowing windows. Auto fine calculator calculates overdue fines per day after the due date.

---

## 8. Events & Sports Short-Polling (Spec F)
- **Decision:** Sports live scores and event status use lightweight JSON short-polling (`/events/api/live-scores`) every 5-10 seconds on the client side, avoiding WebSocket complexity while delivering real-time feel.

---

## 9. Depression Index & Counselor Dashboard (Spec G)
- **Formula:**
  $$\text{Risk Score} = 0.35 \times (100 - \text{Attendance \%}) + 0.25 \times (\text{Unsubmitted Assignments Rate \%}) + 0.20 \times (\text{Room Isolation Index}) + 0.20 \times (\text{Self-Reported Distress})$$
- **Security & Privacy:** Counselor notes and student wellbeing indices are strictly guarded by `@role_required('counselor', 'super_admin')`. Any access to student mental health logs is immutably recorded in the `audit_logs` table. No students or regular faculty can view other students' wellbeing indices.

---

## 10. Communities (Spec I)
- **Decision:** Students and faculty are automatically mapped to Communities based on their branch (`BTech-CSE`), batch (`2024`), residence type (`Hostel-Aryabhata` or `Day Scholar`), and opt-in interest clubs (Coding, Robotics, Literary, Sports). Role-based posting privileges ensure official announcements cannot be drowned out by general chit-chat.
