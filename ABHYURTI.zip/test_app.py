import io
from werkzeug.security import generate_password_hash
from app import create_app
from app.extensions import db
from app.models import User, Role, Complaint, GatePass, Notice, NoticeRead, AuditLog

def run_smoke_tests():
    app = create_app()
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False
    client = app.test_client()

    print("Running Fretbox Smoke Tests...")

    with app.app_context():
        # Setup clean test users for smoke test
        student_role = Role.query.filter_by(name='student').first()
        warden_role = Role.query.filter_by(name='warden').first()
        if not student_role:
            student_role = Role(name='student', display_name='Student')
            db.session.add(student_role)
        if not warden_role:
            warden_role = Role(name='warden', display_name='Hostel Warden')
            db.session.add(warden_role)
        db.session.commit()

        # Create/ensure a test student
        test_student = User.query.filter_by(email='smokestudent@college.edu').first()
        if not test_student:
            test_student = User(
                name='Smoke Student',
                email='smokestudent@college.edu',
                phone='9876543210',
                roll_number='SMOKE2026',
                hostel='Hostel A',
                room='204',
                branch='Computer Science',
                year=3,
                role='student',
                password_hash=generate_password_hash('SmokePass123'),
                pin='5678',
                is_active=True
            )
            db.session.add(test_student)
            db.session.commit()

        # Create/ensure a test warden
        test_warden = User.query.filter_by(email='smokewarden@college.edu').first()
        if not test_warden:
            test_warden = User(
                name='Smoke Warden',
                email='smokewarden@college.edu',
                phone='9876543211',
                role='warden',
                password_hash=generate_password_hash('SmokePass123'),
                is_active=True
            )
            db.session.add(test_warden)
            db.session.commit()

        # 1. Test Login Page
        res = client.get('/login')
        assert res.status_code == 200, f"Login page failed: {res.status_code}"
        assert b"Sign In" in res.data, "Login page missing title"
        print(" [PASS] GET /login")

        # 2. Test Registration Page
        res = client.get('/register')
        assert res.status_code == 200, f"Register page failed: {res.status_code}"
        assert b"Student Registration" in res.data
        print(" [PASS] GET /register")

        # 3. Test Student Login (Standard Authenticated Flow)
        res = client.post('/login', data={
            'identifier': 'smokestudent@college.edu',
            'password': 'SmokePass123'
        }, follow_redirects=True)
        assert res.status_code == 200
        assert b"Smoke Student" in res.data
        print(" [PASS] POST /login as Student & Student Dashboard")

        # 4. Test Student Unified Timeline
        res = client.get('/timeline')
        assert res.status_code == 200
        assert b"Unified Student Activity Timeline" in res.data
        print(" [PASS] GET /timeline")

        # 5. Test Complaints List
        res = client.get('/complaints')
        assert res.status_code == 200
        print(" [PASS] GET /complaints")

        # 6. Test New Complaint Submission (Plumbing in Room 204 - Repeat Detection)
        res = client.post('/complaints/new', data={
            'category': 'cat_plumbing',
            'hostel': 'Hostel A',
            'room': '204',
            'description': 'Automated test leaking pipe issue'
        }, follow_redirects=True)
        assert res.status_code == 200
        assert b"submitted successfully" in res.data
        print(" [PASS] POST /complaints/new with repeat detection")

        # 7. Test Emergency Gate Pass Submission
        res = client.post('/gate-pass/new', data={
            'destination': 'Metro Hospital',
            'reason': 'High temperature medical emergency',
            'from_date': '2026-10-01T20:00',
            'to_date': '2026-10-02T10:00',
            'is_emergency': 'y',
            'emergency_reason': 'Fever 103F',
            'notify_parent': 'y'
        }, follow_redirects=True)
        assert res.status_code == 200
        assert b"Emergency Gate Pass" in res.data or b"submitted" in res.data
        print(" [PASS] POST /gate-pass/new with emergency priority")

        # 8. Test Student Notices Feed
        res = client.get('/notices')
        assert res.status_code == 200
        print(" [PASS] GET /notices")

        # 9. Test Mess Page with Outside Food Ordering & Canteen Issue Report
        res_mess = client.get('/mess')
        assert res_mess.status_code == 200
        assert b"zomato" in res_mess.data.lower()
        assert b"swiggy" in res_mess.data.lower()
        assert b"blinkit" in res_mess.data.lower()
        assert b"zepto" in res_mess.data.lower()
        assert b"dominos" in res_mess.data.lower()
        assert b"third-party" in res_mess.data.lower()
        print(" [PASS] GET /mess with Outside Food Ordering cards & disclaimer")

        # Submit Canteen Food Complaint
        res_food_issue = client.post('/canteen/report-issue', data={
            'food_name': 'Cold Dal Tadka',
            'issue_type': 'Cold Food',
            'meal_type': 'Lunch',
            'notes': 'Served stone cold at counter 2'
        }, follow_redirects=True)
        assert res_food_issue.status_code == 200
        assert b"Cold Dal Tadka" in res_food_issue.data
        print(" [PASS] POST /canteen/report-issue (Student Complaint)")

        for stub in ['/attendance', '/certificates']:
            res = client.get(stub)
            assert res.status_code == 200
            print(f" [PASS] GET {stub}")

        # 10. Test Admin Dashboard as Warden
        client.post('/logout', follow_redirects=True)
        res = client.post('/login', data={
            'identifier': 'smokewarden@college.edu',
            'password': 'SmokePass123'
        }, follow_redirects=True)
        assert res.status_code == 200
        res = client.get('/admin', follow_redirects=True)
        assert res.status_code == 200
        assert b"Dashboard" in res.data
        print(" [PASS] GET /admin (Admin Dashboard as Warden)")

        # Verify Warden sees Student's Canteen Food Complaint
        res_ci = client.get('/admin/canteen-issues')
        assert res_ci.status_code == 200
        assert b"Cold Dal Tadka" in res_ci.data
        print(" [PASS] GET /admin/canteen-issues (Warden views student food complaint)")

        # 11. Test Admin Complaints Queue
        res = client.get('/admin/complaints')
        assert res.status_code == 200
        assert b"Ticket" in res.data
        print(" [PASS] GET /admin/complaints")

        # 12. Test Admin Gate Passes Queue & One-Click Approve
        pending_pass = GatePass.query.filter_by(status='pending').first()
        if pending_pass:
            res = client.post(f'/admin/gate-passes/{pending_pass.id}/approve', follow_redirects=True)
            assert res.status_code == 200
            assert b"APPROVED" in res.data
            print(" [PASS] POST /admin/gate-passes/<id>/approve")

        # 13. Test Compose Notice with Audience Preview API
        res = client.get('/api/target-preview?hostel=Hostel+A&year=3')
        assert res.status_code == 200
        assert 'count' in res.json
        print(f" [PASS] GET /api/target-preview -> {res.json}")

        # 14. Test Room QR Inspection
        res = client.get('/admin/room/Hostel A/204')
        assert res.status_code == 200
        assert b"Room 204" in res.data
        print(" [PASS] GET /admin/room/Hostel A/204")

        # 15. Test Kiosk Terminal & Verification
        res = client.get('/kiosk/')
        assert res.status_code == 200
        assert b"Kiosk" in res.data
        
        # Verify student via PIN
        res = client.post('/kiosk/', data={
            'roll_number': 'SMOKE2026',
            'pin': '5678'
        }, follow_redirects=True)
        assert res.status_code == 200
        assert b"Smoke Student" in res.data
        print(" [PASS] POST /kiosk/ PIN verification")

        # 16. Test Kiosk Complaint & Receipt Generation
        res = client.post('/kiosk/complaint', data={
            'category': 'cat_electrical',
            'hostel': 'Hostel A',
            'room': '204',
            'description': 'Kiosk reported tube light repair'
        }, follow_redirects=True)
        assert res.status_code == 200
        assert b"OFFICIAL STUDENT TRANSACTION RECEIPT" in res.data
        print(" [PASS] POST /kiosk/complaint & GET /kiosk/receipt")

        # 17. Test 7 Multi-Language Localizations (Odia, Tamil, Bengali, Telugu, Marathi, Hindi, English)
        client.post('/logout', follow_redirects=True)
        lang_checks = [
            ('hi', b"ABHYURTI", "छात्र पंजीकरण".encode('utf-8'), "Hindi"),
            ('or', b"ABHYURTI", "ଛାତ୍ର ପଞ୍ଜୀକରଣ".encode('utf-8'), "Odia"),
            ('ta', b"ABHYURTI", "மாணவர் பதிவு".encode('utf-8'), "Tamil"),
            ('bn', b"ABHYURTI", "ছাত্র নিবন্ধন".encode('utf-8'), "Bengali"),
            ('te', b"ABHYURTI", "విద్యార్థి నమోదు".encode('utf-8'), "Telugu"),
            ('mr', b"ABHYURTI", "विद्यार्थी नोंदणी".encode('utf-8'), "Marathi"),
            ('en', b"ABHYURTI", b"Student Registration", "English")
        ]
        for code, brand_bytes, test_bytes, name in lang_checks:
            res = client.get(f'/login?lang={code}', follow_redirects=True)
            assert res.status_code == 200
            assert brand_bytes in res.data, f"Brand 'ABHYURTI' missing for {name}"
            assert test_bytes in res.data, f"Failed for language translation: {name} ({code})"
            print(f" [PASS] GET /login?lang={code} ({name} Localization with brand 'ABHYURTI' and Latin numbers)")

    print("\nALL 17 END-TO-END TESTS PASSED SUCCESSFULLY! \n")

if __name__ == '__main__':
    run_smoke_tests()
    from test_rbac import run_rbac_test_suite
    run_rbac_test_suite()


