from datetime import datetime
from flask import Blueprint, jsonify, request
from flask_login import current_user
from app.extensions import db, limiter
from app.models import User, GatePass, FCMSubscription, Complaint
from app.utils.targeting import get_unread_notices_count
from app.services.ai_service import chat_with_campus_ai, classify_complaint_ai
from app.services.ocr_service import extract_text_from_document, test_ocr_connection
from app.services.maps_service import get_campus_map_data, test_google_maps_key
from app.services.notification_service import (
    send_sms, send_whatsapp, send_email, test_twilio_connection,
    test_email_service, test_fcm_connection
)
from app.services.storage_service import test_cloudinary_connection
from app.services.supabase_service import test_supabase_connection
from app.services.firebase_service import test_firebase_connection

api_bp = Blueprint('api', __name__, url_prefix='/api')

# ------------------------------------------------------------------------------
# Existing Endpoints
# ------------------------------------------------------------------------------
@api_bp.route('/unread-count')
def unread_count():
    if not current_user.is_authenticated:
        return jsonify({'unread_notices': 0, 'emergency_passes': 0})

    notices_count = 0
    if current_user.role == 'student':
        notices_count = get_unread_notices_count(current_user)

    emergency_count = 0
    if current_user.role in ('admin', 'warden', 'super_admin'):
        gp_query = GatePass.query.filter(GatePass.status == 'pending', GatePass.is_emergency == True)
        if current_user.role == 'warden' and current_user.hostel:
            gp_query = gp_query.join(User, GatePass.student_id == User.id).filter(User.hostel == current_user.hostel)
        emergency_count = gp_query.count()

    return jsonify({
        'unread_notices': notices_count,
        'emergency_passes': emergency_count
    })


@api_bp.route('/target-preview')
def target_preview():
    """Returns number of students targeted by given criteria."""
    hostel = request.args.get('hostel')
    year = request.args.get('year', type=int)
    branch = request.args.get('branch')
    batch = request.args.get('batch')

    query = User.query.filter(User.role == 'student')
    if hostel:
        query = query.filter(User.hostel == hostel)
    if year:
        query = query.filter(User.year == year)
    if branch:
        query = query.filter(User.branch == branch)
    if batch:
        query = query.filter(User.batch == batch)

    count = query.count()
    return jsonify({'count': count})


@api_bp.route('/sms-parent', methods=['POST'])
def mock_sms_parent():
    """Endpoint dispatching parent notification SMS/WhatsApp via Twilio or simulator."""
    data = request.get_json() or {}
    phone = data.get('phone', '9876543210')
    name = data.get('student_name', 'Student')
    reason = data.get('reason', 'Campus exit')

    msg = f"ABHYURTI NOTICE: Your ward {name} has requested campus exit for '{reason}'."
    res = send_sms(phone, msg)
    return jsonify({
        'status': 'dispatched',
        'provider': res.get('provider'),
        'message': f"SMS alert dispatched to parent of {name}",
        'payload': data
    })


# ------------------------------------------------------------------------------
# 1. AI Assistant & Chatbot (Google Gemini / OpenAI / Local Heuristic Engine)
# ------------------------------------------------------------------------------
@api_bp.route('/ai/chat', methods=['POST'])
def ai_chat():
    """
    Campus AI Chatbot endpoint. Answers student and staff questions,
    checks live status of complaints/passes, and provides policy info.
    """
    data = request.get_json(silent=True) or {}
    prompt = data.get('prompt', '').strip()
    history = data.get('history', [])

    if not prompt:
        return jsonify({'success': False, 'error': 'Prompt cannot be empty'}), 400

    try:
        result = chat_with_campus_ai(prompt, user=current_user if current_user.is_authenticated else None, history=history)
        return jsonify({
            'success': True,
            'response': result.get('text', ''),
            'source': result.get('source', 'Campus Copilot'),
            'status': result.get('status', 'online')
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': f"Failed to generate response: {str(e)}",
            'response': "I am temporarily unable to reach the AI cloud. Please try again shortly or check with campus admin."
        }), 200


# ------------------------------------------------------------------------------
# 2. AI Complaint Classifier & Recurring-Issue Detection
# ------------------------------------------------------------------------------
@api_bp.route('/ai/classify-complaint', methods=['POST'])
def ai_classify_complaint():
    """
    Analyzes complaint text, predicts category, urgency, department,
    and checks database for recurring issues in the same hostel/room.
    """
    data = request.get_json() or {}
    title = data.get('title', '')
    description = data.get('description', '')
    hostel = data.get('hostel') or (current_user.hostel if current_user.is_authenticated else 'Hostel A')
    room = data.get('room') or (current_user.room if current_user.is_authenticated else '101')

    if not description and not title:
        return jsonify({'error': 'Description or title required'}), 400

    analysis = classify_complaint_ai(title, description, hostel=hostel, room=room)
    return jsonify({
        'success': True,
        'analysis': analysis
    })


# ------------------------------------------------------------------------------
# 3. OCR Document Text & Field Extraction
# ------------------------------------------------------------------------------
@api_bp.route('/ocr/scan', methods=['POST'])
def ocr_scan():
    """
    Uploads a prescription, leave slip, or certificate and extracts structured text.
    """
    image_bytes = None
    base64_data = None

    if 'file' in request.files and request.files['file'].filename:
        image_bytes = request.files['file'].read()
    else:
        data = request.get_json() or {}
        base64_data = data.get('image_base64')

    if not image_bytes and not base64_data:
        return jsonify({'error': 'No file or image_base64 provided'}), 400

    res = extract_text_from_document(image_bytes=image_bytes, base64_data=base64_data)
    return jsonify(res)


# ------------------------------------------------------------------------------
# 4. Firebase Cloud Messaging (FCM) Subscription
# ------------------------------------------------------------------------------
@api_bp.route('/notifications/fcm/subscribe', methods=['POST'])
def fcm_subscribe():
    """Registers browser or mobile device FCM Push token for current user."""
    if not current_user.is_authenticated:
        return jsonify({'error': 'Authentication required'}), 401

    data = request.get_json() or {}
    token = data.get('token', '').strip()
    device_info = data.get('device_info', request.headers.get('User-Agent', 'Web Browser'))[:250]

    if not token:
        return jsonify({'error': 'Missing FCM token'}), 400

    sub = FCMSubscription.query.filter_by(token=token).first()
    if not sub:
        sub = FCMSubscription(user_id=current_user.id, token=token, device_info=device_info)
        db.session.add(sub)
    else:
        sub.user_id = current_user.id
        sub.device_info = device_info
        sub.updated_at = datetime.utcnow()
    db.session.commit()

    return jsonify({'success': True, 'message': 'Device registered for push notifications.'})


# ------------------------------------------------------------------------------
# 5. Campus Maps & Facility POIs
# ------------------------------------------------------------------------------
@api_bp.route('/campus/map-data')
def campus_map_data():
    """Returns campus coordinates, facilities, and Google Maps API configuration."""
    return jsonify(get_campus_map_data())


# ------------------------------------------------------------------------------
# 6. Third-Party Integrations Live Connection Tester
# ------------------------------------------------------------------------------
@api_bp.route('/integrations/test', methods=['POST'])
def test_integration():
    """
    Tests connection to any of the 10 supported cloud/API services.
    Accessible to administrators and super admins.
    """
    if not current_user.is_authenticated or not (current_user.has_role('admin', 'warden', 'super_admin')):
        return jsonify({'success': False, 'message': 'Unauthorized'}), 403

    data = request.get_json() or {}
    service = data.get('service', '').lower().strip()
    key_val = data.get('value', '').strip()

    if service == 'gemini':
        try:
            from app.services.ai_service import _call_gemini
            res = _call_gemini("Ping test. Reply with 'Pong'.", "Respond in one word.", key_val or None)
            return jsonify({'success': True, 'message': f"Google Gemini responded successfully: {res.get('text')}"})
        except Exception as e:
            return jsonify({'success': False, 'message': f"Google Gemini error: {str(e)}"})

    elif service == 'openai':
        try:
            from app.services.ai_service import _call_openai
            res = _call_openai("Ping test. Reply with 'Pong'.", "Respond in one word.", key_val or None)
            return jsonify({'success': True, 'message': f"OpenAI responded successfully: {res.get('text')}"})
        except Exception as e:
            return jsonify({'success': False, 'message': f"OpenAI error: {str(e)}"})

    elif service == 'google_maps':
        return jsonify(test_google_maps_key(key_val))

    elif service == 'cloudinary':
        return jsonify(test_cloudinary_connection())

    elif service == 'twilio':
        return jsonify(test_twilio_connection())

    elif service in ('resend', 'sendgrid'):
        return jsonify(test_email_service(service, key_val))

    elif service == 'fcm':
        return jsonify(test_fcm_connection(key_val))

    elif service == 'firebase':
        return jsonify(test_firebase_connection(key_val))

    elif service == 'supabase':
        return jsonify(test_supabase_connection())

    elif service == 'ocr':
        return jsonify(test_ocr_connection(key_val))

    return jsonify({'success': False, 'message': f"Unknown service: {service}"}), 400
