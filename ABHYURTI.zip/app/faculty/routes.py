from datetime import datetime
from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app.extensions import db
from app.models import User, Attendance, LeaveRequest, Notice, StudentProfile
from app.utils.security import role_required, log_audit_action, create_notification
from app.faculty import faculty_bp

@faculty_bp.route('/')
@faculty_bp.route('/dashboard')
@login_required
@role_required('faculty', 'super_admin', 'admin')
def dashboard():
    # Classes / subjects assigned to this faculty member
    dept = current_user.staff_profile.department if current_user.staff_profile else 'CSE'
    assigned_sections = current_user.staff_profile.assigned_sections if current_user.staff_profile else 'CSE-3A, CSE-3B'

    # Assigned students (e.g. students in same branch or sections)
    branch = dept if dept in ('CSE', 'ECE', 'ME', 'CE', 'EE') else 'CSE'
    assigned_students = User.query.filter(User.role == 'student', User.branch == branch).all()

    # Pending leave requests assigned to faculty
    pending_leaves = LeaveRequest.query.filter(
        (LeaveRequest.faculty_id == current_user.id) | (LeaveRequest.faculty_id.is_(None)),
        LeaveRequest.status == 'pending'
    ).order_by(LeaveRequest.created_at.desc()).all()

    # Recent attendance marked by this faculty
    recent_attendances = Attendance.query.filter_by(
        faculty_id=current_user.id
    ).order_by(Attendance.created_at.desc()).limit(15).all()

    # Notices published by this faculty
    my_notices = Notice.query.filter_by(created_by=current_user.id).order_by(Notice.published_at.desc()).limit(5).all()

    return render_template(
        'faculty/dashboard.html',
        assigned_students=assigned_students,
        pending_leaves=pending_leaves,
        recent_attendances=recent_attendances,
        my_notices=my_notices,
        branch=branch,
        assigned_sections=assigned_sections
    )


@faculty_bp.route('/attendance', methods=['GET', 'POST'])
@faculty_bp.route('/attendance/mark', methods=['GET', 'POST'])
@login_required
@role_required('faculty', 'super_admin', 'admin')
def mark_attendance():
    dept = current_user.staff_profile.department if current_user.staff_profile else 'CSE'
    branch = dept if dept in ('CSE', 'ECE', 'ME', 'CE', 'EE') else 'CSE'
    students = User.query.filter(User.role == 'student', User.branch == branch).order_by(User.roll_number.asc()).all()

    if request.method == 'POST':
        subject_code = request.form.get('subject_code', 'CS301').strip().upper()
        subject_name = request.form.get('subject_name', 'Computer Networks').strip()
        date_str = request.form.get('date') or datetime.utcnow().strftime('%Y-%m-%d')
        att_date = datetime.strptime(date_str, '%Y-%m-%d').date()

        for s in students:
            status_val = request.form.get(f'status_{s.id}', 'present')
            remarks_val = request.form.get(f'remarks_{s.id}', '').strip()

            # Check existing attendance for this student, subject, date
            rec = Attendance.query.filter_by(
                student_id=s.id,
                subject_code=subject_code,
                date=att_date
            ).first()

            if rec:
                rec.status = status_val
                rec.remarks = remarks_val
                rec.faculty_id = current_user.id
            else:
                new_att = Attendance(
                    student_id=s.id,
                    faculty_id=current_user.id,
                    subject_code=subject_code,
                    subject_name=subject_name,
                    date=att_date,
                    status=status_val,
                    remarks=remarks_val
                )
                db.session.add(new_att)

        db.session.commit()
        log_audit_action(current_user.id, 'attendance', current_user.id, 'attendance_marked', notes=f"Marked {subject_code} attendance for {len(students)} students on {date_str}")
        flash(f"Attendance for {subject_code} ({date_str}) saved successfully for {len(students)} students!", "success")
        return redirect(url_for('faculty.dashboard'))

    return render_template('faculty/attendance_form.html', students=students, branch=branch)


@faculty_bp.route('/leaves/<int:id>/<action>', methods=['POST'])
@login_required
@role_required('faculty', 'super_admin', 'admin')
def review_leave(id, action):
    leave = LeaveRequest.query.get_or_404(id)
    rejection_reason = request.form.get('rejection_reason', '').strip()

    old_status = leave.status
    if action == 'approve':
        leave.status = 'approved'
        leave.faculty_id = current_user.id
        db.session.commit()

        log_audit_action(current_user.id, 'leave_request', leave.id, 'approved', old_status=old_status, new_status='approved')
        create_notification(
            user_id=leave.student_id,
            title="Leave Request Approved",
            message=f"Your leave from {leave.start_date.strftime('%d %b')} to {leave.end_date.strftime('%d %b')} was approved by {current_user.name}.",
            category='academic',
            link=url_for('student.timeline')
        )
        flash(f"Leave request #{leave.id} approved.", "success")
    elif action == 'reject':
        leave.status = 'rejected'
        leave.faculty_id = current_user.id
        leave.rejection_reason = rejection_reason or "Leave request declined by teacher."
        db.session.commit()

        log_audit_action(current_user.id, 'leave_request', leave.id, 'rejected', old_status=old_status, new_status='rejected', notes=rejection_reason)
        create_notification(
            user_id=leave.student_id,
            title="Leave Request Rejected",
            message=f"Your leave request was rejected by {current_user.name}. Reason: {leave.rejection_reason}",
            category='academic',
            link=url_for('student.timeline')
        )
        flash(f"Leave request #{leave.id} rejected.", "warning")

    return redirect(url_for('faculty.dashboard'))


@faculty_bp.route('/notices/new', methods=['GET', 'POST'])
@login_required
@role_required('faculty', 'super_admin', 'admin')
def notice_new():
    dept = current_user.staff_profile.department if current_user.staff_profile else 'CSE'
    branch = dept if dept in ('CSE', 'ECE', 'ME', 'CE', 'EE') else 'CSE'

    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        body = request.form.get('body', '').strip()
        target_year = request.form.get('target_year', type=int) or None
        target_batch = request.form.get('target_batch', '').strip() or None

        if not title or not body:
            flash("Notice title and content are required.", "danger")
            return render_template('faculty/notice_form.html', branch=branch)

        notice = Notice(
            title=title,
            body=body,
            target_branch=branch,
            target_year=target_year,
            target_batch=target_batch,
            created_by=current_user.id,
            requires_action=bool(request.form.get('requires_action')),
            action_label=request.form.get('action_label', 'Acknowledge').strip() or 'Acknowledge',
            status='published'
        )
        db.session.add(notice)
        db.session.commit()

        log_audit_action(current_user.id, 'notice', notice.id, 'published', notes=f"Faculty notice published: {title}")
        flash("Academic class notice published successfully!", "success")
        return redirect(url_for('faculty.dashboard'))

    return render_template('faculty/notice_form.html', branch=branch)


# ============================================================================
# FACULTY ASSIGNMENTS & GRADING (SPEC H.1)
# ============================================================================

@faculty_bp.route('/assignments')
@login_required
@role_required('faculty', 'hod', 'super_admin', 'admin')
def assignments_list():
    from app.models import Assignment, AssignmentSubmission
    dept = current_user.staff_profile.department if current_user.staff_profile else 'CSE'
    assignments = Assignment.query.filter_by(faculty_id=current_user.id).order_by(Assignment.created_at.desc()).all()
    return render_template('faculty/assignments.html', assignments=assignments, dept=dept)


@faculty_bp.route('/assignments/create', methods=['POST'])
@login_required
@role_required('faculty', 'hod', 'super_admin', 'admin')
def assignment_create():
    from app.models import Assignment
    title = request.form.get('title', '').strip()
    subject = request.form.get('subject', '').strip()
    semester = request.form.get('semester', type=int) or 6
    description = request.form.get('description', '').strip()
    due_date_str = request.form.get('due_date', '').strip()
    max_score = int(request.form.get('max_score', 100) or 100)
    file_path = request.form.get('file_path', '').strip()
    dept = current_user.staff_profile.department if current_user.staff_profile else 'CSE'

    if not title or not subject or not due_date_str:
        flash("Title, subject, and due date are required.", "danger")
        return redirect(url_for('faculty.assignments_list'))

    try:
        due_date = datetime.strptime(due_date_str, '%Y-%m-%dT%H:%M')
    except ValueError:
        try:
            due_date = datetime.strptime(due_date_str, '%Y-%m-%d')
        except ValueError:
            due_date = datetime.utcnow() + timedelta(days=7)

    assign = Assignment(
        faculty_id=current_user.id,
        department=dept,
        semester=semester,
        subject=subject,
        title=title,
        description=description,
        max_score=max_score,
        due_date=due_date,
        file_path=file_path if file_path else None
    )
    db.session.add(assign)
    db.session.commit()

    log_audit_action(current_user.id, 'assignment', assign.id, 'created', notes=f"Created assignment {title}")
    flash(f"Assignment '{title}' posted successfully for {dept} Sem {semester}!", "success")
    return redirect(url_for('faculty.assignments_list'))


@faculty_bp.route('/assignments/grade/<int:submission_id>', methods=['POST'])
@login_required
@role_required('faculty', 'hod', 'super_admin', 'admin')
def assignment_grade(submission_id):
    from app.models import AssignmentSubmission
    sub = AssignmentSubmission.query.get_or_404(submission_id)
    score = float(request.form.get('score', 0.0) or 0.0)
    feedback = request.form.get('feedback', '').strip()

    sub.score = score
    sub.feedback = feedback
    sub.graded_at = datetime.utcnow()
    db.session.commit()

    create_notification(
        sub.student_id,
        "Assignment Graded",
        f"Your submission for '{sub.assignment.title}' was scored {score}/{sub.assignment.max_score}. Feedback: {feedback or 'Good effort'}.",
        link=url_for('student.student_assignments')
    )

    flash(f"Submission for {sub.student.name} graded ({score}/{sub.assignment.max_score}).", "success")
    return redirect(url_for('faculty.assignments_list'))

