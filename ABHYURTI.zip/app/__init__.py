import os
from datetime import datetime
from flask import Flask, render_template, request, session, flash, redirect, url_for
from app.config import Config
from app.extensions import db, login_manager, csrf, limiter
from app.i18n import translate, get_current_locale, SUPPORTED_LANGUAGES
from app.utils.targeting import get_unread_notices_count

def create_app(config_class=Config):
    app = Flask(__name__, template_folder='../templates', static_folder='../static')
    app.config.from_object(config_class)

    # Ensure directories exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config.get('QR_FOLDER', os.path.join(app.root_path, '..', 'static', 'qr')), exist_ok=True)

    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    limiter.init_app(app)

    # Register blueprints
    from app.auth import auth_bp
    from app.student import student_bp
    from app.admin import admin_bp
    from app.kiosk import kiosk_bp
    from app.api import api_bp
    from app.super_admin import super_admin_bp
    from app.faculty import faculty_bp
    from app.mess_manager import mess_manager_bp
    from app.maintenance import maintenance_bp
    from app.office import office_bp
    from app.notifications import notifications_bp
    from app.communities import communities_bp
    from app.account_section import account_bp
    from app.examination import examination_bp
    from app.cafeteria import cafeteria_bp
    from app.cyber_cafe import cyber_cafe_bp
    from app.library import library_bp
    from app.events import events_bp
    from app.caretaker import caretaker_bp
    from app.counselor import counselor_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(student_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(kiosk_bp)
    app.register_blueprint(api_bp)
    csrf.exempt(api_bp)
    app.register_blueprint(super_admin_bp)
    app.register_blueprint(faculty_bp)
    app.register_blueprint(mess_manager_bp)
    app.register_blueprint(maintenance_bp)
    app.register_blueprint(office_bp)
    app.register_blueprint(notifications_bp)
    app.register_blueprint(communities_bp)
    app.register_blueprint(account_bp)
    app.register_blueprint(examination_bp)
    app.register_blueprint(cafeteria_bp)
    app.register_blueprint(cyber_cafe_bp)
    app.register_blueprint(library_bp)
    app.register_blueprint(events_bp)
    app.register_blueprint(caretaker_bp)
    app.register_blueprint(counselor_bp)

    # Register custom CLI commands
    from app.cli import register_cli_commands
    register_cli_commands(app)

    # Top-level public receipt verification alias
    @app.route('/verify/receipt/<token>')
    def verify_receipt_alias(token):
        return redirect(url_for('account_section.verify_receipt', token=token))

    # Top-level /account-section alias redirect
    @app.route('/account-section')
    @app.route('/account-section/')
    def account_section_alias_root():
        return redirect(url_for('account_section.dashboard'))

    @app.route('/account-section/<path:subpath>')
    def account_section_alias_sub(subpath):
        return redirect(f"/account/{subpath}")

    # Capture language query param before any route or redirect
    @app.before_request
    def capture_language_param():
        lang = request.args.get('lang')
        if lang and lang in SUPPORTED_LANGUAGES:
            session['locale'] = lang

    # Session invalidation check
    @app.before_request
    def validate_user_session():
        from flask_login import current_user, logout_user
        from app.models import UserSession
        if current_user.is_authenticated:
            token = session.get('session_token')
            if token:
                sess_obj = UserSession.query.filter_by(session_token=token, is_active=True).first()
                now = datetime.utcnow()
                if not sess_obj or (sess_obj.expires_at and sess_obj.expires_at < now):
                    session.clear()
                    logout_user()
                    if request.endpoint and not request.endpoint.startswith('static') and request.endpoint != 'auth.login':
                        flash('Your session has expired. Please sign in again.', 'warning')
                        return redirect(url_for('auth.login'))
                else:
                    sess_obj.last_activity_at = now
                    db.session.commit()

    # Context processors for all Jinja2 templates
    @app.context_processor
    def inject_global_template_vars():
        from flask_login import current_user
        from app.models import GatePass, User, Notification, ApprovalRequest
        
        unread_count = 0
        emergency_count = 0
        unread_notifs_count = 0
        pending_staff_count = 0
        
        if current_user.is_authenticated:
            unread_notifs_count = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
            if current_user.is_super_admin:
                pending_staff_count = ApprovalRequest.query.filter_by(status='pending').count()

            if current_user.is_student:
                unread_count = get_unread_notices_count(current_user)
            elif current_user.has_role('admin', 'warden', 'super_admin'):
                gp_q = GatePass.query.filter(GatePass.status == 'pending', GatePass.is_emergency == True)
                if current_user.primary_role == 'warden' and current_user.hostel:
                    gp_q = gp_q.join(User, GatePass.student_id == User.id).filter(User.hostel == current_user.hostel)
                emergency_count = gp_q.count()

        return {
            'APP_NAME': app.config.get('APP_NAME', 'ABHYURTI'),
            'app_name': app.config.get('APP_NAME', 'ABHYURTI'),
            '_': translate,
            'current_locale': get_current_locale(),
            'supported_languages': SUPPORTED_LANGUAGES,
            'unread_notices_count': unread_count,
            'emergency_passes_count': emergency_count,
            'unread_notifs_count': unread_notifs_count,
            'pending_staff_count': pending_staff_count,
            'current_time': datetime.utcnow()
        }

    # Custom Jinja filters
    @app.template_filter('datetimeformat')
    def datetimeformat(value, format='%d %b %Y, %I:%M %p'):
        if value is None:
            return ""
        return value.strftime(format)

    @app.template_filter('timeago')
    def timeago(dt):
        if not dt:
            return ""
        now = datetime.utcnow()
        diff = now - dt
        seconds = diff.total_seconds()
        if seconds < 60:
            return "Just now"
        elif seconds < 3600:
            mins = int(seconds // 60)
            return f"{mins}m ago"
        elif seconds < 86400:
            hours = int(seconds // 3600)
            return f"{hours}h ago"
        else:
            days = int(seconds // 86400)
            return f"{days}d ago"

    # Error pages
    @app.errorhandler(403)
    def forbidden_access(e):
        return render_template('403.html'), 403

    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('404.html'), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('500.html'), 500

    # Cache headers for authenticated data privacy
    @app.after_request
    def set_security_cache_headers(response):
        from flask_login import current_user
        if current_user.is_authenticated:
            response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0, private"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
        return response

    return app
