from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, abort, jsonify
from flask_login import login_required, current_user
from app.counselor import counselor_bp
from app.extensions import db
from app.models import StudentWellbeingIndex, CounselorSessionNote, User
from app.utils.security import role_required, log_audit_action, create_notification
from app.services.wellbeing_service import calculate_student_wellbeing_index, recalculate_all_students_wellbeing


@counselor_bp.route('/')
@counselor_bp.route('/dashboard')
@login_required
@role_required('counselor', 'super_admin')
def dashboard():
    # Recalculate indices for freshness
    recalculate_all_students_wellbeing()

    # Immutable Audit Log for Data Privacy Compliance
    log_audit_action(current_user.id, 'mental_health_records', 0, 'counselor_access',
                     notes=f"Counselor {current_user.name} accessed student wellbeing index dashboard")

    filter_tier = request.args.get('tier', 'all').strip().lower()
    query = StudentWellbeingIndex.query

    if filter_tier in ('severe', 'high', 'moderate', 'low'):
        query = query.filter_by(risk_level=filter_tier)

    # Sort highest risk score first
    indices = query.order_by(StudentWellbeingIndex.composite_risk_score.desc()).all()

    # Tier counts across all students
    all_indices = StudentWellbeingIndex.query.all()
    severe_count = sum(1 for i in all_indices if i.risk_level == 'severe')
    high_count = sum(1 for i in all_indices if i.risk_level == 'high')
    moderate_count = sum(1 for i in all_indices if i.risk_level == 'moderate')
    low_count = sum(1 for i in all_indices if i.risk_level == 'low')
    flagged_count = sum(1 for i in all_indices if i.counselor_flagged)

    return render_template('counselor/dashboard.html',
                           indices=indices,
                           severe_count=severe_count,
                           high_count=high_count,
                           moderate_count=moderate_count,
                           low_count=low_count,
                           flagged_count=flagged_count,
                           selected_tier=filter_tier)


@counselor_bp.route('/student/<int:student_id>')
@login_required
@role_required('counselor', 'super_admin')
def student_profile(student_id):
    student = User.query.get_or_404(student_id)
    if student.role != 'student':
        abort(404)

    wellbeing = calculate_student_wellbeing_index(student.id)
    notes = CounselorSessionNote.query.filter_by(
        student_id=student.id
    ).order_by(CounselorSessionNote.session_date.desc()).all()

    log_audit_action(current_user.id, 'mental_health_records', student.id, 'counselor_case_view',
                     notes=f"Viewed wellbeing case file for {student.name}")

    return render_template('counselor/student_profile.html',
                           student=student,
                           wellbeing=wellbeing,
                           notes=notes)


@counselor_bp.route('/flag/<int:student_id>', methods=['POST'])
@login_required
@role_required('counselor', 'super_admin')
def toggle_flag(student_id):
    wellbeing = StudentWellbeingIndex.query.filter_by(student_id=student_id).first_or_404()
    wellbeing.counselor_flagged = not wellbeing.counselor_flagged
    db.session.commit()

    action_label = "flagged for proactive outreach" if wellbeing.counselor_flagged else "unflagged"
    log_audit_action(current_user.id, 'mental_health_records', student_id, 'flag_toggle',
                     notes=f"Student {action_label}")

    flash(f"Student case file {action_label}.", "info")
    return redirect(request.referrer or url_for('counselor.dashboard'))


@counselor_bp.route('/session/<int:student_id>', methods=['POST'])
@login_required
@role_required('counselor', 'super_admin')
def add_session_note(student_id):
    student = User.query.get_or_404(student_id)
    observations = request.form.get('observations', '').strip()
    action_plan = request.form.get('action_plan', '').strip()
    follow_up_str = request.form.get('follow_up_date', '').strip()

    if not observations:
        flash("Session observations are required.", "danger")
        return redirect(url_for('counselor.student_profile', student_id=student.id))

    follow_up_date = None
    if follow_up_str:
        try:
            follow_up_date = datetime.strptime(follow_up_str, '%Y-%m-%d').date()
        except ValueError:
            pass

    note = CounselorSessionNote(
        student_id=student.id,
        counselor_id=current_user.id,
        observations=observations,
        action_plan=action_plan if action_plan else None,
        follow_up_date=follow_up_date,
        confidentiality_level='strictly_confidential'
    )
    db.session.add(note)
    db.session.commit()

    log_audit_action(current_user.id, 'mental_health_records', student.id, 'session_note_logged',
                     notes=f"Logged confidential counseling session note")

    create_notification(
        student.id,
        "Campus Wellness Center Update",
        f"A confidential wellness consultation summary was recorded. Next check-in: {follow_up_date or 'To be scheduled'}. We are here for you!",
        link=url_for('counselor.student_checkin')
    )

    flash("Confidential session notes saved and student notified.", "success")
    return redirect(url_for('counselor.student_profile', student_id=student.id))


# ============================================================================
# STUDENT-FACING CONFIDENTIAL WELLBEING CHECK-IN
# ============================================================================

@counselor_bp.route('/checkin', methods=['GET', 'POST'])
@login_required
def student_checkin():
    if current_user.role != 'student' and not current_user.has_role('admin', 'super_admin'):
        flash("Student wellness check-in is intended for students.", "info")
        return redirect(url_for('counselor.dashboard'))

    wellbeing = calculate_student_wellbeing_index(current_user.id)

    if request.method == 'POST':
        stress_level = int(request.form.get('stress_level', 2) or 2)  # 1 to 5
        feeling_overwhelmed = request.form.get('overwhelmed') == 'yes'
        sleep_hours = float(request.form.get('sleep_hours', 7.0) or 7.0)
        feedback_text = request.form.get('thoughts', '').strip()

        # Compute self-distress score (0 - 100)
        distress = (stress_level * 15.0) + (25.0 if feeling_overwhelmed else 0.0) + (15.0 if sleep_hours < 6.0 else 0.0)
        distress = min(100.0, max(0.0, distress))

        wellbeing.self_distress_score = distress
        db.session.commit()

        # Recalculate full index
        calculate_student_wellbeing_index(current_user.id)

        # Notify counselors if distress is very high
        if distress >= 60.0:
            counselors = User.query.filter_by(role='counselor').all()
            for c in counselors:
                create_notification(
                    c.id,
                    "⚠️ High Distress Check-in Alert",
                    f"Student {current_user.name} reported high distress score ({distress:.0f}/100) during wellness check-in.",
                    link=url_for('counselor.student_profile', student_id=current_user.id)
                )

        flash("Thank you for checking in. Your responses are strictly confidential.", "success")
        return redirect(url_for('counselor.student_checkin'))

    return render_template('counselor/student_checkin.html', wellbeing=wellbeing)
