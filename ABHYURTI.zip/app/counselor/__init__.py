from flask import Blueprint

counselor_bp = Blueprint('counselor', __name__, url_prefix='/counselor')

from app.counselor import routes
