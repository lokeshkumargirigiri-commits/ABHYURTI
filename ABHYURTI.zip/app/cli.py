import click
import re
from app.extensions import db
from app.models import User, Role, StaffProfile

def register_cli_commands(app):
    @app.cli.command('create-superadmin')
    def create_superadmin():
        """Interactive CLI command to create the initial Super Admin account."""
        click.echo("==================================================")
        click.echo("Fretbox Campus OS - Initial Super Admin Setup")
        click.echo("==================================================")
        name = click.prompt("Full Name", type=str).strip()
        email = click.prompt("Official Email Address", type=str).strip().lower()
        phone = click.prompt("Mobile Number", type=str).strip()
        password = click.prompt("Secure Password", hide_input=True, confirmation_prompt=True)

        if not name or not email or not password:
            click.echo("Error: Full name, email, and password are required.")
            return

        if len(password) < 8 or not re.search(r'[A-Za-z]', password) or not re.search(r'\d', password):
            click.echo("Error: Password must be at least 8 characters with at least one letter and one number.")
            return

        clean_phone = re.sub(r'[\s\-\+]', '', phone)
        if clean_phone.startswith('91') and len(clean_phone) == 12:
            clean_phone = clean_phone[2:]
        if not re.match(r'^[6-9]\d{9}$', clean_phone):
            click.echo("Error: Please provide a valid 10-digit Indian mobile number.")
            return

        existing = User.query.filter((User.email == email) | (User.phone == phone)).first()
        if existing:
            click.echo(f"Error: A user with email '{email}' or phone '{phone}' already exists.")
            return

        super_role = Role.query.filter_by(name='super_admin').first()
        if not super_role:
            super_role = Role(
                name='super_admin',
                display_name='Super Admin',
                description='Full administrative authority',
                is_system_role=True
            )
            db.session.add(super_role)
            db.session.flush()

        admin_user = User(
            name=name,
            email=email,
            phone=phone,
            role='super_admin',
            status='active',
            is_active=True,
            email_verified=True,
            phone_verified=True,
            must_change_password=False
        )
        admin_user.set_password(password)
        admin_user.roles.append(super_role)
        db.session.add(admin_user)
        db.session.flush()

        staff_prof = StaffProfile(
            user_id=admin_user.id,
            employee_id="ADM-ROOT-01",
            department="Institutional Leadership",
            designation="Super Administrator",
            requested_role="super_admin"
        )
        db.session.add(staff_prof)
        db.session.commit()

        click.echo(f"SUCCESS: Super Admin account '{name}' ({email}) created successfully.")

    @app.cli.command('add-employee-code')
    @click.option('--code', prompt='Employee Code (e.g. EMP-FAC-999)', help='Unique pre-approved employee code')
    @click.option('--role', prompt='Role (faculty/warden/mess_manager/maintenance/office_staff/admin/super_admin)', help='Target role')
    @click.option('--name', default='', help='Name of intended staff member')
    @click.option('--department', default='', help='Department or section')
    def add_employee_code_cmd(code, role, name, department):
        """Add or issue a pre-approved employee code for staff registration."""
        from app.models import PreApprovedEmployeeCode
        code = code.strip().upper()
        role = role.strip().lower()
        if not code or not role:
            click.echo("Error: Both code and role are required.")
            return
        existing = PreApprovedEmployeeCode.query.filter_by(employee_code=code).first()
        if existing:
            click.echo(f"Error: Code '{code}' already exists with status '{existing.status}'.")
            return
        rec = PreApprovedEmployeeCode(
            employee_code=code,
            role=role,
            name=name.strip() or None,
            department=department.strip() or None,
            status='unused'
        )
        db.session.add(rec)
        db.session.commit()
        click.echo(f"SUCCESS: Pre-approved code '{code}' added for role '{role}'.")
