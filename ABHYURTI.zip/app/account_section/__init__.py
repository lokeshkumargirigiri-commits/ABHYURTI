from flask import Blueprint

account_bp = Blueprint('account_section', __name__, url_prefix='/account')

from app.account_section import routes
