import csv
import io
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, abort, Response, current_app
from flask_login import login_required, current_user
from app.account_section import account_bp
from app.extensions import db
from app.models import FeePayment, User
from app.utils.security import role_required, log_audit_action, create_notification
from app.services.receipt_service import sign_fee_payment, verify_fee_payment


@account_bp.route('/')
@account_bp.route('/dashboard')
@login_required
@role_required('account_staff', 'admin', 'super_admin')
def dashboard():
    semester = request.args.get('semester', type=int)
    status = request.args.get('status', '').strip().lower()
    from_date = request.args.get('from_date', '').strip()
    to_date = request.args.get('to_date', '').strip()

    query = FeePayment.query

    if semester:
        query = query.filter(FeePayment.semester == semester)
    if status and status != 'all':
        query = query.filter(FeePayment.status == status)

    if from_date:
        try:
            d_from = datetime.strptime(from_date, '%Y-%m-%d')
            query = query.filter(FeePayment.created_at >= d_from)
        except ValueError:
            pass

    if to_date:
        try:
            d_to = datetime.strptime(to_date, '%Y-%m-%d')
            query = query.filter(FeePayment.created_at <= d_to)
        except ValueError:
            pass

    payments = query.order_by(FeePayment.created_at.desc()).all()

    # Calculate KPIs
    all_records = FeePayment.query.all()
    total_collected = sum(p.total_payable for p in all_records if p.status == 'paid')
    total_pending = sum(p.total_payable for p in all_records if p.status == 'pending')
    total_concessions = sum(p.concession_amount or 0.0 for p in all_records)

    students = User.query.filter_by(role='student').order_by(User.name.asc()).all()

    return render_template('account/dashboard.html',
                           payments=payments,
                           students=students,
                           total_collected=total_collected,
                           total_pending=total_pending,
                           total_concessions=total_concessions,
                           selected_semester=semester,
                           selected_status=status,
                           from_date=from_date,
                           to_date=to_date)


@account_bp.route('/export')
@account_bp.route('/export-csv')
@login_required
@role_required('account_staff', 'admin', 'super_admin')
def export_csv():
    semester = request.args.get('semester', type=int)
    status = request.args.get('status', '').strip().lower()

    query = FeePayment.query
    if semester:
        query = query.filter(FeePayment.semester == semester)
    if status and status != 'all':
        query = query.filter(FeePayment.status == status)

    records = query.order_by(FeePayment.created_at.desc()).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'Receipt Token', 'Student Name', 'Roll Number', 'Branch', 'Semester',
        'Fee Type', 'Base Amount (INR)', 'Late Fine (INR)', 'Concession (INR)',
        'Total Paid (INR)', 'Status', 'Payment Method', 'Transaction Ref',
        'Paid Date', 'HMAC SHA256 Signature'
    ])

    for r in records:
        student_name = r.student.name if r.student else 'Unknown'
        roll = r.student.roll_number if r.student else 'N/A'
        branch = r.student.branch if r.student else 'N/A'
        paid_str = r.paid_at.strftime('%Y-%m-%d %H:%M:%S') if r.paid_at else 'Unpaid'

        writer.writerow([
            r.receipt_token or 'N/A',
            student_name,
            roll,
            branch,
            r.semester or 'N/A',
            r.fee_type.title(),
            f"{r.amount:.2f}",
            f"{r.late_fine or 0.0:.2f}",
            f"{r.concession_amount or 0.0:.2f}",
            f"{r.total_payable:.2f}",
            r.status.upper(),
            r.payment_method or 'N/A',
            r.transaction_ref or 'N/A',
            paid_str,
            r.receipt_signature or 'N/A'
        ])

    log_audit_action(current_user.id, 'fee_ledger', 0, 'export_csv', notes="Exported fee collections ledger")

    filename = f"abhyurti_fee_collections_export_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@account_bp.route('/concession/<int:id>', methods=['POST'])
@login_required
@role_required('account_staff', 'admin', 'super_admin')
def apply_concession(id):
    payment = FeePayment.query.get_or_404(id)
    concession_amount = float(request.form.get('concession_amount', 0.0) or 0.0)
    reason = request.form.get('concession_reason', '').strip()

    if concession_amount < 0 or concession_amount > payment.amount:
        flash("Concession amount must be between 0 and total fee amount.", "danger")
        return redirect(url_for('account_section.dashboard'))

    payment.concession_amount = concession_amount
    payment.concession_reason = reason
    db.session.commit()

    log_audit_action(current_user.id, 'fee_payment', payment.id, 'applied_concession',
                     notes=f"Granted Rs {concession_amount:.2f} concession: {reason}")
    create_notification(
        payment.student_id,
        "Fee Concession Approved",
        f"A fee concession of ₹{concession_amount:,.2f} has been approved for your {payment.fee_type} fee. Reason: {reason}",
        link=url_for('account_section.student_fees')
    )
    flash(f"Concession of ₹{concession_amount:,.2f} applied successfully.", "success")
    return redirect(url_for('account_section.dashboard'))


@account_bp.route('/create-demand', methods=['POST'])
@login_required
@role_required('account_staff', 'admin', 'super_admin')
def create_demand():
    student_id = request.form.get('student_id', type=int)
    fee_type = request.form.get('fee_type', 'semester').strip()
    semester = request.form.get('semester', type=int)
    amount = float(request.form.get('amount', 0.0) or 0.0)
    academic_year = request.form.get('academic_year', '2024-2025').strip()

    if not student_id or amount <= 0:
        flash("Please specify a valid student and positive fee amount.", "danger")
        return redirect(url_for('account_section.dashboard'))

    student = User.query.get_or_404(student_id)
    payment = FeePayment(
        student_id=student.id,
        fee_type=fee_type,
        semester=semester,
        academic_year=academic_year,
        amount=amount,
        status='pending'
    )
    db.session.add(payment)
    db.session.commit()

    create_notification(
        student.id,
        f"New {fee_type.title()} Fee Due",
        f"A fee of ₹{amount:,.2f} has been posted for Semester {semester}. Please clear dues to ensure exam clearance.",
        link=url_for('account_section.student_fees')
    )
    flash(f"Fee demand of ₹{amount:,.2f} generated for {student.name}.", "success")
    return redirect(url_for('account_section.dashboard'))


# ============================================================================
# STUDENT-FACING FEE ROUTES & MOCK PAYMENT GATEWAY
# ============================================================================

@account_bp.route('/student/fees')
@account_bp.route('/my-fees')
@login_required
def student_fees():
    if current_user.role != 'student' and not current_user.has_role('admin', 'super_admin'):
        flash("Fee portal is reserved for students.", "warning")
        return redirect(url_for('account_section.dashboard'))

    payments = FeePayment.query.filter_by(student_id=current_user.id).order_by(FeePayment.created_at.desc()).all()
    pending_total = sum(p.total_payable for p in payments if p.status == 'pending')
    paid_total = sum(p.total_payable for p in payments if p.status == 'paid')

    return render_template('account/student_fees.html',
                           payments=payments,
                           pending_total=pending_total,
                           paid_total=paid_total)


@account_bp.route('/student/pay/<int:id>', methods=['GET', 'POST'])
@login_required
def mock_payment(id):
    payment = FeePayment.query.get_or_404(id)
    if payment.student_id != current_user.id and not current_user.has_role('admin', 'super_admin'):
        abort(403)

    if payment.status == 'paid':
        flash("This fee has already been paid.", "info")
        return redirect(url_for('account_section.receipt', id=payment.id))

    if request.method == 'POST':
        method = request.form.get('payment_method', 'mock_upi').strip()
        txn_ref = f"MOCK-TXN-{int(datetime.utcnow().timestamp())}-{payment.id}"

        payment.status = 'paid'
        payment.payment_method = method
        payment.transaction_ref = txn_ref
        payment.paid_at = datetime.utcnow()

        # Sign cryptographically with HMAC SHA-256
        sign_fee_payment(payment)
        db.session.commit()

        log_audit_action(current_user.id, 'fee_payment', payment.id, 'paid',
                         notes=f"Paid ₹{payment.total_payable:.2f} via {method} (Token: {payment.receipt_token})")

        create_notification(
            payment.student_id,
            "Payment Successful",
            f"Your payment of ₹{payment.total_payable:,.2f} for {payment.fee_type.title()} Fee was successful. Receipt Token: {payment.receipt_token}",
            link=url_for('account_section.receipt', id=payment.id)
        )

        flash("Payment completed successfully! Official cryptographic receipt generated.", "success")
        return redirect(url_for('account_section.receipt', id=payment.id))

    return render_template('account/mock_payment.html', payment=payment)


@account_bp.route('/receipt/<int:id>')
@login_required
def receipt(id):
    payment = FeePayment.query.get_or_404(id)
    if payment.student_id != current_user.id and not current_user.has_role('account_staff', 'admin', 'super_admin'):
        abort(403)

    # Ensure signed
    if payment.status == 'paid' and (not payment.receipt_token or not payment.receipt_signature):
        sign_fee_payment(payment)
        db.session.commit()

    is_verified = verify_fee_payment(payment)

    return render_template('account/receipt.html',
                           payment=payment,
                           is_verified=is_verified)


# ============================================================================
# PUBLIC CRYPTOGRAPHIC RECEIPT VERIFICATION ROUTE (NO LOGIN REQUIRED)
# ============================================================================

@account_bp.route('/verify/<token>')
def verify_receipt(token):
    payment = FeePayment.query.filter_by(receipt_token=token).first()
    if not payment:
        return render_template('account/verify_result.html', found=False, token=token), 404

    is_authentic = verify_fee_payment(payment)
    return render_template('account/verify_result.html',
                           found=True,
                           payment=payment,
                           is_authentic=is_authentic,
                           token=token)
