from flask import Blueprint

examination_bp = Blueprint('examination', __name__, url_prefix='/examination')

from app.examination import routes
