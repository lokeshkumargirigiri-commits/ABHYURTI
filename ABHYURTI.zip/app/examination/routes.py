from datetime import datetime, date
import csv, io
from flask import render_template, request, redirect, url_for, flash, abort, Response
from flask_login import login_required, current_user
from app.examination import examination_bp
from app.extensions import db
from app.models import ExamSchedule, FeePayment, User
from app.utils.security import role_required, log_audit_action, create_notification


def seed_default_exams():
    """Ensure baseline exam schedules exist if table is empty."""
    if ExamSchedule.query.count() == 0:
        samples = [
            ('CSE', 6, 'CS601', 'Cloud Computing & Distributed Systems', date(2026, 11, 10), '10:00 AM - 01:00 PM', 'Hall 101'),
            ('CSE', 6, 'CS602', 'Machine Learning & Neural Networks', date(2026, 11, 12), '10:00 AM - 01:00 PM', 'Hall 102'),
            ('CSE', 6, 'CS603', 'Information Security & Cryptography', date(2026, 11, 15), '10:00 AM - 01:00 PM', 'Hall 101'),
            ('ECE', 6, 'EC601', 'Digital Signal Processing', date(2026, 11, 11), '10:00 AM - 01:00 PM', 'Hall 201'),
            ('ME', 6, 'ME601', 'Heat Transfer & Thermodynamics', date(2026, 11, 13), '10:00 AM - 01:00 PM', 'Hall 301'),
        ]
        for dept, sem, code, name, edate, tslot, hall in samples:
            db.session.add(ExamSchedule(department=dept, semester=sem, subject_code=code, subject_name=name, exam_date=edate, time_slot=tslot, hall_number=hall))
        db.session.commit()


@examination_bp.route('/')
@examination_bp.route('/dashboard')
@login_required
@role_required('exam_staff', 'hod', 'admin', 'super_admin')
def dashboard():
    seed_default_exams()
    selected_dept = request.args.get('department', 'CSE').strip().upper()
    selected_sem = request.args.get('semester', 6, type=int)

    schedules = ExamSchedule.query.filter_by(
        department=selected_dept,
        semester=selected_sem
    ).order_by(ExamSchedule.exam_date.asc()).all()

    # Query students in this department and compute fee clearance
    students = User.query.filter_by(role='student').filter(
        (User.branch == selected_dept) | (User.branch.is_(None))
    ).all()

    student_clearance = []
    for s in students:
        pending_dues = FeePayment.query.filter_by(student_id=s.id, status='pending').all()
        due_sum = sum(p.total_payable for p in pending_dues)
        cleared = (due_sum == 0)
        student_clearance.append({
            'student': s,
            'cleared': cleared,
            'pending_amount': due_sum,
            'pending_count': len(pending_dues)
        })

    cleared_count = sum(1 for sc in student_clearance if sc['cleared'])
    blocked_count = len(student_clearance) - cleared_count

    return render_template('examination/dashboard.html',
                           schedules=schedules,
                           student_clearance=student_clearance,
                           selected_dept=selected_dept,
                           selected_sem=selected_sem,
                           cleared_count=cleared_count,
                           blocked_count=blocked_count)


@examination_bp.route('/schedule/add', methods=['POST'])
@login_required
@role_required('exam_staff', 'hod', 'admin', 'super_admin')
def add_schedule():
    dept = request.form.get('department', 'CSE').strip().upper()
    semester = request.form.get('semester', type=int)
    subject_code = request.form.get('subject_code', '').strip().upper()
    subject_name = request.form.get('subject_name', '').strip()
    date_str = request.form.get('exam_date', '').strip()
    time_slot = request.form.get('time_slot', '10:00 AM - 01:00 PM').strip()
    hall = request.form.get('hall_number', 'Main Academic Block - LH-1').strip()

    if not subject_code or not subject_name or not date_str:
        flash("Subject code, name, and exam date are required.", "danger")
        return redirect(url_for('examination.dashboard', department=dept, semester=semester))

    try:
        exam_date = datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        flash("Invalid exam date format.", "danger")
        return redirect(url_for('examination.dashboard', department=dept, semester=semester))

    schedule = ExamSchedule(
        department=dept,
        semester=semester,
        subject_code=subject_code,
        subject_name=subject_name,
        exam_date=exam_date,
        time_slot=time_slot,
        hall_number=hall
    )
    db.session.add(schedule)
    db.session.commit()

    log_audit_action(current_user.id, 'exam_schedule', schedule.id, 'created',
                     notes=f"Scheduled {subject_code} ({dept} Sem {semester}) on {date_str}")

    flash(f"Exam schedule for {subject_code} added successfully.", "success")
    return redirect(url_for('examination.dashboard', department=dept, semester=semester))


@examination_bp.route('/export')
@examination_bp.route('/export-csv')
@login_required
@role_required('exam_staff', 'hod', 'admin', 'super_admin')
def export_clearance_csv():
    """Export examination hall ticket candidate clearance ledger to CSV."""
    seed_default_exams()
    dept = request.args.get('department', 'CSE').strip()
    sem = request.args.get('semester', 6, type=int)

    students = User.query.filter(User.role == 'student').all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'Roll Number', 'Student Name', 'Branch', 'Hostel', 'Room',
        'Fee Clearance Status', 'Outstanding Dues (INR)', 'Hall Ticket Eligibility'
    ])

    for s in students:
        dues = sum(p.total_payable for p in FeePayment.query.filter_by(student_id=s.id, status='pending').all())
        cleared = dues == 0
        writer.writerow([
            s.roll_number or 'N/A',
            s.name,
            s.branch or 'N/A',
            s.hostel or 'N/A',
            s.room or 'N/A',
            'CLEARED' if cleared else 'DUES PENDING',
            f"{dues:.2f}",
            'ELIGIBLE (ADMIT ISSUED)' if cleared else 'BLOCKED (FEES OUTSTANDING)'
        ])

    log_audit_action(current_user.id, 'exam_clearance', 0, 'export_csv',
                     notes=f"Exported examination candidate clearance ledger for {dept} Sem {sem}")

    filename = f"abhyurti_exam_clearance_ledger_{dept}_Sem{sem}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.csv"
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


@examination_bp.route('/student/exams')
@examination_bp.route('/my-exams')
@login_required
def student_exams():
    seed_default_exams()
    dept = current_user.branch or 'CSE'
    sem = 6  # standard semester fallback

    schedules = ExamSchedule.query.filter_by(
        department=dept,
        semester=sem
    ).order_by(ExamSchedule.exam_date.asc()).all()

    # Check fee clearance
    pending_dues = FeePayment.query.filter_by(student_id=current_user.id, status='pending').all()
    due_amount = sum(p.total_payable for p in pending_dues)
    is_cleared = (due_amount == 0)

    return render_template('examination/student_exams.html',
                           schedules=schedules,
                           is_cleared=is_cleared,
                           due_amount=due_amount,
                           pending_count=len(pending_dues))


@examination_bp.route('/hall-ticket')
@examination_bp.route('/hall-ticket/<int:student_id>')
@login_required
def hall_ticket(student_id=None):
    seed_default_exams()
    if student_id and current_user.has_role('exam_staff', 'hod', 'admin', 'super_admin'):
        student = User.query.get_or_404(student_id)
    else:
        student = current_user

    dept = student.branch or 'CSE'
    sem = 6

    schedules = ExamSchedule.query.filter_by(
        department=dept,
        semester=sem
    ).order_by(ExamSchedule.exam_date.asc()).all()

    pending_dues = FeePayment.query.filter_by(student_id=student.id, status='pending').all()
    due_amount = sum(p.total_payable for p in pending_dues)
    is_cleared = (due_amount == 0)

    return render_template('examination/hall_ticket.html',
                           student=student,
                           schedules=schedules,
                           is_cleared=is_cleared,
                           due_amount=due_amount,
                           pending_dues=pending_dues)
