from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app.extensions import db
from app.models import (
    Complaint, GatePass, Notice, NoticeRead, AuditLog, User,
    Attendance, LeaveRequest, DocumentRequest, MessMenu, MessFeedback
)
from app.utils.audit import log_audit
from app.utils.targeting import get_notices_for_user, get_unread_notices_count
from app.utils.uploads import save_and_compress_photo
from app.auth.routes import role_required
from app.i18n import translate as _

student_bp = Blueprint('student', __name__)

@student_bp.route('/')
@login_required
def home():
    # Route each authenticated role to their isolated private dashboard
    if current_user.role == 'super_admin':
        return redirect(url_for('super_admin.dashboard'))
    elif current_user.role in ('admin', 'warden'):
        return redirect(url_for('admin.dashboard'))
    elif current_user.role == 'faculty':
        return redirect(url_for('faculty.dashboard'))
    elif current_user.role == 'mess_manager':
        return redirect(url_for('mess_manager.dashboard'))
    elif current_user.role == 'maintenance':
        return redirect(url_for('maintenance.dashboard'))
    elif current_user.role == 'office_staff':
        return redirect(url_for('office.dashboard'))

    # Active complaints
    active_complaints = Complaint.query.filter(
        Complaint.student_id == current_user.id,
        Complaint.status.notin_(['resolved', 'closed'])
    ).order_by(Complaint.created_at.desc()).all()

    # Active/latest gate pass
    latest_gate_pass = GatePass.query.filter_by(
        student_id=current_user.id
    ).order_by(GatePass.created_at.desc()).first()

    # Targeted notices & unread count
    notices = get_notices_for_user(current_user)
    unread_count = get_unread_notices_count(current_user)

    # Read notices lookup
    read_notice_ids = {
        nr.notice_id for nr in NoticeRead.query.filter_by(user_id=current_user.id).all()
    }

    return render_template(
        'student/home.html',
        active_complaints=active_complaints,
        latest_gate_pass=latest_gate_pass,
        notices=notices[:4],
        unread_count=unread_count,
        read_notice_ids=read_notice_ids
    )


@student_bp.route('/timeline')
@login_required
@role_required('student')
def timeline():
    """
    Unified Student Timeline - single chronological feed of all campus events
    affecting this student (complaints, gate passes, notices read/actioned).
    """
    timeline_events = []

    # 1. Complaints
    complaints = Complaint.query.filter_by(student_id=current_user.id).all()
    for c in complaints:
        timeline_events.append({
            'type': 'complaint',
            'title': f"Complaint #{c.id}: {c.category.title()} Issue",
            'subtitle': f"Room {c.room} ({c.hostel})",
            'description': c.description,
            'status': c.status,
            'timestamp': c.created_at,
            'link': url_for('student.complaint_detail', id=c.id),
            'icon': 'bi-wrench-adjustable',
            'color': 'primary',
            'badge': c.status.replace('_', ' ').title()
        })
        # If resolved, add a resolution milestone
        if c.resolved_at:
            timeline_events.append({
                'type': 'complaint_resolved',
                'title': f"Complaint #{c.id} Resolved",
                'subtitle': f"Notes: {c.resolution_notes or 'Issue fixed'}",
                'description': f"Resolution completed for {c.category} in Room {c.room}.",
                'status': 'resolved',
                'timestamp': c.resolved_at,
                'link': url_for('student.complaint_detail', id=c.id),
                'icon': 'bi-check2-circle',
                'color': 'success',
                'badge': 'Resolved'
            })

    # 2. Gate Passes
    passes = GatePass.query.filter_by(student_id=current_user.id).all()
    for gp in passes:
        icon = 'bi-exclamation-diamond' if gp.is_emergency else 'bi-box-arrow-right'
        color = 'danger' if gp.is_emergency else ('success' if gp.status == 'approved' else 'secondary')
        timeline_events.append({
            'type': 'gate_pass',
            'title': f"{'🚨 EMERGENCY ' if gp.is_emergency else ''}Gate Pass: {gp.destination}",
            'subtitle': f"From {gp.from_date.strftime('%d %b, %I:%M %p')} to {gp.to_date.strftime('%d %b, %I:%M %p')}",
            'description': f"Reason: {gp.reason}",
            'status': gp.status,
            'timestamp': gp.created_at,
            'link': url_for('student.gate_pass_detail', id=gp.id),
            'icon': icon,
            'color': color,
            'badge': gp.status.upper()
        })

    # 3. Notices received/actioned
    notices = get_notices_for_user(current_user)
    read_map = {
        nr.notice_id: nr for nr in NoticeRead.query.filter_by(user_id=current_user.id).all()
    }
    for n in notices:
        nr = read_map.get(n.id)
        status_label = "Unread"
        if nr:
            status_label = "Action Completed" if nr.action_at else "Read"
        
        timeline_events.append({
            'type': 'notice',
            'title': f"Notice: {n.title}",
            'subtitle': n.targeting_summary,
            'description': n.body[:140] + ('...' if len(n.body) > 140 else ''),
            'status': status_label.lower().replace(' ', '_'),
            'timestamp': n.published_at,
            'link': url_for('student.notice_detail', id=n.id),
            'icon': 'bi-megaphone',
            'color': 'info',
            'badge': status_label
        })

    # Sort all events chronologically descending
    timeline_events.sort(key=lambda x: x['timestamp'], reverse=True)

    filter_type = request.args.get('filter', 'all')
    if filter_type != 'all':
        timeline_events = [e for e in timeline_events if e['type'].startswith(filter_type)]

    return render_template('student/timeline.html', events=timeline_events, current_filter=filter_type)


@student_bp.route('/complaints')
@login_required
@role_required('student')
def complaints_list():
    category = request.args.get('category')
    status = request.args.get('status')
    
    query = Complaint.query.filter_by(student_id=current_user.id)
    if category:
        query = query.filter_by(category=category)
    if status:
        query = query.filter_by(status=status)
        
    complaints = query.order_by(Complaint.created_at.desc()).all()
    return render_template('student/complaints/list.html', complaints=complaints)


@student_bp.route('/complaints/new', methods=['GET', 'POST'])
@login_required
@role_required('student')
def complaint_new():
    if request.method == 'POST':
        category = request.form.get('category', '').strip()
        room = request.form.get('room', '').strip() or current_user.room or '101'
        hostel = request.form.get('hostel', '').strip() or current_user.hostel or 'Hostel A'
        description = request.form.get('description', '').strip()

        if not category or not description:
            flash("Please choose a category and enter an issue description.", "danger")
            return render_template('student/complaints/form.html')

        # Handle photo: check storage file, direct camera file, or base64 snapshot
        photo_file = request.files.get('photo')
        photo_camera_file = request.files.get('photo_camera')
        camera_base64 = request.form.get('photo_camera_data')

        uploaded_rel_path = None
        if camera_base64 and len(camera_base64) > 50:
            uploaded_rel_path = save_and_compress_photo(base64_data=camera_base64)
        elif photo_camera_file and photo_camera_file.filename:
            uploaded_rel_path = save_and_compress_photo(file_obj=photo_camera_file)
        elif photo_file and photo_file.filename:
            uploaded_rel_path = save_and_compress_photo(file_obj=photo_file)

        # Check for repeat issue: same room and category in the last 30 days
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        previous_count = Complaint.query.filter(
            Complaint.hostel == hostel,
            Complaint.room == room,
            Complaint.category == category,
            Complaint.created_at >= thirty_days_ago
        ).count()

        is_repeat = (previous_count > 0)

        complaint = Complaint(
            student_id=current_user.id,
            category=category,
            description=description,
            room=room,
            hostel=hostel,
            photo_path=uploaded_rel_path,
            status='submitted',
            is_repeat=is_repeat
        )
        db.session.add(complaint)
        db.session.commit()

        # Audit Log
        repeat_note = " [Auto-flagged as REPEAT ISSUE: previous ticket in last 30 days]" if is_repeat else ""
        log_audit(
            actor_id=current_user.id,
            entity_type='complaint',
            entity_id=complaint.id,
            action='created',
            new_status='submitted',
            notes=f"Student submitted complaint for {category} in Room {room}{repeat_note}"
        )

        flash(f"Complaint #{complaint.id} submitted successfully! The maintenance warden has been notified.", "success")
        if is_repeat:
            flash("Note: This issue was automatically flagged as a repeat problem for priority attention.", "warning")

        return redirect(url_for('student.complaint_detail', id=complaint.id))

    return render_template('student/complaints/form.html')


@student_bp.route('/complaints/<int:id>')
@login_required
@role_required('student')
def complaint_detail(id):
    complaint = Complaint.query.filter_by(id=id, student_id=current_user.id).first_or_404()
    audit_trail = AuditLog.query.filter_by(
        entity_type='complaint',
        entity_id=complaint.id
    ).order_by(AuditLog.created_at.asc()).all()

    return render_template('student/complaints/detail.html', complaint=complaint, audit_trail=audit_trail)


@student_bp.route('/gate-pass')
@login_required
@role_required('student')
def gate_pass_list():
    passes = GatePass.query.filter_by(
        student_id=current_user.id
    ).order_by(GatePass.created_at.desc()).all()
    return render_template('student/gate_pass/list.html', passes=passes)


@student_bp.route('/gate-pass/new', methods=['GET', 'POST'])
@login_required
@role_required('student')
def gate_pass_new():
    if request.method == 'POST':
        destination = request.form.get('destination', '').strip()
        reason = request.form.get('reason', '').strip()
        from_str = request.form.get('from_date', '').strip()
        to_str = request.form.get('to_date', '').strip()
        is_emergency = bool(request.form.get('is_emergency'))
        emergency_reason = request.form.get('emergency_reason', '').strip()
        notify_parent = bool(request.form.get('notify_parent'))

        if not destination or not reason or not from_str or not to_str:
            flash("Please fill in all required date, destination, and reason fields.", "danger")
            return render_template('student/gate_pass/form.html')

        try:
            from_date = datetime.strptime(from_str, '%Y-%m-%dT%H:%M')
            to_date = datetime.strptime(to_str, '%Y-%m-%dT%H:%M')
        except ValueError:
            flash("Invalid date format provided.", "danger")
            return render_template('student/gate_pass/form.html')

        gate_pass = GatePass(
            student_id=current_user.id,
            from_date=from_date,
            to_date=to_date,
            destination=destination,
            reason=reason,
            status='pending',
            is_emergency=is_emergency,
            emergency_reason=emergency_reason if is_emergency else None,
            parent_notified=notify_parent
        )
        db.session.add(gate_pass)
        db.session.commit()

        # Audit log
        emergency_flag = " [EMERGENCY - 30 MIN SLA ACTIVATED]" if is_emergency else ""
        parent_flag = " [Parent SMS Alert Queued]" if notify_parent else ""
        log_audit(
            actor_id=current_user.id,
            entity_type='gate_pass',
            entity_id=gate_pass.id,
            action='created',
            new_status='pending',
            notes=f"Gate pass requested to {destination}{emergency_flag}{parent_flag}"
        )

        if is_emergency:
            try:
                from app.services.notification_service import notify_emergency_gate_pass_raised
                notify_emergency_gate_pass_raised(gate_pass, current_user)
            except Exception as e:
                current_app.logger.warning(f"Error triggering emergency pass notifications: {e}")
            flash("🚨 Emergency Gate Pass submitted! Warden has been alerted with top-queue SLA priority.", "danger")
        else:
            flash("Gate pass request submitted for hostel warden approval.", "success")

        return redirect(url_for('student.gate_pass_detail', id=gate_pass.id))

    return render_template('student/gate_pass/form.html')


@student_bp.route('/gate-pass/<int:id>')
@login_required
@role_required('student')
def gate_pass_detail(id):
    gate_pass = GatePass.query.filter_by(id=id, student_id=current_user.id).first_or_404()
    audit_trail = AuditLog.query.filter_by(
        entity_type='gate_pass',
        entity_id=gate_pass.id
    ).order_by(AuditLog.created_at.asc()).all()

    return render_template('student/gate_pass/detail.html', gate_pass=gate_pass, audit_trail=audit_trail)


@student_bp.route('/notices')
@login_required
@role_required('student')
def notices_list():
    notices = get_notices_for_user(current_user)
    read_map = {
        nr.notice_id: nr for nr in NoticeRead.query.filter_by(user_id=current_user.id).all()
    }
    return render_template('student/notices/list.html', notices=notices, read_map=read_map)


@student_bp.route('/notices/<int:id>')
@login_required
@role_required('student')
def notice_detail(id):
    notice = Notice.query.get_or_404(id)
    
    # Mark read if not already marked
    read_record = NoticeRead.query.filter_by(notice_id=notice.id, user_id=current_user.id).first()
    if not read_record:
        read_record = NoticeRead(
            notice_id=notice.id,
            user_id=current_user.id,
            read_at=datetime.utcnow()
        )
        db.session.add(read_record)
        db.session.commit()

    return render_template('student/notices/detail.html', notice=notice, read_record=read_record)


@student_bp.route('/notices/<int:id>/action', methods=['POST'])
@login_required
@role_required('student')
def notice_action(id):
    notice = Notice.query.get_or_404(id)
    read_record = NoticeRead.query.filter_by(notice_id=notice.id, user_id=current_user.id).first()
    if not read_record:
        read_record = NoticeRead(
            notice_id=notice.id,
            user_id=current_user.id,
            read_at=datetime.utcnow(),
            action_at=datetime.utcnow()
        )
        db.session.add(read_record)
    else:
        read_record.action_at = datetime.utcnow()
    
    db.session.commit()

    # Log action audit
    log_audit(
        actor_id=current_user.id,
        entity_type='notice',
        entity_id=notice.id,
        action='action_taken',
        notes=f"Student confirmed action for notice: {notice.title}"
    )

    flash(f"Action '{notice.action_label}' confirmed successfully!", "success")
    return redirect(url_for('student.notice_detail', id=notice.id))


# Fully functional student workflows
@student_bp.route('/attendance')
@login_required
@role_required('student', 'super_admin', 'admin')
def attendance_stub():
    attendances = Attendance.query.filter_by(student_id=current_user.id).order_by(Attendance.date.desc()).all()
    total_classes = len(attendances)
    present_classes = sum(1 for a in attendances if a.status == 'present')
    overall_percentage = round((present_classes / total_classes * 100), 1) if total_classes > 0 else 85.0

    # Group by subject
    subjects_dict = {}
    for a in attendances:
        subjects_dict.setdefault(a.subject_code, {'name': a.subject_name, 'total': 0, 'present': 0})
        subjects_dict[a.subject_code]['total'] += 1
        if a.status == 'present':
            subjects_dict[a.subject_code]['present'] += 1

    return render_template(
        'student/stubs/attendance.html',
        attendances=attendances,
        total_classes=total_classes,
        present_classes=present_classes,
        overall_percentage=overall_percentage,
        subjects_dict=subjects_dict
    )


@student_bp.route('/mess', methods=['GET', 'POST'])
@login_required
@role_required('student', 'super_admin', 'admin')
def mess_stub():
    from app.models import MessMenu, MessFeedback, CanteenIssueReport, SystemSetting
    if request.method == 'POST':
        rating = request.form.get('rating', type=int) or 4
        category = request.form.get('category', 'food_quality').strip()
        meal_type = request.form.get('meal_type', 'Lunch').strip()
        feedback_text = request.form.get('feedback_text', '').strip()

        if not feedback_text:
            flash("Please enter your feedback comments.", "danger")
            return redirect(url_for('student.mess_stub'))

        fb = MessFeedback(
            student_id=current_user.id,
            rating=rating,
            category=category,
            meal_type=meal_type,
            feedback_text=feedback_text,
            status='new'
        )
        db.session.add(fb)
        db.session.commit()

        log_audit(actor_id=current_user.id, entity_type='mess_feedback', entity_id=fb.id, action='submitted', notes=f"Rating: {rating} stars, category: {category}")
        flash("Thank you! Your mess feedback has been submitted to the Mess Manager.", "success")
        return redirect(url_for('student.mess_stub'))

    menus = MessMenu.query.order_by(MessMenu.day_of_week.asc()).all()
    my_feedbacks = MessFeedback.query.filter_by(student_id=current_user.id).order_by(MessFeedback.created_at.desc()).all()
    my_canteen_issues = CanteenIssueReport.query.filter_by(student_id=current_user.id).order_by(CanteenIssueReport.created_at.desc()).all()

    # Outside food ordering permission
    outside_setting = SystemSetting.query.filter_by(key='allow_outside_food_ordering').first()
    allow_outside_food = True if not outside_setting or outside_setting.value.lower() != 'false' else False

    return render_template(
        'student/stubs/mess.html',
        menus=menus,
        feedbacks=my_feedbacks,
        canteen_issues=my_canteen_issues,
        allow_outside_food=allow_outside_food
    )


@student_bp.route('/canteen/report-issue', methods=['POST'])
@login_required
@role_required('student', 'super_admin', 'admin')
def report_canteen_issue():
    from app.models import CanteenIssueReport
    food_name = request.form.get('food_name', '').strip()
    issue_type = request.form.get('issue_type', 'Hygiene / Quality').strip()
    meal_type = request.form.get('meal_type', 'Lunch').strip()
    notes = request.form.get('notes', '').strip()

    if not food_name:
        flash("Please enter the food item name.", "danger")
        return redirect(url_for('student.mess_stub'))

    issue = CanteenIssueReport(
        student_id=current_user.id,
        hostel=current_user.hostel or 'Hostel A',
        food_name=food_name,
        issue_type=issue_type,
        meal_type=meal_type,
        notes=notes,
        status='pending'
    )
    db.session.add(issue)
    db.session.commit()

    log_audit(actor_id=current_user.id, entity_type='canteen_issue', entity_id=issue.id, action='reported', notes=f"Reported {food_name}: {issue_type}")
    flash(f"Your food complaint regarding '{food_name}' has been lodged with the Warden and Mess administration.", "success")
    return redirect(url_for('student.mess_stub'))



@student_bp.route('/certificates', methods=['GET', 'POST'])
@login_required
@role_required('student', 'super_admin', 'admin')
def certificates_stub():
    from app.models import DocumentRequest
    if request.method == 'POST':
        doc_type = request.form.get('document_type', 'bonafide').strip()
        reason = request.form.get('reason', '').strip()

        if not reason:
            flash("Please specify the purpose or reason for requesting this document.", "danger")
            return redirect(url_for('student.certificates_stub'))

        req = DocumentRequest(
            student_id=current_user.id,
            document_type=doc_type,
            reason=reason,
            status='submitted'
        )
        db.session.add(req)
        db.session.commit()

        log_audit(actor_id=current_user.id, entity_type='document_request', entity_id=req.id, action='requested', notes=f"Requested {doc_type} certificate")
        flash(f"Your application for {doc_type.replace('_', ' ').title()} has been submitted to the Academic Office.", "success")
        return redirect(url_for('student.certificates_stub'))

    my_requests = DocumentRequest.query.filter_by(student_id=current_user.id).order_by(DocumentRequest.created_at.desc()).all()
    fee_dues = current_user.student_profile.fee_dues if current_user.student_profile else 0.0
    return render_template('student/stubs/certificates.html', requests=my_requests, fee_dues=fee_dues)


@student_bp.route('/leaves', methods=['GET', 'POST'])
@login_required
@role_required('student', 'super_admin', 'admin')
def leaves_list():
    from app.models import LeaveRequest
    if request.method == 'POST':
        from_str = request.form.get('from_date', '').strip()
        to_str = request.form.get('to_date', '').strip()
        reason = request.form.get('reason', '').strip()

        if not from_str or not to_str or not reason:
            flash("Please fill out leave start date, end date, and reason.", "danger")
            return redirect(url_for('student.leaves_list'))

        from_dt = datetime.strptime(from_str, '%Y-%m-%dT%H:%M') if 'T' in from_str else datetime.strptime(from_str, '%Y-%m-%d')
        to_dt = datetime.strptime(to_str, '%Y-%m-%dT%H:%M') if 'T' in to_str else datetime.strptime(to_str, '%Y-%m-%d')

        leave = LeaveRequest(
            student_id=current_user.id,
            start_date=from_dt,
            end_date=to_dt,
            reason=reason,
            status='pending'
        )
        db.session.add(leave)
        db.session.commit()

        log_audit(actor_id=current_user.id, entity_type='leave_request', entity_id=leave.id, action='submitted', notes=f"Student applied for leave")
        flash("Leave request submitted for faculty approval!", "success")
        return redirect(url_for('student.leaves_list'))

    leaves = LeaveRequest.query.filter_by(student_id=current_user.id).order_by(LeaveRequest.created_at.desc()).all()
    return render_template('student/leaves.html', leaves=leaves)


@student_bp.route('/campus-map')
@login_required
def campus_map():
    """Interactive campus navigation and hostel/facility map."""
    from app.services.maps_service import get_campus_map_data
    map_data = get_campus_map_data()
    return render_template('campus_map/index.html', map_data=map_data)


@student_bp.route('/ai-assistant')
@login_required
def ai_assistant():
    """Campus AI Copilot Full-Page Assistant."""
    return render_template('ai/assistant.html')


# ============================================================================
# STUDENT ASSIGNMENTS & HOMEWORK (SPEC H.1)
# ============================================================================

@student_bp.route('/assignments', endpoint='assignments_list')
@student_bp.route('/student/assignments', endpoint='student_assignments')
@login_required
def student_assignments():
    from app.models import Assignment, AssignmentSubmission
    dept = current_user.branch or 'CSE'
    assignments = Assignment.query.filter(
        (Assignment.department == dept) | (Assignment.department.is_(None))
    ).order_by(Assignment.due_date.asc()).all()

    my_subs = AssignmentSubmission.query.filter_by(student_id=current_user.id).all()
    my_submissions = {s.assignment_id: s for s in my_subs}

    return render_template('student/assignments.html',
                           assignments=assignments,
                           my_submissions=my_submissions)


@student_bp.route('/assignments/submit/<int:assignment_id>', methods=['POST'])
@login_required
def assignment_submit(assignment_id):
    from app.models import Assignment, AssignmentSubmission
    assign = Assignment.query.get_or_404(assignment_id)
    sub_text = request.form.get('submission_text', '').strip()
    file_path = request.form.get('file_path', '').strip()

    if not sub_text and not file_path:
        flash("Please provide solution writeup or cloud document link.", "warning")
        return redirect(url_for('student.student_assignments'))

    now = datetime.utcnow()
    is_late = (now > assign.due_date) if assign.due_date else False

    sub = AssignmentSubmission.query.filter_by(
        assignment_id=assign.id,
        student_id=current_user.id
    ).first()

    if not sub:
        sub = AssignmentSubmission(
            assignment_id=assign.id,
            student_id=current_user.id,
            submission_text=sub_text if sub_text else None,
            file_path=file_path if file_path else None,
            submitted_at=now,
            is_late=is_late
        )
        db.session.add(sub)
    else:
        sub.submission_text = sub_text if sub_text else None
        sub.file_path = file_path if file_path else None
        sub.submitted_at = now
        sub.is_late = is_late

    db.session.commit()
    flash(f"Solution for '{assign.title}' submitted successfully{' (Late Submission logged)' if is_late else ''}!", "success")
    return redirect(url_for('student.student_assignments'))


