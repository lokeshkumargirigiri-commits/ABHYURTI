import os
from datetime import timedelta
from dotenv import load_dotenv

basedir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
# Load .env file if available
load_dotenv(os.path.join(basedir, '.env'))

class Config:
    # Application Brand Name
    APP_NAME = os.environ.get('APP_NAME', 'ABHYURTI')

    # SECRET_KEY sourced strictly from environment variable with runtime random fallback
    SECRET_KEY = os.environ.get('SECRET_KEY') or os.urandom(32).hex()

    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'fretbox.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.path.join(basedir, 'static', 'uploads')
    QR_FOLDER = os.path.join(basedir, 'static', 'qr')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}
    DEFAULT_LOCALE = 'en'
    LANGUAGES = ['en', 'hi', 'or', 'ta', 'bn', 'te', 'mr']

    # Session & Cookie Security (Step 4)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'False').lower() in ('true', '1') or os.environ.get('FLASK_ENV') == 'production'
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)

    # CSRF Protection
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = 86400

    # Rate Limiting (Flask-Limiter)
    RATELIMIT_DEFAULT = "500 per day; 100 per hour"
    RATELIMIT_STORAGE_URI = "memory://"
