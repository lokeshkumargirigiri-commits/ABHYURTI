import os
import qrcode
from flask import current_app

def generate_room_qr(hostel, room):
    """Generates a QR code image for a room inspection URL."""
    qr_folder = current_app.config.get('QR_FOLDER')
    os.makedirs(qr_folder, exist_ok=True)
    filename = f"qr_{hostel.replace(' ', '_')}_{room}.png"
    filepath = os.path.join(qr_folder, filename)

    if not os.path.exists(filepath):
        # Generate QR code targeting room inspect route
        qr_url = f"/admin/room/{hostel}/{room}"
        qr = qrcode.QRCode(
            version=1,
            box_size=6,
            border=2,
        )
        qr.add_data(qr_url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(filepath)

    return f"qr/{filename}"
