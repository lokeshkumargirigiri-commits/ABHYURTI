import os
import io
import uuid
import base64
from PIL import Image
from werkzeug.utils import secure_filename
from flask import current_app

def save_and_compress_photo(file_obj=None, base64_data=None):
    """
    Saves and compresses an image either from an uploaded FileStorage object
    or a Base64 string from direct browser camera capture.
    Resizes image to max 800x800 px maintaining aspect ratio,
    converts to RGB and saves as compressed JPEG.
    """
    upload_folder = current_app.config['UPLOAD_FOLDER']
    os.makedirs(upload_folder, exist_ok=True)
    filename = f"cmp_{uuid.uuid4().hex[:12]}.jpg"
    dest_path = os.path.join(upload_folder, filename)

    img = None
    try:
        if base64_data and base64_data.startswith('data:image'):
            # Camera snapshot from canvas
            header, encoded = base64_data.split(',', 1)
            image_bytes = base64.b64decode(encoded)
            img = Image.open(io.BytesIO(image_bytes))
        elif file_obj and file_obj.filename:
            # File from input[type=file]
            img = Image.open(file_obj.stream)
        else:
            return None

        # Convert to RGB (handles RGBA / PNG transparent backgrounds)
        if img.mode in ('RGBA', 'LA', 'P'):
            rgb_img = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'P':
                img = img.convert('RGBA')
            rgb_img.paste(img, mask=img.split()[-1] if 'A' in img.getbands() else None)
            img = rgb_img
        elif img.mode != 'RGB':
            img = img.convert('RGB')

        # Resize to max 800x800
        max_size = (800, 800)
        img.thumbnail(max_size, Image.Resampling.LANCZOS)

        # Buffer for compressed JPEG
        buf = io.BytesIO()
        img.save(buf, 'JPEG', quality=80, optimize=True)
        compressed_bytes = buf.getvalue()

        # 1. Attempt Cloudinary Cloud Upload
        try:
            from app.services.storage_service import upload_to_cloudinary
            cdn_url = upload_to_cloudinary(compressed_bytes, filename=filename)
            if cdn_url:
                return cdn_url
        except Exception as e:
            current_app.logger.warning(f"Cloudinary upload fallback to disk: {e}")

        # 2. Local Disk Fallback
        with open(dest_path, 'wb') as f:
            f.write(compressed_bytes)

        return f"uploads/{filename}"
    except Exception as e:
        current_app.logger.error(f"Error compressing photo: {e}")
        return None
