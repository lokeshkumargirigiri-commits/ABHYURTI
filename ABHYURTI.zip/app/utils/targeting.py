from datetime import datetime
from app.extensions import db
from app.models import Notice, NoticeRead, User

def get_notices_for_user(user):
    """Fetch active published notices targeted to a given student."""
    if not user or not user.is_authenticated or user.role != 'student':
        return []

    now = datetime.utcnow()
    query = Notice.query.filter(Notice.status == 'published')
    
    # Check expiry if set
    query = query.filter(
        db.or_(Notice.expires_at.is_(None), Notice.expires_at > now)
    )

    # Filter matching criteria (NULL means applies to all)
    if user.hostel:
        query = query.filter(db.or_(Notice.target_hostel.is_(None), Notice.target_hostel == user.hostel))
    if user.year:
        query = query.filter(db.or_(Notice.target_year.is_(None), Notice.target_year == user.year))
    if user.branch:
        query = query.filter(db.or_(Notice.target_branch.is_(None), Notice.target_branch == user.branch))
    if user.batch:
        query = query.filter(db.or_(Notice.target_batch.is_(None), Notice.target_batch == user.batch))

    return query.order_by(Notice.published_at.desc()).all()


def get_targeted_users_query(notice):
    """Return User query filtered for students targeted by a notice."""
    query = User.query.filter(User.role == 'student')
    if notice.target_hostel:
        query = query.filter(User.hostel == notice.target_hostel)
    if notice.target_year:
        query = query.filter(User.year == notice.target_year)
    if notice.target_branch:
        query = query.filter(User.branch == notice.target_branch)
    if notice.target_batch:
        query = query.filter(User.batch == notice.target_batch)
    return query


def get_targeted_users_count(notice):
    return get_targeted_users_query(notice).count()


def get_unread_notices_count(user):
    """Count how many targeted notices this student has not yet read."""
    if not user or not user.is_authenticated or user.role != 'student':
        return 0
    notices = get_notices_for_user(user)
    if not notices:
        return 0
    
    read_notice_ids = {
        nr.notice_id for nr in NoticeRead.query.filter_by(user_id=user.id).all()
    }
    return sum(1 for n in notices if n.id not in read_notice_ids)
