import hashlib
import secrets
from datetime import datetime, timedelta
from functools import wraps
from flask import request, redirect, url_for, flash, abort, session
from flask_login import current_user
from app.extensions import db
from app.models import (
    OTPVerification, UserSession, User, Role, Permission,
    Notification, AuditLog
)

OTP_PEPPER = "fretbox-campus-otp-salt-2026"
MAX_LOGIN_ATTEMPTS = 5
LOCKOUT_DURATION_MINUTES = 15

def hash_otp(otp_code: str) -> str:
    """Hash OTP with SHA-256 and internal pepper. Never store plain OTP."""
    payload = f"{OTP_PEPPER}:{otp_code}".encode('utf-8')
    return hashlib.sha256(payload).hexdigest()


def generate_numeric_otp(length: int = 6) -> str:
    """Generate cryptographically secure numeric OTP."""
    # Ensure full 6-digit with leading zeros allowed
    range_start = 10**(length - 1)
    range_end = (10**length) - 1
    return str(secrets.randbelow(range_end - range_start + 1) + range_start)


def create_or_update_otp(identifier: str, purpose: str, validity_minutes: int = 10, cooldown_seconds: int = 60):
    """
    Creates or updates OTP record for phone or email.
    Enforces 60-second cooldown rate limit.
    Returns: (record, plain_otp) or (None, error_message)
    """
    identifier = identifier.strip().lower()
    now = datetime.utcnow()

    # Check for active cooldown rate limit
    recent = OTPVerification.query.filter_by(
        identifier=identifier,
        purpose=purpose,
        is_verified=False
    ).order_by(OTPVerification.created_at.desc()).first()

    if recent and recent.resend_available_at > now:
        remaining_seconds = int((recent.resend_available_at - now).total_seconds())
        return None, f"Please wait {remaining_seconds} seconds before requesting a new OTP."

    plain_otp = generate_numeric_otp(6)
    hashed = hash_otp(plain_otp)
    expires_at = now + timedelta(minutes=validity_minutes)
    resend_at = now + timedelta(seconds=cooldown_seconds)

    record = OTPVerification(
        identifier=identifier,
        otp_hash=hashed,
        purpose=purpose,
        attempts=0,
        max_attempts=3,
        is_verified=False,
        expires_at=expires_at,
        resend_available_at=resend_at,
        created_at=now
    )
    db.session.add(record)
    db.session.commit()
    return record, plain_otp


def verify_otp(identifier: str, submitted_otp: str, purpose: str):
    """
    Verifies user-submitted OTP against hashed value with attempt throttling.
    Returns: (success: bool, message: str)
    """
    identifier = identifier.strip().lower()
    now = datetime.utcnow()

    record = OTPVerification.query.filter_by(
        identifier=identifier,
        purpose=purpose,
        is_verified=False
    ).order_by(OTPVerification.created_at.desc()).first()

    if not record:
        return False, "No OTP verification pending. Please request a new OTP."

    if record.is_expired:
        return False, "OTP has expired. Please request a new code."

    if record.attempts >= record.max_attempts:
        return False, "Maximum verification attempts exceeded. Please request a new OTP."

    record.attempts += 1
    submitted_hash = hash_otp(submitted_otp.strip())

    if submitted_hash != record.otp_hash:
        db.session.commit()
        remaining = record.max_attempts - record.attempts
        if remaining > 0:
            return False, f"Invalid OTP. {remaining} attempt(s) remaining."
        return False, "Invalid OTP. Maximum attempts exceeded. Please request a new code."

    # Success
    record.is_verified = True
    db.session.commit()
    return True, "OTP verified successfully."


def register_failed_login(user: User):
    """Handle rate-limiting for failed password login attempts."""
    user.failed_login_attempts = (user.failed_login_attempts or 0) + 1
    if user.failed_login_attempts >= MAX_LOGIN_ATTEMPTS:
        user.locked_until = datetime.utcnow() + timedelta(minutes=LOCKOUT_DURATION_MINUTES)
    db.session.commit()


def register_successful_login(user: User, ip_address=None, user_agent=None):
    """Reset failed attempts, log timestamp and establish tracked user session."""
    user.failed_login_attempts = 0
    user.locked_until = None
    user.last_login_at = datetime.utcnow()
    db.session.commit()

    # Track active session
    session_token = secrets.token_urlsafe(48)
    user_session = UserSession(
        user_id=user.id,
        session_token=session_token,
        ip_address=ip_address or request.remote_addr,
        user_agent=(user_agent or request.user_agent.string)[:250] if request.user_agent else 'Browser',
        is_active=True,
        created_at=datetime.utcnow(),
        last_activity_at=datetime.utcnow(),
        expires_at=datetime.utcnow() + timedelta(days=7)
    )
    db.session.add(user_session)
    db.session.commit()
    session['session_token'] = session_token
    return user_session


def terminate_current_session(user_id: int):
    """Terminate the current device session on logout."""
    token = session.get('session_token')
    if token:
        sess = UserSession.query.filter_by(session_token=token, user_id=user_id).first()
        if sess:
            sess.is_active = False
            db.session.commit()
    session.pop('session_token', None)


def create_notification(user_id: int, title: str, message: str, category: str = 'system', link: str = None):
    """Create in-app user notification."""
    notif = Notification(
        user_id=user_id,
        title=title,
        message=message,
        category=category,
        link=link,
        is_read=False,
        created_at=datetime.utcnow()
    )
    db.session.add(notif)
    db.session.commit()
    return notif


def log_audit_action(actor_id, entity_type, entity_id, action, old_status=None, new_status=None, notes=None, ip_address=None):
    """Standardized audit log helper."""
    client_ip = ip_address or (request.remote_addr if request else None)
    log = AuditLog(
        actor_id=actor_id,
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        old_status=old_status,
        new_status=new_status,
        notes=notes,
        ip_address=client_ip,
        created_at=datetime.utcnow()
    )
    db.session.add(log)
    db.session.commit()
    return log


def role_required(*roles):
    """Check if current user has any of the authorized roles."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return redirect(url_for('auth.login', next=request.url))
            
            # Verify account status
            if current_user.status == 'pending_verification':
                flash("Your account is pending verification by Super Admin.", "warning")
                return redirect(url_for('auth.pending_approval'))
            if current_user.status in ('deactivated', 'rejected') or not current_user.is_active:
                flash("Your account is deactivated or rejected. Please contact administration.", "danger")
                return redirect(url_for('auth.login'))

            if not current_user.has_role(*roles):
                abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def permission_required(permission_code):
    """Check if user has specific granular permission."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                return redirect(url_for('auth.login', next=request.url))
            if not current_user.has_permission(permission_code):
                flash(f"Access denied: Missing required permission '{permission_code}'.", "danger")
                return abort(403)
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def verify_record_access(record, student_attr='student_id', hostel_attr='hostel', assigned_attr='assigned_to'):
    """
    Enforce backend record-level access control (preventing IDOR vulnerabilities).
    Returns True if allowed, False if unauthorized.
    """
    if not current_user.is_authenticated:
        return False

    # Super Admin has global access
    if current_user.is_super_admin or current_user.role == 'admin':
        return True

    user_role = current_user.primary_role

    # Student can only access their own records
    if user_role == 'student':
        rec_student_id = getattr(record, student_attr, None)
        if rec_student_id is not None:
            return rec_student_id == current_user.id
        # In case record itself is User
        if hasattr(record, 'id') and isinstance(record, User):
            return record.id == current_user.id
        return False

    # Hostel Warden can only access records in their assigned hostel
    if user_role == 'warden':
        warden_hostel = current_user.hostel
        if current_user.staff_profile and current_user.staff_profile.assigned_hostel:
            warden_hostel = current_user.staff_profile.assigned_hostel

        if not warden_hostel:
            return True  # If campus-wide warden
            
        rec_hostel = getattr(record, hostel_attr, None)
        if rec_hostel:
            return rec_hostel == warden_hostel
        
        # Check through student relationship if present
        if hasattr(record, 'student') and record.student and record.student.hostel:
            return record.student.hostel == warden_hostel

    # Maintenance staff can only access tickets/complaints assigned to them
    if user_role == 'maintenance':
        assigned_id = getattr(record, assigned_attr, None)
        if assigned_id == current_user.id:
            return True
        if hasattr(record, 'assigned_staff_id') and record.assigned_staff_id == current_user.id:
            return True
        return False

    # Office Staff can access document and fee requests
    if user_role == 'office_staff':
        return True

    # Faculty can access assigned students / leave requests
    if user_role == 'faculty':
        if hasattr(record, 'faculty_id') and record.faculty_id:
            return record.faculty_id == current_user.id
        return True

    return True
