from app.extensions import db
from app.models import AuditLog

def log_audit(actor_id, entity_type, entity_id, action, old_status=None, new_status=None, notes=None):
    """Utility to record state transitions and actions in AuditLog."""
    entry = AuditLog(
        actor_id=actor_id,
        entity_type=entity_type,
        entity_id=entity_id,
        action=action,
        old_status=old_status,
        new_status=new_status,
        notes=notes
    )
    db.session.add(entry)
    db.session.commit()
    return entry
