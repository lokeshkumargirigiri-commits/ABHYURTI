from flask import Blueprint

caretaker_bp = Blueprint('caretaker', __name__, url_prefix='/caretaker')

from app.caretaker import routes
