from datetime import datetime, date
from flask import render_template, request, redirect, url_for, flash, abort
from flask_login import login_required, current_user
from app.caretaker import caretaker_bp
from app.extensions import db
from app.models import HostelNightAttendance, CaretakerHealthEmergency, User
from app.utils.security import role_required, log_audit_action, create_notification


@caretaker_bp.route('/')
@caretaker_bp.route('/dashboard')
@login_required
@role_required('caretaker', 'admin', 'super_admin')
def dashboard():
    today = date.today()
    selected_hostel = request.args.get('hostel', 'Aryabhata').strip()
    selected_date_str = request.args.get('date', today.isoformat()).strip()

    try:
        att_date = datetime.strptime(selected_date_str, '%Y-%m-%d').date()
    except ValueError:
        att_date = today

    # Students assigned to this hostel
    students = User.query.filter(
        User.role == 'student',
        User.hostel.ilike(f"%{selected_hostel}%")
    ).order_by(User.room.asc(), User.name.asc()).all()

    # Existing attendance records for this day
    existing_records = {
        r.student_id: r for r in HostelNightAttendance.query.filter_by(
            hostel=selected_hostel,
            date=att_date
        ).all()
    }

    # Open medical emergencies
    emergencies = CaretakerHealthEmergency.query.order_by(
        CaretakerHealthEmergency.created_at.desc()
    ).limit(20).all()

    return render_template('caretaker/dashboard.html',
                           students=students,
                           existing_records=existing_records,
                           emergencies=emergencies,
                           selected_hostel=selected_hostel,
                           selected_date=att_date)


@caretaker_bp.route('/night-attendance', methods=['POST'])
@login_required
@role_required('caretaker', 'admin', 'super_admin')
def save_night_attendance():
    hostel = request.form.get('hostel', 'Aryabhata').strip()
    date_str = request.form.get('date', '').strip()

    try:
        att_date = datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        att_date = date.today()

    student_ids = request.form.getlist('student_id')
    for s_id_str in student_ids:
        try:
            s_id = int(s_id_str)
            student = User.query.get(s_id)
            if not student:
                continue

            status_val = request.form.get(f'status_{s_id}', 'present').strip()
            remarks = request.form.get(f'remarks_{s_id}', '').strip()

            rec = HostelNightAttendance.query.filter_by(
                student_id=s_id,
                date=att_date
            ).first()

            if not rec:
                rec = HostelNightAttendance(
                    hostel=hostel,
                    room=student.room or 'N/A',
                    student_id=s_id,
                    date=att_date,
                    status=status_val,
                    remarks=remarks if remarks else None,
                    marked_by_id=current_user.id
                )
                db.session.add(rec)
            else:
                rec.status = status_val
                if remarks:
                    rec.remarks = remarks
                rec.marked_by_id = current_user.id
        except (ValueError, TypeError):
            continue

    db.session.commit()
    log_audit_action(current_user.id, 'night_attendance', 0, 'recorded',
                     notes=f"Logged night roll-call for {hostel} on {att_date}")

    flash(f"Night roll-call attendance for {hostel} ({att_date}) saved successfully.", "success")
    return redirect(url_for('caretaker.dashboard', hostel=hostel, date=att_date.isoformat()))


@caretaker_bp.route('/emergency', methods=['POST'])
@login_required
@role_required('caretaker', 'admin', 'super_admin')
def report_emergency():
    student_id = request.form.get('student_id', type=int)
    hostel = request.form.get('hostel', '').strip()
    room = request.form.get('room', '').strip()
    symptoms = request.form.get('symptoms', '').strip()
    severity = request.form.get('severity', 'high').strip()
    action_taken = request.form.get('action_taken', 'first_aid').strip()

    if not student_id or not symptoms:
        flash("Student and symptoms description are required.", "danger")
        return redirect(url_for('caretaker.dashboard'))

    student = User.query.get_or_404(student_id)

    emergency = CaretakerHealthEmergency(
        student_id=student.id,
        hostel=hostel or student.hostel or 'Hostel',
        room=room or student.room or 'N/A',
        symptoms=symptoms,
        severity=severity,
        action_taken=action_taken,
        escalated_to_superintendent=True,
        status='open',
        reported_by_id=current_user.id
    )
    db.session.add(emergency)
    db.session.commit()

    log_audit_action(current_user.id, 'health_emergency', emergency.id, 'reported',
                     notes=f"Emergency: {student.name} ({severity}) - {symptoms[:50]}")

    # Notify Superintendent and Warden
    supts = User.query.filter(User.role.in_(['superintendent', 'warden', 'admin'])).all()
    for s in supts:
        create_notification(
            s.id,
            f"🚨 HEALTH EMERGENCY: {student.name} ({hostel} - Rm {room})",
            f"Severity: {severity.upper()}. Symptoms: {symptoms}. Action: {action_taken}. Escalated by Caretaker {current_user.name}.",
            link=url_for('admin.room_inspect', hostel=emergency.hostel, room=emergency.room)
        )

    flash(f"Health emergency reported and escalated to Hostel Superintendent immediately.", "warning")
    return redirect(url_for('caretaker.dashboard'))


@caretaker_bp.route('/emergency/<int:id>/status', methods=['POST'])
@login_required
@role_required('caretaker', 'admin', 'superintendent', 'super_admin')
def update_emergency_status(id):
    em = CaretakerHealthEmergency.query.get_or_404(id)
    new_status = request.form.get('status', 'resolved').strip()
    em.status = new_status
    db.session.commit()

    flash(f"Emergency case #{em.id} marked as {new_status}.", "info")
    return redirect(url_for('caretaker.dashboard'))
