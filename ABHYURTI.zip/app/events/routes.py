from datetime import datetime, timedelta
from flask import render_template, request, redirect, url_for, flash, abort, jsonify
from flask_login import login_required, current_user
from app.events import events_bp
from app.extensions import db
from app.models import CampusEvent, EventApplication, SportsLiveScore, User
from app.utils.security import role_required, log_audit_action, create_notification


def seed_events_and_sports():
    """Ensure baseline campus events and sports live matches exist."""
    if CampusEvent.query.count() == 0:
        events = [
            ('HackFret 2026: 24-Hour AI & Web Hackathon', 'technical', 'Central Computing Complex', datetime.utcnow() + timedelta(days=12), 'Build full-stack intelligent campus utilities. Cash prizes ₹50,000.'),
            ('Tarang 2026: Annual Cultural Gala & Battle of Bands', 'cultural', 'Open Air Amphitheatre', datetime.utcnow() + timedelta(days=18), 'Annual music festival, classical dance competitions, and rock band night.'),
            ('Annual Inter-Department Athletics Meet', 'sports', 'Main Stadium & Synthetic Track', datetime.utcnow() + timedelta(days=8), '100m sprint, 4x100m relay, long jump, shot put, and cross country.')
        ]
        for title, cat, venue, edate, desc in events:
            db.session.add(CampusEvent(title=title, category=cat, venue=venue, event_date=edate, description=desc))
        db.session.commit()

    if SportsLiveScore.query.count() == 0:
        matches = [
            ('Inter-Department Cricket Championship: Final', 'cricket', 'CSE Titans', 'Mechanical Bulls', '142/4 (18.2 ov)', '138/8 (20 ov)', 'live', 'CSE Titans need 5 runs in 10 balls. A. Sharma batting at 48*.'),
            ('Annual Football League: Semi-Final 1', 'football', 'Aryabhata Strikers', 'Raman FC', '2', '1', 'completed', 'Aryabhata Strikers win 2-1 and advance to Grand Final.'),
            ('Inter-Year Badminton Singles Championship', 'badminton', 'ECE Smashers', 'Civil Shuttlers', '21-18, 19-21, 15-12', 'Deciding 3rd Set', 'live', 'Intense rally on Court 1. ECE leads by 3 points in final set.')
        ]
        for mtitle, stype, ta, tb, sa, sb, stat, summ in matches:
            db.session.add(SportsLiveScore(match_title=mtitle, sport_type=stype, team_a=ta, team_b=tb, score_a=sa, score_b=sb, current_status=stat, summary=summ))
        db.session.commit()


@events_bp.route('/')
@login_required
def index():
    seed_events_and_sports()
    events = CampusEvent.query.filter_by(is_active=True).order_by(CampusEvent.event_date.asc()).all()
    matches = SportsLiveScore.query.order_by(SportsLiveScore.updated_at.desc()).all()

    my_applications = EventApplication.query.filter_by(
        student_id=current_user.id
    ).all()
    registered_event_ids = {a.event_id for a in my_applications}

    return render_template('events/index.html',
                           events=events,
                           matches=matches,
                           my_applications=my_applications,
                           registered_event_ids=registered_event_ids)


@events_bp.route('/api/live-scores')
def api_live_scores():
    seed_events_and_sports()
    matches = SportsLiveScore.query.order_by(SportsLiveScore.updated_at.desc()).all()
    data = []
    for m in matches:
        data.append({
            'id': m.id,
            'match_title': m.match_title,
            'sport_type': m.sport_type,
            'team_a': m.team_a,
            'team_b': m.team_b,
            'score_a': m.score_a,
            'score_b': m.score_b,
            'current_status': m.current_status,
            'summary': m.summary,
            'updated_at': m.updated_at.strftime('%I:%M:%S %p')
        })
    return jsonify({'success': True, 'matches': data, 'timestamp': datetime.utcnow().isoformat()})


@events_bp.route('/register/<int:event_id>', methods=['POST'])
@login_required
def register_event(event_id):
    ev = CampusEvent.query.get_or_404(event_id)
    existing = EventApplication.query.filter_by(event_id=ev.id, student_id=current_user.id).first()
    if existing:
        flash(f"You have already registered for '{ev.title}'.", "info")
        return redirect(url_for('events.index'))

    app_rec = EventApplication(event_id=ev.id, student_id=current_user.id, status='registered')
    db.session.add(app_rec)
    db.session.commit()

    log_audit_action(current_user.id, 'event_application', app_rec.id, 'registered',
                     notes=f"Registered for event {ev.title}")

    create_notification(
        current_user.id,
        "Event Registration Confirmed",
        f"You are officially registered for '{ev.title}' at {ev.venue} on {ev.event_date.strftime('%d %b %Y')}.",
        link=url_for('events.index')
    )

    flash(f"Successfully registered for '{ev.title}'!", "success")
    return redirect(url_for('events.index'))


# ============================================================================
# COORDINATOR DASHBOARDS (EVENT & SPORTS COORDINATORS)
# ============================================================================

@events_bp.route('/dashboard')
@login_required
@role_required('event_coordinator', 'sports_coordinator', 'admin', 'super_admin')
def dashboard():
    seed_events_and_sports()
    events = CampusEvent.query.order_by(CampusEvent.event_date.desc()).all()
    matches = SportsLiveScore.query.order_by(SportsLiveScore.updated_at.desc()).all()
    applications = EventApplication.query.order_by(EventApplication.created_at.desc()).limit(25).all()

    return render_template('events/dashboard.html',
                           events=events,
                           matches=matches,
                           applications=applications)


@events_bp.route('/create', methods=['POST'])
@login_required
@role_required('event_coordinator', 'sports_coordinator', 'admin', 'super_admin')
def create_event():
    title = request.form.get('title', '').strip()
    category = request.form.get('category', 'cultural').strip()
    venue = request.form.get('venue', '').strip()
    date_str = request.form.get('event_date', '').strip()
    description = request.form.get('description', '').strip()
    max_p = int(request.form.get('max_participants', 100) or 100)

    if not title or not date_str:
        flash("Event title and date are required.", "danger")
        return redirect(url_for('events.dashboard'))

    try:
        edate = datetime.strptime(date_str, '%Y-%m-%dT%H:%M')
    except ValueError:
        try:
            edate = datetime.strptime(date_str, '%Y-%m-%d')
        except ValueError:
            flash("Invalid date format.", "danger")
            return redirect(url_for('events.dashboard'))

    ev = CampusEvent(
        title=title,
        category=category,
        venue=venue,
        event_date=edate,
        description=description,
        max_participants=max_p,
        created_by_id=current_user.id
    )
    db.session.add(ev)
    db.session.commit()

    flash(f"Campus Event '{title}' created successfully.", "success")
    return redirect(url_for('events.dashboard'))


@events_bp.route('/sports/create', methods=['POST'])
@login_required
@role_required('sports_coordinator', 'event_coordinator', 'admin', 'super_admin')
def create_match():
    title = request.form.get('match_title', '').strip()
    stype = request.form.get('sport_type', 'cricket').strip()
    team_a = request.form.get('team_a', '').strip()
    team_b = request.form.get('team_b', '').strip()
    status = request.form.get('current_status', 'upcoming').strip()
    summary = request.form.get('summary', '').strip()

    if not title or not team_a or not team_b:
        flash("Match title and team names are required.", "danger")
        return redirect(url_for('events.dashboard'))

    match = SportsLiveScore(
        match_title=title,
        sport_type=stype,
        team_a=team_a,
        team_b=team_b,
        score_a="0",
        score_b="0",
        current_status=status,
        summary=summary
    )
    db.session.add(match)
    db.session.commit()

    flash(f"Sports fixture '{title}' initialized on live board.", "success")
    return redirect(url_for('events.dashboard'))


@events_bp.route('/sports/<int:id>/update-score', methods=['POST'])
@login_required
@role_required('sports_coordinator', 'event_coordinator', 'admin', 'super_admin')
def update_score(id):
    match = SportsLiveScore.query.get_or_404(id)
    score_a = request.form.get('score_a', '').strip()
    score_b = request.form.get('score_b', '').strip()
    status = request.form.get('current_status', 'live').strip()
    summary = request.form.get('summary', '').strip()

    match.score_a = score_a
    match.score_b = score_b
    match.current_status = status
    match.summary = summary
    match.updated_at = datetime.utcnow()
    db.session.commit()

    log_audit_action(current_user.id, 'sports_live_score', match.id, 'score_update',
                     notes=f"Updated score: {match.team_a} ({score_a}) vs {match.team_b} ({score_b})")

    flash(f"Live score for '{match.match_title}' updated instantly.", "success")
    return redirect(url_for('events.dashboard'))


@events_bp.route('/application/<int:id>/position', methods=['POST'])
@login_required
@role_required('event_coordinator', 'sports_coordinator', 'admin', 'super_admin')
def award_position(id):
    app_rec = EventApplication.query.get_or_404(id)
    pos = request.form.get('position', '').strip()
    remarks = request.form.get('remarks', '').strip()
    status = request.form.get('status', 'winner').strip()

    app_rec.position = pos
    app_rec.remarks = remarks
    app_rec.status = status
    app_rec.certificate_issued = True
    db.session.commit()

    create_notification(
        app_rec.student_id,
        "🏆 Event Award / Position Announced!",
        f"Congratulations! You have been awarded '{pos}' in '{app_rec.event.title}'. {remarks}",
        link=url_for('events.index')
    )

    flash(f"Position '{pos}' awarded to {app_rec.student.name}.", "success")
    return redirect(url_for('events.dashboard'))
