from app.kiosk.routes import kiosk_bp
