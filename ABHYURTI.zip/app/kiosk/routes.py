from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from app.extensions import db
from app.models import User, Complaint, GatePass, AuditLog
from app.utils.audit import log_audit
from app.utils.uploads import save_and_compress_photo
from app.utils.qr import generate_room_qr
from app.i18n import translate as _

kiosk_bp = Blueprint('kiosk', __name__, url_prefix='/kiosk')

@kiosk_bp.route('/', methods=['GET', 'POST'])
def home():
    student_id = session.get('kiosk_student_id')
    current_student = User.query.get(student_id) if student_id else None

    if request.method == 'POST':
        roll_number = request.form.get('roll_number', '').strip().upper()
        pin = request.form.get('pin', '').strip()

        student = User.query.filter(User.roll_number.ilike(roll_number), User.role == 'student').first()
        if student and student.pin and student.pin == pin:
            session['kiosk_student_id'] = student.id
            flash(f"Verified identity for {student.name} ({student.roll_number})", "success")
            return redirect(url_for('kiosk.home'))
        else:
            flash("Invalid Roll Number or Security PIN.", "danger")

    # If student is verified, fetch their active tickets
    student_complaints = []
    student_passes = []
    if current_student:
        student_complaints = Complaint.query.filter_by(student_id=current_student.id).order_by(Complaint.created_at.desc()).limit(5).all()
        student_passes = GatePass.query.filter_by(student_id=current_student.id).order_by(GatePass.created_at.desc()).limit(5).all()

    return render_template(
        'kiosk/home.html',
        current_student=current_student,
        student_complaints=student_complaints,
        student_passes=student_passes
    )


@kiosk_bp.route('/exit')
def exit_session():
    session.pop('kiosk_student_id', None)
    flash("Kiosk session ended. Terminal ready for next student.", "info")
    return redirect(url_for('kiosk.home'))


@kiosk_bp.route('/complaint', methods=['GET', 'POST'])
def complaint_form():
    student_id = session.get('kiosk_student_id')
    if not student_id:
        flash("Please verify student roll number first.", "warning")
        return redirect(url_for('kiosk.home'))

    student = User.query.get_or_404(student_id)

    if request.method == 'POST':
        category = request.form.get('category', '').strip()
        room = request.form.get('room', '').strip() or student.room or '101'
        hostel = request.form.get('hostel', '').strip() or student.hostel or 'Hostel A'
        description = request.form.get('description', '').strip()

        if not category or not description:
            flash("Please provide category and description.", "danger")
            return render_template('kiosk/complaint_form.html', student=student)

        # Handle photo from kiosk camera or file
        photo_file = request.files.get('photo')
        camera_base64 = request.form.get('photo_camera_data')
        uploaded_rel_path = None
        if camera_base64 and len(camera_base64) > 50:
            uploaded_rel_path = save_and_compress_photo(base64_data=camera_base64)
        elif photo_file and photo_file.filename:
            uploaded_rel_path = save_and_compress_photo(file_obj=photo_file)

        # Repeat issue check
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        previous_count = Complaint.query.filter(
            Complaint.hostel == hostel,
            Complaint.room == room,
            Complaint.category == category,
            Complaint.created_at >= thirty_days_ago
        ).count()

        complaint = Complaint(
            student_id=student.id,
            category=category,
            description=description,
            room=room,
            hostel=hostel,
            photo_path=uploaded_rel_path,
            status='submitted',
            is_repeat=(previous_count > 0)
        )
        db.session.add(complaint)
        db.session.commit()

        log_audit(
            actor_id=student.id,
            entity_type='kiosk',
            entity_id=complaint.id,
            action='kiosk_complaint_created',
            new_status='submitted',
            notes=f"Kiosk Operator submitted ticket for {student.name} ({student.roll_number})"
        )

        flash(f"Complaint #{complaint.id} logged via Self-Service Kiosk!", "success")
        return redirect(url_for('kiosk.receipt', item_type='complaint', item_id=complaint.id))

    return render_template('kiosk/complaint_form.html', student=student)


@kiosk_bp.route('/gate-pass', methods=['GET', 'POST'])
def gate_pass_form():
    student_id = session.get('kiosk_student_id')
    if not student_id:
        flash("Please verify student roll number first.", "warning")
        return redirect(url_for('kiosk.home'))

    student = User.query.get_or_404(student_id)

    if request.method == 'POST':
        destination = request.form.get('destination', '').strip()
        reason = request.form.get('reason', '').strip()
        from_str = request.form.get('from_date', '').strip()
        to_str = request.form.get('to_date', '').strip()
        is_emergency = bool(request.form.get('is_emergency'))
        emergency_reason = request.form.get('emergency_reason', '').strip()

        try:
            from_date = datetime.strptime(from_str, '%Y-%m-%dT%H:%M')
            to_date = datetime.strptime(to_str, '%Y-%m-%dT%H:%M')
        except ValueError:
            flash("Invalid date and time selected.", "danger")
            return render_template('kiosk/gate_pass_form.html', student=student)

        gate_pass = GatePass(
            student_id=student.id,
            from_date=from_date,
            to_date=to_date,
            destination=destination,
            reason=reason,
            status='pending',
            is_emergency=is_emergency,
            emergency_reason=emergency_reason if is_emergency else None,
            parent_notified=True
        )
        db.session.add(gate_pass)
        db.session.commit()

        log_audit(
            actor_id=student.id,
            entity_type='kiosk',
            entity_id=gate_pass.id,
            action='kiosk_gate_pass_created',
            new_status='pending',
            notes=f"Gate Pass requested at Kiosk for {student.name}"
        )

        flash(f"Gate Pass #{gate_pass.id} logged via Kiosk!", "success")
        return redirect(url_for('kiosk.receipt', item_type='gate_pass', item_id=gate_pass.id))

    return render_template('kiosk/gate_pass_form.html', student=student)


@kiosk_bp.route('/receipt/<item_type>/<int:item_id>')
def receipt(item_type, item_id):
    student_id = session.get('kiosk_student_id')
    item = None
    student = None

    if item_type == 'complaint':
        item = Complaint.query.get_or_404(item_id)
        student = item.student
    elif item_type == 'gate_pass':
        item = GatePass.query.get_or_404(item_id)
        student = item.student

    return render_template(
        'kiosk/receipt.html',
        item_type=item_type,
        item=item,
        student=student
    )
