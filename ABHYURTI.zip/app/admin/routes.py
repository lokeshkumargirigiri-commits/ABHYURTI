import csv
import io
from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, Response, jsonify
from flask_login import login_required, current_user
from sqlalchemy import func
from app.extensions import db
from app.models import Complaint, GatePass, Notice, NoticeRead, AuditLog, User
from app.utils.audit import log_audit
from app.utils.targeting import get_targeted_users_count, get_targeted_users_query
from app.utils.qr import generate_room_qr
from app.auth.routes import role_required
from app.i18n import translate as _

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/')
@admin_bp.route('/dashboard')
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def dashboard():
    hostel_filter = current_user.hostel if current_user.role in ('warden', 'superintendent') else None

    # Base complaints query
    c_query = Complaint.query
    if hostel_filter:
        c_query = c_query.filter(Complaint.hostel == hostel_filter)

    total_complaints = c_query.count()
    pending_complaints = c_query.filter(Complaint.status.notin_(['resolved', 'closed'])).count()
    resolved_complaints = c_query.filter(Complaint.status.in_(['resolved', 'closed'])).count()
    repeat_complaints = c_query.filter(Complaint.is_repeat == True).count()

    # Ageing calculation
    now = datetime.utcnow()
    three_days_ago = now - timedelta(days=3)
    seven_days_ago = now - timedelta(days=7)

    # Active complaints for bucket counts
    active_complaints_list = c_query.filter(Complaint.status.notin_(['resolved', 'closed'])).all()
    ageing_0_3 = sum(1 for c in active_complaints_list if c.created_at >= three_days_ago)
    ageing_4_7 = sum(1 for c in active_complaints_list if seven_days_ago <= c.created_at < three_days_ago)
    ageing_8_plus = sum(1 for c in active_complaints_list if c.created_at < seven_days_ago)

    # Gate passes
    gp_query = GatePass.query.join(User, GatePass.student_id == User.id)
    if hostel_filter:
        gp_query = gp_query.filter(User.hostel == hostel_filter)
    
    pending_passes = gp_query.filter(GatePass.status == 'pending').count()
    emergency_passes = gp_query.filter(GatePass.status == 'pending', GatePass.is_emergency == True).count()
    breached_passes = sum(1 for gp in gp_query.filter(GatePass.status == 'pending', GatePass.is_emergency == True).all() if gp.is_sla_breached)

    # Notices read-rate aggregate
    notices = Notice.query.order_by(Notice.published_at.desc()).limit(5).all()
    notices_stats = []
    for n in notices:
        t_count = get_targeted_users_count(n)
        r_count = NoticeRead.query.filter_by(notice_id=n.id).count()
        a_count = NoticeRead.query.filter(NoticeRead.notice_id == n.id, NoticeRead.action_at.isnot(None)).count()
        r_rate = int((r_count / t_count * 100)) if t_count > 0 else 0
        notices_stats.append({
            'notice': n,
            'targeted': t_count,
            'reads': r_count,
            'actions': a_count,
            'read_rate': r_rate
        })

    # Recent queues
    recent_complaints = c_query.filter(Complaint.status.notin_(['resolved', 'closed'])).order_by(Complaint.created_at.asc()).limit(6).all()
    recent_passes = gp_query.filter(GatePass.status == 'pending').order_by(GatePass.is_emergency.desc(), GatePass.created_at.asc()).limit(5).all()

    # Repeat issues list
    repeat_issues_list = c_query.filter(Complaint.is_repeat == True, Complaint.status.notin_(['resolved', 'closed'])).limit(5).all()

    # Average resolution time calculation
    resolved_tickets = c_query.filter(Complaint.status.in_(['resolved', 'closed']), Complaint.resolved_at.isnot(None)).all()
    if resolved_tickets:
        avg_hours = sum((t.resolved_at - t.created_at).total_seconds() / 3600 for t in resolved_tickets) / len(resolved_tickets)
        avg_resolution_str = f"{avg_hours:.1f} hrs"
    else:
        avg_resolution_str = "N/A"

    return render_template(
        'admin/dashboard.html',
        total_complaints=total_complaints,
        pending_complaints=pending_complaints,
        resolved_complaints=resolved_complaints,
        repeat_complaints=repeat_complaints,
        ageing_0_3=ageing_0_3,
        ageing_4_7=ageing_4_7,
        ageing_8_plus=ageing_8_plus,
        pending_passes=pending_passes,
        emergency_passes=emergency_passes,
        breached_passes=breached_passes,
        avg_resolution_str=avg_resolution_str,
        notices_stats=notices_stats,
        recent_complaints=recent_complaints,
        recent_passes=recent_passes,
        repeat_issues_list=repeat_issues_list,
        hostel_filter=hostel_filter
    )


@admin_bp.route('/complaints')
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def complaints_queue():
    status = request.args.get('status')
    category = request.args.get('category')
    hostel = request.args.get('hostel')
    bucket = request.args.get('bucket')
    repeat_only = bool(request.args.get('repeat'))

    query = Complaint.query
    if current_user.role in ('warden', 'superintendent') and current_user.hostel:
        query = query.filter(Complaint.hostel == current_user.hostel)
    elif hostel:
        query = query.filter(Complaint.hostel == hostel)

    if status:
        query = query.filter(Complaint.status == status)
    if category:
        query = query.filter(Complaint.category == category)
    if repeat_only:
        query = query.filter(Complaint.is_repeat == True)

    now = datetime.utcnow()
    complaints = query.order_by(Complaint.created_at.asc()).all()

    # Filter bucket in-memory
    if bucket == 'red':
        eight_days_ago = now - timedelta(days=7)
        complaints = [c for c in complaints if c.created_at < eight_days_ago]
    elif bucket == 'amber':
        seven_ago = now - timedelta(days=7)
        three_ago = now - timedelta(days=3)
        complaints = [c for c in complaints if seven_ago <= c.created_at < three_ago]
    elif bucket == 'green':
        three_ago = now - timedelta(days=3)
        complaints = [c for c in complaints if c.created_at >= three_ago]

    staff_members = User.query.filter(User.role.in_(['admin', 'warden', 'maintenance', 'super_admin'])).all()

    return render_template(
        'admin/complaints/queue.html',
        complaints=complaints,
        staff_members=staff_members,
        current_status=status,
        current_category=category,
        current_hostel=hostel,
        current_bucket=bucket,
        current_repeat=repeat_only
    )


@admin_bp.route('/complaints/<int:id>', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def complaint_detail(id):
    complaint = Complaint.query.get_or_404(id)
    
    # Restrict warden to own hostel
    if current_user.role in ('warden', 'superintendent') and current_user.hostel and complaint.hostel != current_user.hostel:
        flash("You can only manage complaints within your assigned hostel block.", "danger")
        return redirect(url_for('admin.complaints_queue'))

    if request.method == 'POST':
        old_status = complaint.status
        new_status = request.form.get('status', complaint.status)
        assigned_to = request.form.get('assigned_to', type=int)
        notes = request.form.get('resolution_notes', '').strip()

        complaint.status = new_status
        if assigned_to:
            complaint.assigned_to = assigned_to
            from app.models import MaintenanceTicket
            ticket = MaintenanceTicket.query.filter_by(complaint_id=complaint.id).first()
            if not ticket:
                ticket = MaintenanceTicket(
                    complaint_id=complaint.id,
                    assigned_staff_id=assigned_to,
                    status='assigned'
                )
                db.session.add(ticket)
            else:
                ticket.assigned_staff_id = assigned_to

        if notes:
            complaint.resolution_notes = notes

        if new_status in ('resolved', 'closed') and not complaint.resolved_at:
            complaint.resolved_at = datetime.utcnow()

        db.session.commit()

        # Trigger notification to student
        try:
            from app.services.notification_service import notify_complaint_status_changed
            notify_complaint_status_changed(complaint, complaint.student, new_status, notes=notes)
        except Exception as e:
            current_app.logger.warning(f"Error dispatching complaint notification: {e}")

        # Audit Log
        log_audit(
            actor_id=current_user.id,
            entity_type='complaint',
            entity_id=complaint.id,
            action='status_update',
            old_status=old_status,
            new_status=new_status,
            notes=f"Updated by {current_user.name} ({current_user.role}). Notes: {notes or 'None'}"
        )

        flash(f"Complaint #{complaint.id} status updated to {new_status.replace('_', ' ').title()}.", "success")
        return redirect(url_for('admin.complaint_detail', id=complaint.id))

    audit_trail = AuditLog.query.filter_by(
        entity_type='complaint',
        entity_id=complaint.id
    ).order_by(AuditLog.created_at.asc()).all()

    staff_members = User.query.filter(User.role.in_(['admin', 'warden', 'maintenance', 'super_admin'])).all()
    qr_image = generate_room_qr(complaint.hostel, complaint.room)

    return render_template(
        'admin/complaints/detail.html',
        complaint=complaint,
        audit_trail=audit_trail,
        staff_members=staff_members,
        qr_image=qr_image
    )


@admin_bp.route('/gate-passes')
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def gate_pass_queue():
    status = request.args.get('status', 'all')
    
    query = GatePass.query.join(User, GatePass.student_id == User.id)
    if current_user.role in ('warden', 'superintendent') and current_user.hostel:
        query = query.filter(User.hostel == current_user.hostel)

    if status and status != 'all':
        query = query.filter(GatePass.status == status)

    # Sort: pending emergency passes first, then by departure date
    passes = query.order_by(
        GatePass.status == 'pending',
        GatePass.is_emergency.desc(),
        GatePass.from_date.asc()
    ).all()

    return render_template('admin/gate_pass/queue.html', passes=passes, current_status=status)


@admin_bp.route('/gate-passes/<int:id>/approve', methods=['POST'])
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def gate_pass_approve(id):
    gate_pass = GatePass.query.get_or_404(id)
    old_status = gate_pass.status
    gate_pass.status = 'approved'
    gate_pass.approved_by = current_user.id
    db.session.commit()

    # Trigger Push + SMS + Email receipts
    try:
        from app.services.notification_service import notify_gate_pass_status_changed
        notify_gate_pass_status_changed(gate_pass, gate_pass.student, 'approved', approver_name=current_user.name)
    except Exception as e:
        current_app.logger.warning(f"Error dispatching approval notification: {e}")

    log_audit(
        actor_id=current_user.id,
        entity_type='gate_pass',
        entity_id=gate_pass.id,
        action='approved',
        old_status=old_status,
        new_status='approved',
        notes=f"Approved by {current_user.name} ({current_user.role})"
    )

    flash(f"Gate Pass #{gate_pass.id} for {gate_pass.student.name} APPROVED.", "success")
    return redirect(request.referrer or url_for('admin.gate_pass_queue'))


@admin_bp.route('/gate-passes/<int:id>/reject', methods=['POST'])
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def gate_pass_reject(id):
    gate_pass = GatePass.query.get_or_404(id)
    reason = request.form.get('rejection_reason', '').strip()
    if not reason:
        flash("Rejection reason is required.", "danger")
        return redirect(request.referrer or url_for('admin.gate_pass_queue'))

    old_status = gate_pass.status
    gate_pass.status = 'rejected'
    gate_pass.approved_by = current_user.id
    gate_pass.rejection_reason = reason
    db.session.commit()

    # Trigger Push + SMS rejection alerts
    try:
        from app.services.notification_service import notify_gate_pass_status_changed
        notify_gate_pass_status_changed(gate_pass, gate_pass.student, 'rejected', approver_name=current_user.name)
    except Exception as e:
        current_app.logger.warning(f"Error dispatching rejection notification: {e}")

    log_audit(
        actor_id=current_user.id,
        entity_type='gate_pass',
        entity_id=gate_pass.id,
        action='rejected',
        old_status=old_status,
        new_status='rejected',
        notes=f"Rejected by {current_user.name}. Reason: {reason}"
    )

    flash(f"Gate Pass #{gate_pass.id} rejected.", "warning")
    return redirect(request.referrer or url_for('admin.gate_pass_queue'))


@admin_bp.route('/gate-passes/<int:id>/return', methods=['POST'])
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def gate_pass_return(id):
    gate_pass = GatePass.query.get_or_404(id)
    gate_pass.actual_return_at = datetime.utcnow()
    db.session.commit()

    log_audit(
        actor_id=current_user.id,
        entity_type='gate_pass',
        entity_id=gate_pass.id,
        action='returned',
        new_status='returned',
        notes=f"Student return recorded at campus gate by {current_user.name}."
    )

    flash(f"Return time logged for {gate_pass.student.name}.", "success")
    return redirect(request.referrer or url_for('admin.gate_pass_queue'))


@admin_bp.route('/notices')
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def notices_list():
    notices = Notice.query.order_by(Notice.published_at.desc()).all()
    stats = []
    for n in notices:
        t_count = get_targeted_users_count(n)
        r_count = NoticeRead.query.filter_by(notice_id=n.id).count()
        a_count = NoticeRead.query.filter(NoticeRead.notice_id == n.id, NoticeRead.action_at.isnot(None)).count()
        r_rate = int((r_count / t_count * 100)) if t_count > 0 else 0
        a_rate = int((a_count / t_count * 100)) if t_count > 0 else 0
        stats.append({
            'notice': n,
            'targeted': t_count,
            'reads': r_count,
            'actions': a_count,
            'read_rate': r_rate,
            'action_rate': a_rate
        })

    return render_template('admin/notices/list.html', notices_stats=stats)


@admin_bp.route('/notices/new', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def notice_new():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        body = request.form.get('body', '').strip()
        target_hostel = request.form.get('target_hostel', '').strip() or None
        target_year = request.form.get('target_year', type=int) or None
        target_branch = request.form.get('target_branch', '').strip() or None
        target_batch = request.form.get('target_batch', '').strip() or None
        requires_action = bool(request.form.get('requires_action'))
        action_label = request.form.get('action_label', 'Acknowledge & Confirm').strip() or 'Acknowledge & Confirm'

        if not title or not body:
            flash("Notice title and body content are required.", "danger")
            return render_template('admin/notices/form.html')

        notice = Notice(
            title=title,
            body=body,
            target_hostel=target_hostel,
            target_year=target_year,
            target_branch=target_branch,
            target_batch=target_batch,
            created_by=current_user.id,
            requires_action=requires_action,
            action_label=action_label,
            status='published'
        )
        db.session.add(notice)
        db.session.commit()

        targeted_count = get_targeted_users_count(notice)

        log_audit(
            actor_id=current_user.id,
            entity_type='notice',
            entity_id=notice.id,
            action='published',
            new_status='published',
            notes=f"Notice '{title}' published to {targeted_count} targeted students."
        )

        flash(f"Notice published successfully to {targeted_count} targeted students!", "success")
        return redirect(url_for('admin.notices_list'))

    return render_template('admin/notices/form.html')


@admin_bp.route('/room/<hostel>/<room>')
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def room_inspect(hostel, room):
    """Warden & Superintendent floor inspection view after scanning room QR code."""
    complaints = Complaint.query.filter_by(
        hostel=hostel,
        room=room
    ).order_by(Complaint.created_at.desc()).all()

    unresolved_complaints = [c for c in complaints if c.status not in ('resolved', 'closed')]
    resolved_complaints = [c for c in complaints if c.status in ('resolved', 'closed')]

    # Room members assigned to this hostel and room
    room_members = User.query.filter_by(
        hostel=hostel,
        room=room,
        role='student'
    ).order_by(User.name.asc()).all()

    # Gate-pass requests submitted by this room's students
    member_ids = [m.id for m in room_members]
    gate_passes = GatePass.query.filter(
        GatePass.student_id.in_(member_ids)
    ).order_by(GatePass.created_at.desc()).all() if member_ids else []

    qr_image = generate_room_qr(hostel, room)
    repeat_flag = any(c.is_repeat for c in complaints)

    return render_template(
        'admin/room_inspect.html',
        hostel=hostel,
        room=room,
        complaints=complaints,
        unresolved_complaints=unresolved_complaints,
        resolved_complaints=resolved_complaints,
        room_members=room_members,
        gate_passes=gate_passes,
        qr_image=qr_image,
        repeat_flag=repeat_flag
    )


@admin_bp.route('/complaints/export')
@login_required
@role_required('admin', 'warden', 'superintendent', 'super_admin')
def export_complaints_csv():
    """Export complaints queue to CSV for morning operations meetings."""
    query = Complaint.query
    if current_user.role in ('warden', 'superintendent') and current_user.hostel:
        query = query.filter(Complaint.hostel == current_user.hostel)
    
    complaints = query.order_by(Complaint.created_at.desc()).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow([
        'Ticket ID', 'Hostel', 'Room', 'Category', 'Description',
        'Status', 'Age (Days)', 'Repeat Issue', 'Student Name',
        'Student Roll', 'Created At', 'Resolved At', 'Notes'
    ])

    for c in complaints:
        writer.writerow([
            c.id, c.hostel, c.room, c.category, c.description,
            c.status, c.age_days, 'YES' if c.is_repeat else 'NO',
            c.student.name if c.student else '',
            c.student.roll_number if c.student else '',
            c.created_at.strftime('%Y-%m-%d %H:%M'),
            c.resolved_at.strftime('%Y-%m-%d %H:%M') if c.resolved_at else '',
            c.resolution_notes or ''
        ])

    response = Response(output.getvalue(), mimetype='text/csv')
    response.headers['Content-Disposition'] = f"attachment; filename=abhyurti_complaints_{datetime.utcnow().strftime('%Y%m%d')}.csv"
    return response


@admin_bp.route('/integrations')
@login_required
@role_required('admin', 'warden', 'super_admin')
def integrations_hub():
    """Unified Settings and Third-Party API Hub."""
    from app.services.settings_service import get_all_integrations_summary
    integrations = get_all_integrations_summary()
    return render_template('integrations/index.html', integrations=integrations)


@admin_bp.route('/integrations/update', methods=['POST'])
@login_required
@role_required('admin', 'super_admin')
def integrations_update():
    """Updates one or more API Keys and service configurations."""
    from app.services.settings_service import set_setting
    updated_count = 0
    for key in request.form:
        if key == 'csrf_token':
            continue
        val = request.form.get(key, '').strip()
        # If masked or empty and already set, only update if newly typed
        if val and not val.startswith('••••'):
            set_setting(key, val)
            updated_count += 1
        elif val == '':
            set_setting(key, '')

    log_audit(
        actor_id=current_user.id,
        entity_type='system_settings',
        entity_id=0,
        action='integrations_updated',
        notes=f"Updated cloud API keys by {current_user.name}"
    )

    flash("Cloud integrations and API settings updated successfully!", "success")
    return redirect(url_for('admin.integrations_hub'))


@admin_bp.route('/canteen-issues')
@login_required
@role_required('admin', 'warden', 'super_admin')
def canteen_issues():
    from app.models import CanteenIssueReport, SystemSetting
    status_filter = request.args.get('status', 'all')
    hostel_filter = current_user.hostel if current_user.role == 'warden' else None

    query = CanteenIssueReport.query
    if hostel_filter:
        query = query.filter(CanteenIssueReport.hostel == hostel_filter)
    if status_filter != 'all':
        query = query.filter(CanteenIssueReport.status == status_filter)

    issues = query.order_by(CanteenIssueReport.created_at.desc()).all()

    outside_setting = SystemSetting.query.filter_by(key='allow_outside_food_ordering').first()
    allow_outside_food = True if not outside_setting or outside_setting.value.lower() != 'false' else False

    return render_template(
        'admin/canteen_issues.html',
        issues=issues,
        current_status=status_filter,
        allow_outside_food=allow_outside_food
    )


@admin_bp.route('/canteen-issues/<int:issue_id>/update', methods=['POST'])
@login_required
@role_required('admin', 'warden', 'super_admin')
def update_canteen_issue(issue_id):
    from app.models import CanteenIssueReport
    issue = CanteenIssueReport.query.get_or_404(issue_id)
    new_status = request.form.get('status', issue.status).strip()
    admin_notes = request.form.get('admin_notes', '').strip()

    issue.status = new_status
    if admin_notes:
        issue.admin_notes = admin_notes
    if new_status == 'resolved':
        issue.resolved_at = datetime.utcnow()
        issue.resolved_by_id = current_user.id

    db.session.commit()
    log_audit(actor_id=current_user.id, entity_type='canteen_issue', entity_id=issue.id, action=f'status_{new_status}', notes=admin_notes)
    flash(f"Canteen issue #{issue.id} ({issue.food_name}) updated to '{new_status}'.", "success")
    return redirect(url_for('admin.canteen_issues'))


@admin_bp.route('/canteen/toggle-outside-ordering', methods=['POST'])
@login_required
@role_required('admin', 'warden', 'super_admin')
def toggle_outside_ordering():
    from app.services.settings_service import set_setting
    from app.models import SystemSetting
    current_setting = SystemSetting.query.filter_by(key='allow_outside_food_ordering').first()
    is_currently_enabled = True if not current_setting or current_setting.value.lower() != 'false' else False
    new_val = 'false' if is_currently_enabled else 'true'
    set_setting('allow_outside_food_ordering', new_val)

    state_str = "ENABLED" if new_val == 'true' else "DISABLED"
    log_audit(actor_id=current_user.id, entity_type='system_settings', entity_id=0, action='toggle_outside_food', notes=f"Outside food ordering set to {state_str}")
    flash(f"Outside food ordering for students has been {state_str}.", "info")
    return redirect(url_for('admin.canteen_issues'))
