import re
from datetime import datetime, timedelta
from flask import Blueprint, render_template, redirect, url_for, flash, request, abort, session, jsonify, current_app
from flask_login import login_user, logout_user, login_required, current_user
from app.extensions import db, limiter
from app.models import (
    User, Role, StudentProfile, StaffProfile, ApprovalRequest,
    OTPVerification, UserSession, Notification, AuditLog
)
from app.utils.security import (
    create_or_update_otp, verify_otp, register_failed_login,
    register_successful_login, terminate_current_session,
    create_notification, log_audit_action, role_required
)
from app.i18n import translate as _

auth_bp = Blueprint('auth', __name__)

def find_user_by_identifier(identifier: str):
    if not identifier:
        return None
    ident = identifier.strip()
    raw_digits = ''.join(c for c in ident if c.isdigit())
    
    conditions = [
        User.email.ilike(ident),
        User.phone == ident,
        User.roll_number.ilike(ident)
    ]
    if len(raw_digits) >= 10:
        last10 = raw_digits[-10:]
        clean_phone = db.func.replace(db.func.replace(User.phone, ' ', ''), '-', '')
        conditions.append(clean_phone.like(f"%{last10}%"))
        
    user = User.query.filter(db.or_(*conditions)).first()
    if user:
        return user

    # Check StaffProfile employee_id
    staff = StaffProfile.query.filter(StaffProfile.employee_id.ilike(ident)).first()
    if staff and staff.user:
        return staff.user

    from app.models import PreApprovedEmployeeCode
    pre = PreApprovedEmployeeCode.query.filter(PreApprovedEmployeeCode.employee_code.ilike(ident)).first()
    if pre and pre.used_by:
        return pre.used_by

    return None


@auth_bp.route('/login', methods=['GET', 'POST'])
@limiter.limit("10 per minute", methods=["POST"])
def login():
    selected_role = request.args.get('role', 'student').strip().lower()

    if current_user.is_authenticated:
        if current_user.status == 'pending_verification':
            return redirect(url_for('auth.pending_approval'))
        role = current_user.primary_role
        if role == 'student':
            return redirect(url_for('student.home'))
        elif role in ('super_admin', 'admin'):
            return redirect(url_for('super_admin.dashboard'))
        elif role in ('faculty', 'hod'):
            return redirect(url_for('faculty.dashboard'))
        elif role in ('warden', 'superintendent'):
            return redirect(url_for('admin.dashboard'))
        elif role == 'mess_manager':
            return redirect(url_for('mess_manager.dashboard'))
        elif role == 'maintenance':
            return redirect(url_for('maintenance.dashboard'))
        elif role == 'office_staff':
            return redirect(url_for('office.dashboard'))
        elif role == 'account_staff':
            return redirect(url_for('account_section.dashboard'))
        elif role == 'exam_staff':
            return redirect(url_for('examination.dashboard'))
        elif role == 'cafeteria_staff':
            return redirect(url_for('cafeteria.dashboard'))
        elif role == 'cyber_cafe_staff':
            return redirect(url_for('cyber_cafe.dashboard'))
        elif role == 'librarian':
            return redirect(url_for('library.dashboard'))
        elif role in ('event_coordinator', 'sports_coordinator'):
            return redirect(url_for('events.dashboard'))
        elif role == 'counselor':
            return redirect(url_for('counselor.dashboard'))
        elif role == 'caretaker':
            return redirect(url_for('caretaker.dashboard'))
        return redirect(url_for('student.home'))

    if request.method == 'POST':
        identifier = request.form.get('identifier', '').strip()  # email, phone, roll number, or employee ID
        password = request.form.get('password', '')
        selected_role = request.form.get('selected_role', '').strip().lower()
        remember = bool(request.form.get('remember'))

        if not identifier or not password:
            flash("Please enter your credentials and password.", "danger")
            return render_template('auth/login.html', selected_role=selected_role or 'student')

        # Find user by email, phone, roll number, or employee ID
        user = find_user_by_identifier(identifier)

        # Check account lockout if user exists
        if user and user.is_account_locked:
            minutes_left = int((user.locked_until - datetime.utcnow()).total_seconds() // 60) + 1
            flash(f"Account temporarily locked due to multiple failed login attempts. Try again in {minutes_left} minutes.", "danger")
            return render_template('auth/login.html', selected_role=selected_role or 'student')

        # Generic login error prevents account enumeration
        if not user or not user.check_password(password):
            if user:
                register_failed_login(user)
            flash("Invalid credentials.", "danger")
            return render_template('auth/login.html', selected_role=selected_role or 'student')

        # Check account activation status
        if not user.is_active or user.status == 'deactivated':
            flash("Your account has been deactivated by administration. Please contact support.", "danger")
            return render_template('auth/login.html', selected_role=selected_role or 'student')

        if user.status == 'rejected':
            approval = ApprovalRequest.query.filter_by(staff_user_id=user.id).order_by(ApprovalRequest.created_at.desc()).first()
            reason = approval.review_notes if approval else "Application rejected by administration."
            flash(f"Registration rejected: {reason}", "danger")
            return render_template('auth/login.html', selected_role=selected_role or 'student')

        # Role-based access validation: if user picked an explicit role, verify authorization
        if selected_role and selected_role not in ('all', '', 'auto'):
            role_allowed = user.has_role(selected_role)
            if not role_allowed and selected_role in ('warden', 'superintendent') and user.has_role('admin'):
                role_allowed = True
            if not role_allowed and user.has_role('super_admin'):
                role_allowed = True
            if not role_allowed:
                user_role_display = user.primary_role.replace('_', ' ').title()
                selected_role_display = selected_role.replace('_', ' ').title()
                flash(f"Access Denied: Your account is registered as '{user_role_display}', but you selected the '{selected_role_display}' portal. Please select '{user_role_display}' to sign in.", "warning")
                return render_template('auth/login.html', selected_role=user.primary_role)

        # Successful login & session lifetime management
        session.permanent = remember
        login_user(user, remember=remember)
        register_successful_login(user)
        log_audit_action(user.id, 'user', user.id, 'login', notes=f"User signed in via {request.remote_addr} for portal {selected_role}")

        if user.status == 'pending_verification':
            flash(f"Welcome {user.name}! Your staff account is currently pending verification.", "info")
            return redirect(url_for('auth.pending_approval'))

        flash(f"Welcome back, {user.name}!", "success")
        next_page = request.args.get('next')
        if next_page:
            return redirect(next_page)

        target_role = selected_role if (selected_role and user.has_role(selected_role)) else user.primary_role
        if target_role == 'student':
            return redirect(url_for('student.home'))
        elif target_role in ('super_admin', 'admin'):
            return redirect(url_for('super_admin.dashboard'))
        elif target_role in ('faculty', 'hod'):
            return redirect(url_for('faculty.dashboard'))
        elif target_role in ('warden', 'superintendent'):
            return redirect(url_for('admin.dashboard'))
        elif target_role == 'mess_manager':
            return redirect(url_for('mess_manager.dashboard'))
        elif target_role == 'maintenance':
            return redirect(url_for('maintenance.dashboard'))
        elif target_role == 'office_staff':
            return redirect(url_for('office.dashboard'))
        elif target_role == 'account_staff':
            return redirect(url_for('account_section.dashboard'))
        elif target_role == 'exam_staff':
            return redirect(url_for('examination.dashboard'))
        elif target_role == 'cafeteria_staff':
            return redirect(url_for('cafeteria.dashboard'))
        elif target_role == 'cyber_cafe_staff':
            return redirect(url_for('cyber_cafe.dashboard'))
        elif target_role == 'librarian':
            return redirect(url_for('library.dashboard'))
        elif target_role in ('event_coordinator', 'sports_coordinator'):
            return redirect(url_for('events.dashboard'))
        elif target_role == 'counselor':
            return redirect(url_for('counselor.dashboard'))
        elif target_role == 'caretaker':
            return redirect(url_for('caretaker.dashboard'))
        return redirect(url_for('student.home'))

    return render_template('auth/login.html', selected_role=selected_role)


@auth_bp.route('/register', methods=['GET', 'POST'])
@auth_bp.route('/signup', methods=['GET', 'POST'])
@limiter.limit("20 per minute", methods=["POST"])
def register():
    from app.models import PreApprovedEmployeeCode
    selected_role = request.args.get('role', 'student').strip().lower()
    ALLOWED_REGISTRATION_ROLES = [
        'student', 'faculty', 'warden', 'mess_manager', 'maintenance', 'office_staff',
        'admin', 'super_admin', 'hod', 'account_staff', 'exam_staff', 'cafeteria_staff',
        'cyber_cafe_staff', 'librarian', 'event_coordinator', 'sports_coordinator',
        'counselor', 'caretaker', 'superintendent'
    ]
    if selected_role not in ALLOWED_REGISTRATION_ROLES:
        selected_role = 'student'

    if current_user.is_authenticated:
        return redirect(url_for('student.home'))

    if request.method == 'POST':
        raw_role = request.form.get('role', selected_role).strip().lower()
        emp_code = (request.form.get('employee_code') or request.form.get('employee_id') or '').strip().upper()
        roll_number = request.form.get('roll_number', '').strip().upper()

        ALL_STAFF_ROLES = [
            'faculty', 'warden', 'mess_manager', 'maintenance', 'office_staff',
            'admin', 'super_admin', 'hod', 'account_staff', 'exam_staff', 'cafeteria_staff',
            'cyber_cafe_staff', 'librarian', 'event_coordinator', 'sports_coordinator',
            'counselor', 'caretaker', 'superintendent'
        ]
        if raw_role in ALL_STAFF_ROLES:
            if not emp_code:
                if roll_number:
                    # Form tampering attempt from student registration: force role='student'
                    role = 'student'
                else:
                    flash("An official University-issued Employee Code is required for staff/admin registration.", "danger")
                    return render_template('auth/register.html', selected_role=raw_role)
            else:
                role = raw_role
        else:
            role = 'student'

        name = request.form.get('name', '').strip()
        email = request.form.get('email', '').strip().lower()
        phone = request.form.get('phone', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        # Required fields check
        if not name or not email or not phone or not password:
            flash("Full name, email, mobile number, and password are required.", "danger")
            return render_template('auth/register.html', selected_role=role)

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template('auth/register.html', selected_role=role)

        # Password validation: >= 8 characters, at least 1 letter, at least 1 number
        if len(password) < 8 or not re.search(r'[A-Za-z]', password) or not re.search(r'\d', password):
            flash("Password must be at least 8 characters long and contain both letters and numbers.", "danger")
            return render_template('auth/register.html', selected_role=role)

        # Indian mobile number validation (10 digits starting with 6-9, ignoring leading +91 or 91)
        clean_phone = re.sub(r'[\s\-\+]', '', phone)
        if clean_phone.startswith('91') and len(clean_phone) == 12:
            clean_phone = clean_phone[2:]
        if not re.match(r'^[6-9]\d{9}$', clean_phone):
            flash("Please enter a valid 10-digit Indian mobile number starting with 6-9.", "danger")
            return render_template('auth/register.html', selected_role=role)

        # Unique email validation (case-insensitive)
        if User.query.filter(User.email.ilike(email)).first():
            flash("An account with this email address already exists. Please sign in.", "warning")
            return render_template('auth/register.html', selected_role=role)

        # Unique mobile validation
        if User.query.filter((User.phone == phone) | (User.phone.like(f"%{clean_phone}%"))).first():
            flash("An account with this mobile number already exists. Please sign in.", "warning")
            return render_template('auth/register.html', selected_role=role)

        if role == 'student':
            if not roll_number:
                flash("Student ID / Roll Number is required for student registration.", "danger")
                return render_template('auth/register.html', selected_role=role)

            if User.query.filter(User.roll_number.ilike(roll_number)).first() or \
               StudentProfile.query.filter(StudentProfile.roll_number.ilike(roll_number)).first():
                flash("An account with this Roll Number already exists. Please sign in.", "warning")
                return render_template('auth/register.html', selected_role=role)

            branch = request.form.get('branch', 'CSE').strip()
            year = request.form.get('year', type=int) or 1
            semester = request.form.get('semester', type=int) or 1
            hostel = request.form.get('hostel', 'Hostel A').strip()
            room = request.form.get('room', '').strip()
            batch = request.form.get('batch', '2024-2028').strip()
            student_pin = clean_phone[-4:] if len(clean_phone) >= 4 else '0000'

            new_user = User(
                name=name,
                email=email,
                phone=phone,
                role='student',
                status='active',
                is_active=True,
                email_verified=False,
                phone_verified=False,
                roll_number=roll_number,
                branch=branch,
                year=year,
                hostel=hostel,
                room=room,
                batch=batch,
                pin=student_pin,
                must_change_password=False
            )
            new_user.set_password(password)

            student_role = Role.query.filter_by(name='student').first()
            if student_role:
                new_user.roles.append(student_role)

            db.session.add(new_user)
            db.session.flush()

            profile = StudentProfile(
                user_id=new_user.id,
                roll_number=roll_number,
                branch=branch,
                year=year,
                semester=semester,
                batch=batch,
                hostel=hostel,
                room=room,
                pin=student_pin,
                fee_dues=0.0
            )
            db.session.add(profile)
            db.session.commit()

            log_audit_action(new_user.id, 'user', new_user.id, 'student_registered', notes=f"Student {name} registered with Roll {roll_number}")
            flash("Registration successful! Please sign in with your credentials.", "success")
            return redirect(url_for('auth.login', role='student'))

        else:
            # Non-student roles: Admin, Warden, Faculty, Mess Manager, Maintenance, Office Staff
            if not emp_code:
                flash("University Pre-Approved Employee Code is required for staff/admin registration.", "danger")
                return render_template('auth/register.html', selected_role=role)

            # Query pre-approved employee code
            code_obj = PreApprovedEmployeeCode.query.filter_by(employee_code=emp_code).first()
            if not code_obj:
                flash(f"Invalid Employee Code '{emp_code}'. Please provide an authentic college-issued employee code.", "danger")
                return render_template('auth/register.html', selected_role=role)

            if code_obj.status == 'used':
                flash(f"Employee Code '{emp_code}' has already been used. Please contact administration.", "danger")
                return render_template('auth/register.html', selected_role=role)

            # Validate role matches pre-approved assignment (admin and super_admin compatible)
            code_role = code_obj.role.lower()
            role_matches = (code_role == role) or (code_role in ('admin', 'super_admin') and role in ('admin', 'super_admin'))
            if not role_matches:
                flash(f"Role mismatch: Employee Code '{emp_code}' was issued for the '{code_obj.role.replace('_', ' ').title()}' role, not '{role.replace('_', ' ').title()}'.", "danger")
                return render_template('auth/register.html', selected_role=role)

            if StaffProfile.query.filter(StaffProfile.employee_id.ilike(emp_code)).first():
                flash(f"A staff account with Employee Code '{emp_code}' already exists. Please sign in.", "warning")
                return render_template('auth/register.html', selected_role=role)

            assigned_hostel = None
            assigned_sections = None
            specialization = None
            office_unit = None

            if role == 'faculty':
                department = request.form.get('department', code_obj.department or 'CSE').strip()
                designation = request.form.get('designation', 'Assistant Professor').strip()
                assigned_sections = request.form.get('assigned_sections', 'CSE-3A').strip()
            elif role == 'warden':
                assigned_hostel = request.form.get('assigned_hostel', 'Hostel A').strip()
                department = 'Hostel Administration'
                designation = request.form.get('designation', 'Hostel Superintendent / Warden').strip()
            elif role == 'mess_manager':
                assigned_hostel = request.form.get('assigned_mess', 'Hostel A Dining').strip()
                department = 'Mess & Catering'
                designation = 'Mess Manager'
            elif role == 'maintenance':
                specialization = request.form.get('specialization', 'Electrical').strip()
                department = 'Estate & Maintenance'
                designation = f"{specialization} Technician"
            elif role == 'office_staff':
                office_unit = request.form.get('office_unit', 'Academic Section').strip()
                department = office_unit
                designation = request.form.get('designation', 'Administrative Officer').strip()
            elif role in ('admin', 'super_admin'):
                department = request.form.get('department', code_obj.department or 'Central Administration').strip()
                designation = request.form.get('designation', 'Administrator').strip()
            else:
                department = 'Administration'
                designation = 'Staff'

            effective_role = code_obj.role if code_obj.role in ('admin', 'super_admin') else role

            new_user = User(
                name=name,
                email=email,
                phone=phone,
                role=effective_role,
                status='active',
                is_active=True,
                email_verified=False,
                phone_verified=False,
                hostel=assigned_hostel if role in ('warden', 'mess_manager') else None,
                branch=department if role == 'faculty' else None,
                must_change_password=False
            )
            new_user.set_password(password)

            role_obj = Role.query.filter_by(name=effective_role).first()
            if role_obj:
                new_user.roles.append(role_obj)

            db.session.add(new_user)
            db.session.flush()

            staff_profile = StaffProfile(
                user_id=new_user.id,
                employee_id=emp_code,
                department=department,
                designation=designation,
                requested_role=effective_role,
                assigned_hostel=assigned_hostel,
                assigned_sections=assigned_sections,
                office_unit=office_unit,
                specialization=specialization
            )
            db.session.add(staff_profile)

            # Mark Pre-Approved Employee Code as used
            code_obj.status = 'used'
            code_obj.used_at = datetime.utcnow()
            code_obj.used_by_id = new_user.id

            db.session.commit()

            role_display = effective_role.replace('_', ' ').title()
            log_audit_action(new_user.id, 'user', new_user.id, f'{effective_role}_registered', notes=f"Staff {name} ({effective_role}) registered with verified Employee Code {emp_code}")
            flash(f"Registration successful for {role_display}! Please sign in to access your portal.", "success")
            return redirect(url_for('auth.login', role=effective_role))

    return render_template('auth/register.html', selected_role=selected_role)



@auth_bp.route('/verify-otp', methods=['GET', 'POST'])
def verify_otp_view():
    identifier = session.get('pending_verification_identifier') or request.args.get('identifier', '')
    purpose = session.get('pending_verification_purpose') or request.args.get('purpose', 'registration_mobile')
    user_id = session.get('pending_verification_user_id')

    if not identifier:
        flash("No verification request found. Please login or register.", "warning")
        return redirect(url_for('auth.login'))

    if request.method == 'POST':
        otp = request.form.get('otp', '').strip()
        if not otp:
            flash("Please enter the 6-digit OTP code.", "danger")
            return render_template('auth/verify_otp.html', identifier=identifier, purpose=purpose)

        success, msg = verify_otp(identifier, otp, purpose)
        if not success:
            flash(msg, "danger")
            return render_template('auth/verify_otp.html', identifier=identifier, purpose=purpose)

        # OTP verified successfully
        if user_id:
            user = User.query.get(user_id)
            if user:
                if 'mobile' in purpose:
                    user.phone_verified = True
                else:
                    user.email_verified = True
                db.session.commit()

                # If student, activate and auto-login
                if user.primary_role == 'student':
                    user.status = 'active'
                    user.is_active = True
                    db.session.commit()
                    login_user(user)
                    register_successful_login(user)
                    session.pop('pending_verification_identifier', None)
                    session.pop('pending_verification_purpose', None)
                    session.pop('pending_verification_user_id', None)
                    flash("Mobile verified successfully! Welcome to ABHYURTI Campus OS.", "success")
                    return redirect(url_for('student.home'))
                else:
                    # Staff verified OTP, now awaiting Super Admin approval
                    login_user(user)
                    register_successful_login(user)
                    session.pop('pending_verification_identifier', None)
                    session.pop('pending_verification_purpose', None)
                    session.pop('pending_verification_user_id', None)
                    flash("Contact verified! Your application is in 'Pending Verification' awaiting Super Admin review.", "info")
                    return redirect(url_for('auth.pending_approval'))

        flash("Verification successful! Please log in.", "success")
        return redirect(url_for('auth.login'))

    return render_template('auth/verify_otp.html', identifier=identifier, purpose=purpose)


@auth_bp.route('/resend-otp', methods=['POST'])
def resend_otp():
    identifier = request.form.get('identifier', '').strip()
    purpose = request.form.get('purpose', 'registration_mobile').strip()

    if not identifier:
        return jsonify({'success': False, 'message': 'Identifier is required.'}), 400

    record, plain_otp = create_or_update_otp(identifier, purpose)
    if not record:
        return jsonify({'success': False, 'message': plain_otp}), 429

    return jsonify({
        'success': True,
        'message': f"New OTP dispatched successfully! (Demo OTP: {plain_otp})",
        'demo_otp': plain_otp
    })


@auth_bp.route('/pending-approval')
@login_required
def pending_approval():
    approval = ApprovalRequest.query.filter_by(staff_user_id=current_user.id).order_by(ApprovalRequest.created_at.desc()).first()
    return render_template('auth/pending_approval.html', approval=approval)


@auth_bp.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        identifier = request.form.get('identifier', '').strip().lower()
        if not identifier:
            flash("Please enter your registered email or mobile number.", "danger")
            return render_template('auth/forgot_password.html')

        user = find_user_by_identifier(identifier)

        if not user:
            flash("If that account exists, an OTP has been dispatched.", "info")
            return redirect(url_for('auth.reset_password', identifier=identifier))

        # Generate OTP
        target = user.phone or user.email
        record, plain_otp = create_or_update_otp(target, 'password_reset')
        if not record:
            flash(plain_otp, "warning")
            return render_template('auth/forgot_password.html')

        flash(f"Password reset OTP sent to your registered contact! (Demo OTP: {plain_otp})", "info")
        return redirect(url_for('auth.reset_password', identifier=target))

    return render_template('auth/forgot_password.html')


@auth_bp.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    identifier = request.args.get('identifier', '').strip()

    if request.method == 'POST':
        identifier = request.form.get('identifier', '').strip()
        otp = request.form.get('otp', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        if not identifier or not otp or not password:
            flash("All fields are required.", "danger")
            return render_template('auth/reset_password.html', identifier=identifier)

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return render_template('auth/reset_password.html', identifier=identifier)

        if len(password) < 6:
            flash("Password must be at least 6 characters.", "danger")
            return render_template('auth/reset_password.html', identifier=identifier)

        success, msg = verify_otp(identifier, otp, 'password_reset')
        if not success:
            flash(msg, "danger")
            return render_template('auth/reset_password.html', identifier=identifier)

        user = find_user_by_identifier(identifier)

        if not user:
            flash("User not found.", "danger")
            return redirect(url_for('auth.login'))

        user.set_password(password)
        user.failed_login_attempts = 0
        user.locked_until = None
        db.session.commit()

        log_audit_action(user.id, 'user', user.id, 'password_reset', notes="Password successfully changed via OTP")
        flash("Password successfully reset! Please sign in with your new password.", "success")
        return redirect(url_for('auth.login'))

    return render_template('auth/reset_password.html', identifier=identifier)


@auth_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        phone = request.form.get('phone', '').strip()
        pin = request.form.get('pin', '').strip()

        if phone and phone != current_user.phone:
            # Check duplicate phone
            existing = User.query.filter_by(phone=phone).first()
            if existing and existing.id != current_user.id:
                flash("That mobile number is already registered by another user.", "danger")
                return redirect(url_for('auth.profile'))
            current_user.phone = phone
            current_user.phone_verified = False

        if pin and len(pin) >= 4:
            current_user.pin = pin
            if current_user.student_profile:
                current_user.student_profile.pin = pin

        db.session.commit()
        log_audit_action(current_user.id, 'user', current_user.id, 'profile_updated', notes="User updated contact info / PIN")
        flash("Profile updated successfully.", "success")
        return redirect(url_for('auth.profile'))

    sessions = UserSession.query.filter_by(user_id=current_user.id).order_by(UserSession.last_activity_at.desc()).limit(10).all()
    current_token = session.get('session_token')
    return render_template('auth/profile.html', sessions=sessions, current_token=current_token)


@auth_bp.route('/sessions/<int:id>/terminate', methods=['POST'])
@login_required
def terminate_session(id):
    sess = UserSession.query.filter_by(id=id, user_id=current_user.id).first_or_404()
    sess.is_active = False
    db.session.commit()
    flash("Session terminated successfully.", "success")
    return redirect(url_for('auth.profile'))


@auth_bp.route('/logout', methods=['GET', 'POST'])
def logout():
    if current_user.is_authenticated:
        uid = current_user.id
        terminate_current_session(uid)
        logout_user()
    session.clear()
    
    response = redirect(url_for('auth.login'))
    # Fully delete session cookies and remember token
    session_cookie_name = current_app.config.get('SESSION_COOKIE_NAME', 'session')
    remember_cookie_name = current_app.config.get('REMEMBER_COOKIE_NAME', 'remember_token')
    response.delete_cookie(session_cookie_name, path='/')
    response.delete_cookie(remember_cookie_name, path='/')
    
    # Strictly prevent caching of authenticated views
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0, private"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    
    flash("You have been signed out successfully.", "info")
    return response
