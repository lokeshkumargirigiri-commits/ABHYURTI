from datetime import datetime, timedelta
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app.extensions import db, login_manager

# Many-to-Many Association Table: User <-> Role
user_roles = db.Table(
    'user_roles',
    db.Column('id', db.Integer, primary_key=True),
    db.Column('user_id', db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True),
    db.Column('role_id', db.Integer, db.ForeignKey('roles.id', ondelete='CASCADE'), nullable=False, index=True),
    db.Column('assigned_at', db.DateTime, default=datetime.utcnow),
    db.Column('assigned_by_id', db.Integer, nullable=True),
    db.UniqueConstraint('user_id', 'role_id', name='uq_user_role')
)

# Many-to-Many Association Table: Role <-> Permission
role_permissions = db.Table(
    'role_permissions',
    db.Column('id', db.Integer, primary_key=True),
    db.Column('role_id', db.Integer, db.ForeignKey('roles.id', ondelete='CASCADE'), nullable=False, index=True),
    db.Column('permission_id', db.Integer, db.ForeignKey('permissions.id', ondelete='CASCADE'), nullable=False, index=True),
    db.UniqueConstraint('role_id', 'permission_id', name='uq_role_permission')
)

UserRole = user_roles
RolePermission = role_permissions


class Role(db.Model):
    __tablename__ = 'roles'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), unique=True, nullable=False, index=True)
    display_name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    is_system_role = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    permissions = db.relationship('Permission', secondary=role_permissions, backref=db.backref('roles', lazy='dynamic'), lazy='dynamic')
    users = db.relationship('User', secondary=user_roles, back_populates='roles')

    def __repr__(self):
        return f'<Role {self.name}>'


class Permission(db.Model):
    __tablename__ = 'permissions'

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(80), unique=True, nullable=False, index=True)
    name = db.Column(db.String(100), nullable=False)
    module = db.Column(db.String(50), nullable=False)
    description = db.Column(db.Text, nullable=True)

    def __repr__(self):
        return f'<Permission {self.code}>'


class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    phone = db.Column(db.String(20), unique=True, nullable=True, index=True)
    password_hash = db.Column(db.String(256), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    
    # Account status & access
    role = db.Column(db.String(30), default='student')  # Primary role legacy/fallback
    status = db.Column(db.String(30), default='active')  # 'active', 'pending_verification', 'rejected', 'deactivated'
    is_active = db.Column(db.Boolean, default=True)
    email_verified = db.Column(db.Boolean, default=False)
    phone_verified = db.Column(db.Boolean, default=False)
    failed_login_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime, nullable=True)
    last_login_at = db.Column(db.DateTime, nullable=True)

    # Legacy direct student/hostel columns preserved for backward compatibility
    roll_number = db.Column(db.String(30), unique=True, index=True, nullable=True)
    batch = db.Column(db.String(30), nullable=True)      # e.g., '2024-2028'
    branch = db.Column(db.String(50), nullable=True)     # e.g., 'CSE', 'ECE', 'ME'
    hostel = db.Column(db.String(50), nullable=True)     # e.g., 'Hostel A', 'Hostel B'
    room = db.Column(db.String(20), nullable=True)       # e.g., '204'
    year = db.Column(db.Integer, nullable=True)          # 1, 2, 3, 4
    pin = db.Column(db.String(10), nullable=True)        # For kiosk access
    must_change_password = db.Column(db.Boolean, default=False)

    # Audit & timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    updated_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)

    # Relationships
    roles = db.relationship('Role', secondary=user_roles, back_populates='users', lazy='joined')
    student_profile = db.relationship('StudentProfile', backref='user', uselist=False, cascade='all, delete-orphan')
    staff_profile = db.relationship('StaffProfile', foreign_keys='StaffProfile.user_id', backref='user', uselist=False, cascade='all, delete-orphan')
    sessions = db.relationship('UserSession', backref='user', cascade='all, delete-orphan', lazy=True)
    notifications = db.relationship('Notification', foreign_keys='Notification.user_id', backref='recipient', cascade='all, delete-orphan', lazy=True)
    complaints = db.relationship('Complaint', foreign_keys='Complaint.student_id', backref='student', lazy=True)
    gate_passes = db.relationship('GatePass', foreign_keys='GatePass.student_id', backref='student', lazy=True)
    notice_reads = db.relationship('NoticeRead', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def has_role(self, *role_names):
        """Check if user has any of the given roles."""
        assigned_names = {r.name for r in self.roles}
        if self.role:
            assigned_names.add(self.role)
        return any(rn in assigned_names for rn in role_names)

    def has_permission(self, permission_code):
        """Check if user has a permission via any assigned role, or Super Admin privilege."""
        if self.has_role('super_admin') or self.role == 'admin':
            return True
        for r in self.roles:
            for p in r.permissions:
                if p.code == permission_code:
                    return True
        return False

    @property
    def primary_role(self):
        if self.roles:
            return self.roles[0].name
        return self.role or 'student'

    @property
    def is_admin(self):
        return self.has_role('admin', 'super_admin')

    @property
    def is_super_admin(self):
        return self.has_role('super_admin')

    @property
    def is_warden(self):
        return self.has_role('warden')

    @property
    def is_student(self):
        return self.has_role('student') or self.role == 'student'

    @property
    def is_faculty(self):
        return self.has_role('faculty')

    @property
    def is_mess_manager(self):
        return self.has_role('mess_manager')

    @property
    def is_maintenance(self):
        return self.has_role('maintenance')

    @property
    def is_office_staff(self):
        return self.has_role('office_staff')

    @property
    def is_account_locked(self):
        if self.locked_until and self.locked_until > datetime.utcnow():
            return True
        return False

    def __repr__(self):
        return f'<User {self.email} ({self.primary_role})>'


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class StudentProfile(db.Model):
    __tablename__ = 'student_profiles'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), unique=True, nullable=False)
    roll_number = db.Column(db.String(30), unique=True, nullable=False, index=True)
    branch = db.Column(db.String(50), nullable=True)
    year = db.Column(db.Integer, nullable=True)
    semester = db.Column(db.Integer, nullable=True)
    batch = db.Column(db.String(30), nullable=True)
    hostel = db.Column(db.String(50), nullable=True)
    room = db.Column(db.String(20), nullable=True)
    pin = db.Column(db.String(10), nullable=True)
    emergency_contact_name = db.Column(db.String(100), nullable=True)
    emergency_contact_phone = db.Column(db.String(20), nullable=True)
    fee_dues = db.Column(db.Float, default=0.0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class StaffProfile(db.Model):
    __tablename__ = 'staff_profiles'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), unique=True, nullable=False)
    employee_id = db.Column(db.String(50), unique=True, nullable=False, index=True)
    department = db.Column(db.String(100), nullable=False)
    designation = db.Column(db.String(100), nullable=True)
    requested_role = db.Column(db.String(50), nullable=False)
    assigned_hostel = db.Column(db.String(50), nullable=True)     # For Hostel Warden
    assigned_sections = db.Column(db.String(100), nullable=True)  # For Faculty (e.g. "CSE-3A, CSE-3B")
    office_unit = db.Column(db.String(100), nullable=True)        # For Office Staff (e.g. "Academic Section")
    specialization = db.Column(db.String(100), nullable=True)     # For Maintenance (e.g. "Plumbing", "Electrical")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class PreApprovedEmployeeCode(db.Model):
    __tablename__ = 'preapproved_employee_codes'

    id = db.Column(db.Integer, primary_key=True)
    employee_code = db.Column(db.String(50), unique=True, nullable=False, index=True)
    role = db.Column(db.String(50), nullable=False, index=True)  # 'admin', 'warden', 'faculty', 'mess_manager', 'maintenance', 'office_staff', 'super_admin'
    name = db.Column(db.String(100), nullable=True)
    department = db.Column(db.String(100), nullable=True)
    status = db.Column(db.String(20), default='unused', index=True)  # 'unused', 'used'
    used_at = db.Column(db.DateTime, nullable=True)
    used_by_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships
    used_by = db.relationship('User', foreign_keys=[used_by_id])

    def __repr__(self):
        return f'<PreApprovedEmployeeCode {self.employee_code} ({self.role}) - {self.status}>'


class OTPVerification(db.Model):
    __tablename__ = 'otp_verifications'

    id = db.Column(db.Integer, primary_key=True)
    identifier = db.Column(db.String(120), nullable=False, index=True)  # email or mobile
    otp_hash = db.Column(db.String(256), nullable=False)
    purpose = db.Column(db.String(50), nullable=False)  # 'registration_mobile', 'registration_email', 'login', 'password_reset'
    attempts = db.Column(db.Integer, default=0)
    max_attempts = db.Column(db.Integer, default=3)
    is_verified = db.Column(db.Boolean, default=False)
    expires_at = db.Column(db.DateTime, nullable=False)
    resend_available_at = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def is_expired(self):
        return datetime.utcnow() > self.expires_at

    @property
    def can_attempt(self):
        return self.attempts < self.max_attempts and not self.is_expired and not self.is_verified


class UserSession(db.Model):
    __tablename__ = 'user_sessions'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    session_token = db.Column(db.String(128), unique=True, nullable=False, index=True)
    ip_address = db.Column(db.String(45), nullable=True)
    user_agent = db.Column(db.String(255), nullable=True)
    device_name = db.Column(db.String(100), default='Browser')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_activity_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)


class ApprovalRequest(db.Model):
    __tablename__ = 'approval_requests'

    id = db.Column(db.Integer, primary_key=True)
    staff_user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    requested_role_name = db.Column(db.String(50), nullable=False)
    status = db.Column(db.String(30), default='pending')  # 'pending', 'approved', 'rejected', 'corrections_requested'
    reviewed_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    review_notes = db.Column(db.Text, nullable=True)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    staff_user = db.relationship('User', foreign_keys=[staff_user_id], backref='staff_approval_requests')
    reviewer = db.relationship('User', foreign_keys=[reviewed_by])


class Notification(db.Model):
    __tablename__ = 'notifications'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    title = db.Column(db.String(150), nullable=False)
    message = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), default='system')  # 'approval', 'gate_pass', 'complaint', 'academic', 'mess', 'document', 'system'
    link = db.Column(db.String(255), nullable=True)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class Attendance(db.Model):
    __tablename__ = 'attendances'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    faculty_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    subject_code = db.Column(db.String(30), nullable=False)
    subject_name = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False, default=datetime.utcnow().date)
    status = db.Column(db.String(20), default='present')  # 'present', 'absent', 'late', 'excused'
    remarks = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref='attendance_records')
    faculty = db.relationship('User', foreign_keys=[faculty_id])


class LeaveRequest(db.Model):
    __tablename__ = 'leave_requests'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    faculty_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    start_date = db.Column(db.DateTime, nullable=False)
    end_date = db.Column(db.DateTime, nullable=False)
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), default='pending')  # 'pending', 'approved', 'rejected'
    rejection_reason = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref='leave_requests')
    reviewer = db.relationship('User', foreign_keys=[faculty_id])


class DocumentRequest(db.Model):
    __tablename__ = 'document_requests'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    document_type = db.Column(db.String(50), nullable=False)  # 'bonafide', 'noc', 'clearance', 'character', 'fee_receipt'
    reason = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(30), default='submitted')  # 'submitted', 'under_review', 'approved', 'rejected', 'completed'
    processed_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    remarks = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref='document_requests')
    processor = db.relationship('User', foreign_keys=[processed_by])


class Complaint(db.Model):
    __tablename__ = 'complaints'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    category = db.Column(db.String(50), nullable=False)  # plumbing, electrical, furniture, etc.
    description = db.Column(db.Text, nullable=False)
    room = db.Column(db.String(20), nullable=False)
    hostel = db.Column(db.String(50), nullable=False)
    photo_path = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(30), default='submitted')  # submitted, acknowledged, in_progress, resolved, closed
    assigned_to = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime, nullable=True)
    resolution_notes = db.Column(db.Text, nullable=True)
    is_repeat = db.Column(db.Boolean, default=False)

    assigned_staff = db.relationship('User', foreign_keys=[assigned_to], backref='assigned_complaints')
    maintenance_ticket = db.relationship('MaintenanceTicket', backref='complaint', uselist=False, cascade='all, delete-orphan')

    @property
    def age_days(self):
        delta = datetime.utcnow() - self.created_at
        return delta.days

    @property
    def age_bucket(self):
        days = self.age_days
        if days <= 3:
            return 'green'   # 0-3 days (Fresh)
        elif days <= 7:
            return 'amber'   # 4-7 days (Attention needed)
        else:
            return 'red'     # 8+ days (Critical ageing)

    @property
    def age_label(self):
        days = self.age_days
        if days == 0:
            delta = datetime.utcnow() - self.created_at
            hours = int(delta.total_seconds() // 3600)
            return f'{hours}h ago' if hours > 0 else 'Just now'
        return f'{days}d old'


class MaintenanceTicket(db.Model):
    __tablename__ = 'maintenance_tickets'

    id = db.Column(db.Integer, primary_key=True)
    complaint_id = db.Column(db.Integer, db.ForeignKey('complaints.id', ondelete='CASCADE'), unique=True, nullable=False)
    assigned_staff_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    status = db.Column(db.String(30), default='assigned')  # 'assigned', 'in_progress', 'materials_pending', 'resolved'
    materials_used = db.Column(db.Text, nullable=True)
    resolution_notes = db.Column(db.Text, nullable=True)
    resolution_photo = db.Column(db.String(255), nullable=True)
    resolved_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    assigned_staff = db.relationship('User', foreign_keys=[assigned_staff_id], backref='maintenance_tickets')


class MessMenu(db.Model):
    __tablename__ = 'mess_menus'

    id = db.Column(db.Integer, primary_key=True)
    day_of_week = db.Column(db.String(20), nullable=False)  # 'Monday', 'Tuesday', ...
    meal_type = db.Column(db.String(20), nullable=False)    # 'Breakfast', 'Lunch', 'Snacks', 'Dinner'
    date = db.Column(db.Date, nullable=True)
    items_description = db.Column(db.Text, nullable=False)
    special_diet_notes = db.Column(db.Text, nullable=True)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    creator = db.relationship('User', foreign_keys=[created_by])


class MessFeedback(db.Model):
    __tablename__ = 'mess_feedbacks'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    rating = db.Column(db.Integer, nullable=False)  # 1 to 5
    category = db.Column(db.String(50), nullable=False)  # 'food_quality', 'cleanliness', 'portion_size', 'staff_behavior', 'punctuality'
    meal_type = db.Column(db.String(20), nullable=False)  # 'Breakfast', 'Lunch', 'Snacks', 'Dinner'
    feedback_text = db.Column(db.Text, nullable=False)
    response_notes = db.Column(db.Text, nullable=True)
    responded_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    status = db.Column(db.String(20), default='new')  # 'new', 'reviewed', 'action_taken'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref='mess_feedbacks')
    responder = db.relationship('User', foreign_keys=[responded_by])


class CanteenIssueReport(db.Model):
    __tablename__ = 'canteen_issue_reports'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    hostel = db.Column(db.String(50), nullable=True)
    food_name = db.Column(db.String(120), nullable=False)
    issue_type = db.Column(db.String(80), nullable=False)  # 'Under-cooked', 'Hygiene / Foreign Object', 'Cold Food', 'Bad Smell / Stale', 'Too Salty / Spicy', 'Other'
    meal_type = db.Column(db.String(30), nullable=True)    # 'Breakfast', 'Lunch', 'Snacks', 'Dinner'
    notes = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(30), default='pending', index=True)  # 'pending', 'investigating', 'resolved'
    admin_notes = db.Column(db.Text, nullable=True)
    resolved_by_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='SET NULL'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime, nullable=True)

    # Relationships
    student = db.relationship('User', foreign_keys=[student_id], backref='canteen_issues')
    resolved_by = db.relationship('User', foreign_keys=[resolved_by_id])

    def __repr__(self):
        return f'<CanteenIssueReport {self.food_name} - {self.issue_type} ({self.status})>'


class GatePass(db.Model):
    __tablename__ = 'gate_passes'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    from_date = db.Column(db.DateTime, nullable=False)
    to_date = db.Column(db.DateTime, nullable=False)
    reason = db.Column(db.Text, nullable=False)
    destination = db.Column(db.String(150), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected, returned
    approved_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    rejection_reason = db.Column(db.Text, nullable=True)
    is_emergency = db.Column(db.Boolean, default=False)
    emergency_reason = db.Column(db.Text, nullable=True)
    parent_notified = db.Column(db.Boolean, default=False)
    actual_return_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    approver = db.relationship('User', foreign_keys=[approved_by], backref='approved_passes')

    @property
    def elapsed_minutes(self):
        delta = datetime.utcnow() - self.created_at
        return int(delta.total_seconds() // 60)

    @property
    def is_sla_breached(self):
        if self.is_emergency and self.status == 'pending':
            return self.elapsed_minutes > 30
        return False

    @property
    def is_overdue(self):
        if self.status == 'approved' and not self.actual_return_at:
            return datetime.utcnow() > self.to_date
        return False


class Notice(db.Model):
    __tablename__ = 'notices'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    body = db.Column(db.Text, nullable=False)
    target_role = db.Column(db.String(50), nullable=True)     # NULL means All roles
    target_batch = db.Column(db.String(30), nullable=True)    # NULL means All
    target_branch = db.Column(db.String(50), nullable=True)   # NULL means All
    target_hostel = db.Column(db.String(50), nullable=True)   # NULL means All
    target_year = db.Column(db.Integer, nullable=True)        # NULL means All
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    published_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=True)
    requires_action = db.Column(db.Boolean, default=False)
    action_label = db.Column(db.String(60), default='Acknowledge & Confirm')
    status = db.Column(db.String(20), default='published')    # published, draft, archived

    creator = db.relationship('User', foreign_keys=[created_by], backref='created_notices')
    reads = db.relationship('NoticeRead', backref='notice', lazy='dynamic', cascade='all, delete-orphan')

    @property
    def targeting_summary(self):
        parts = []
        if self.target_hostel:
            parts.append(f'Hostel: {self.target_hostel}')
        if self.target_year:
            parts.append(f'Year: {self.target_year}')
        if self.target_branch:
            parts.append(f'Branch: {self.target_branch}')
        if self.target_batch:
            parts.append(f'Batch: {self.target_batch}')
        return ' | '.join(parts) if parts else 'All Students (Campus-wide)'


class NoticeRead(db.Model):
    __tablename__ = 'notice_reads'

    id = db.Column(db.Integer, primary_key=True)
    notice_id = db.Column(db.Integer, db.ForeignKey('notices.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    read_at = db.Column(db.DateTime, default=datetime.utcnow)
    action_at = db.Column(db.DateTime, nullable=True)

    __table_args__ = (
        db.UniqueConstraint('notice_id', 'user_id', name='uq_notice_user_read'),
    )


class AuditLog(db.Model):
    __tablename__ = 'audit_logs'

    id = db.Column(db.Integer, primary_key=True)
    actor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    entity_type = db.Column(db.String(50), nullable=False)  # complaint, gate_pass, notice, user, staff_approval, role, attendance, mess, document
    entity_id = db.Column(db.Integer, nullable=False)
    action = db.Column(db.String(50), nullable=False)       # status_change, approved, rejected, created, returned, role_change, activation_change
    old_status = db.Column(db.String(50), nullable=True)
    new_status = db.Column(db.String(50), nullable=True)
    notes = db.Column(db.Text, nullable=True)
    ip_address = db.Column(db.String(45), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    actor = db.relationship('User', foreign_keys=[actor_id])


class SystemSetting(db.Model):
    __tablename__ = 'system_settings'

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False, index=True)
    value = db.Column(db.Text, nullable=True)
    category = db.Column(db.String(50), default='general')  # ai, maps, firebase, storage, sms, email, database, ocr
    is_secret = db.Column(db.Boolean, default=False)
    description = db.Column(db.String(255), nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def masked_value(self):
        if not self.value:
            return ""
        if not self.is_secret:
            return self.value
        if len(self.value) <= 8:
            return "••••••••"
        return self.value[:4] + "••••••••" + self.value[-4:]

    def __repr__(self):
        return f'<SystemSetting {self.key}>'


class FCMSubscription(db.Model):
    __tablename__ = 'fcm_subscriptions'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    token = db.Column(db.Text, nullable=False, unique=True)
    device_info = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', backref=db.backref('fcm_subscriptions', cascade='all, delete-orphan'))

    def __repr__(self):
        return f'<FCMSubscription user_id={self.user_id}>'


# ============================================================================
# NEW FOUNDATION MODELS FOR CAMPUS OS EXPANSION (SPECS A - I)
# ============================================================================

class FeePayment(db.Model):
    __tablename__ = 'fee_payments'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    fee_type = db.Column(db.String(50), nullable=False, default='semester')  # semester, exam, hostel, library, fine
    semester = db.Column(db.Integer, nullable=True)                          # 1 to 8
    academic_year = db.Column(db.String(20), nullable=True)                  # e.g. 2024-2025
    amount = db.Column(db.Float, nullable=False)
    late_fine = db.Column(db.Float, default=0.0)
    concession_amount = db.Column(db.Float, default=0.0)
    concession_reason = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(30), default='pending', index=True)         # pending, paid, waived, failed
    payment_method = db.Column(db.String(50), nullable=True)                 # mock_upi, mock_netbanking, cash_counter
    transaction_ref = db.Column(db.String(100), nullable=True, unique=True)
    receipt_token = db.Column(db.String(128), nullable=True, unique=True, index=True)
    receipt_signature = db.Column(db.String(128), nullable=True)             # HMAC SHA-256 signature
    paid_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref=db.backref('fee_payments', lazy=True))

    @property
    def total_payable(self):
        return max(0.0, (self.amount or 0.0) + (self.late_fine or 0.0) - (self.concession_amount or 0.0))

    def __repr__(self):
        return f'<FeePayment id={self.id} student_id={self.student_id} status={self.status}>'


class CafeteriaItem(db.Model):
    __tablename__ = 'cafeteria_items'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    category = db.Column(db.String(50), default='meal')                       # meal, beverage, snack, dessert
    price = db.Column(db.Float, nullable=False)
    is_available = db.Column(db.Boolean, default=True, index=True)
    description = db.Column(db.Text, nullable=True)
    image_url = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<CafeteriaItem {self.name} available={self.is_available}>'


class CafeteriaOrder(db.Model):
    __tablename__ = 'cafeteria_orders'

    id = db.Column(db.Integer, primary_key=True)
    order_token = db.Column(db.String(50), unique=True, nullable=False, index=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    total_amount = db.Column(db.Float, nullable=False)
    payment_status = db.Column(db.String(30), default='paid')                 # paid, pending
    payment_method = db.Column(db.String(50), default='mock_upi')
    status = db.Column(db.String(30), default='placed', index=True)           # placed, preparing, ready, delivered, cancelled
    special_instructions = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref=db.backref('cafeteria_orders', lazy=True))
    items = db.relationship('CafeteriaOrderItem', backref='order', cascade='all, delete-orphan', lazy=True)

    def __repr__(self):
        return f'<CafeteriaOrder {self.order_token} status={self.status}>'


class CafeteriaOrderItem(db.Model):
    __tablename__ = 'cafeteria_order_items'

    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('cafeteria_orders.id', ondelete='CASCADE'), nullable=False)
    item_id = db.Column(db.Integer, db.ForeignKey('cafeteria_items.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    unit_price = db.Column(db.Float, nullable=False)

    item = db.relationship('CafeteriaItem')


class CyberCafeRequest(db.Model):
    __tablename__ = 'cyber_cafe_requests'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    request_type = db.Column(db.String(50), nullable=False)                   # scholarship, terminal_slot, print_xerox
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=True)
    priority = db.Column(db.Integer, default=2)                               # 1=scholarship, 2=slot, 3=print
    slot_date = db.Column(db.Date, nullable=True)
    slot_time = db.Column(db.String(50), nullable=True)
    document_path = db.Column(db.String(255), nullable=True)
    pages = db.Column(db.Integer, default=1)
    is_color = db.Column(db.Boolean, default=False)
    contact_phone = db.Column(db.String(20), nullable=True)
    staff_notes = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(30), default='pending', index=True)          # pending, scheduled, in_progress, completed, rejected, rescheduled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = db.relationship('User', foreign_keys=[user_id], backref=db.backref('cyber_cafe_requests', lazy=True))


class LibraryBook(db.Model):
    __tablename__ = 'library_books'

    id = db.Column(db.Integer, primary_key=True)
    isbn = db.Column(db.String(50), nullable=True, index=True)
    title = db.Column(db.String(200), nullable=False, index=True)
    author = db.Column(db.String(150), nullable=False)
    category = db.Column(db.String(100), default='General')
    total_copies = db.Column(db.Integer, default=5)
    available_copies = db.Column(db.Integer, default=5)
    shelf_location = db.Column(db.String(50), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def is_available(self):
        return (self.available_copies or 0) > 0


class LibraryBookRequest(db.Model):
    __tablename__ = 'library_book_requests'

    id = db.Column(db.Integer, primary_key=True)
    book_id = db.Column(db.Integer, db.ForeignKey('library_books.id', ondelete='CASCADE'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    user_type = db.Column(db.String(30), default='student')                   # student, teacher
    status = db.Column(db.String(30), default='requested', index=True)        # requested, issued, returned, rejected, overdue
    issue_date = db.Column(db.DateTime, nullable=True)
    due_date = db.Column(db.DateTime, nullable=True)
    return_date = db.Column(db.DateTime, nullable=True)
    fine_amount = db.Column(db.Float, default=0.0)
    fine_paid = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    book = db.relationship('LibraryBook', backref=db.backref('requests', lazy=True))
    user = db.relationship('User', foreign_keys=[user_id], backref=db.backref('library_requests', lazy=True))


class CampusEvent(db.Model):
    __tablename__ = 'campus_events'

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(50), default='cultural')                   # cultural, technical, sports, workshop
    description = db.Column(db.Text, nullable=True)
    venue = db.Column(db.String(150), nullable=True)
    event_date = db.Column(db.DateTime, nullable=False)
    registration_deadline = db.Column(db.DateTime, nullable=True)
    max_participants = db.Column(db.Integer, default=100)
    is_active = db.Column(db.Boolean, default=True)
    created_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    applications = db.relationship('EventApplication', backref='event', cascade='all, delete-orphan', lazy=True)
    creator = db.relationship('User', foreign_keys=[created_by_id])


class EventApplication(db.Model):
    __tablename__ = 'event_applications'

    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.Integer, db.ForeignKey('campus_events.id', ondelete='CASCADE'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    status = db.Column(db.String(30), default='registered')                   # registered, shortlisted, winner, runner_up, participated
    position = db.Column(db.String(50), nullable=True)                        # 1st, 2nd, 3rd, Special Mention
    certificate_issued = db.Column(db.Boolean, default=False)
    remarks = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref=db.backref('event_applications', lazy=True))


class SportsLiveScore(db.Model):
    __tablename__ = 'sports_live_scores'

    id = db.Column(db.Integer, primary_key=True)
    match_title = db.Column(db.String(200), nullable=False)
    sport_type = db.Column(db.String(50), default='cricket')                  # cricket, football, volleyball, badminton, athletics
    team_a = db.Column(db.String(100), nullable=False)
    team_b = db.Column(db.String(100), nullable=False)
    score_a = db.Column(db.String(100), default='0')
    score_b = db.Column(db.String(100), default='0')
    current_status = db.Column(db.String(50), default='upcoming')             # upcoming, live, completed
    summary = db.Column(db.String(255), nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class StudentWellbeingIndex(db.Model):
    __tablename__ = 'student_wellbeing_indices'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), unique=True, nullable=False)
    attendance_rate = db.Column(db.Float, default=100.0)                      # 0 - 100 %
    assignment_miss_rate = db.Column(db.Float, default=0.0)                   # 0 - 100 %
    isolation_score = db.Column(db.Float, default=0.0)                        # 0 - 100
    self_distress_score = db.Column(db.Float, default=0.0)                    # 0 - 100 (from optional check-in)
    composite_risk_score = db.Column(db.Float, default=0.0)                   # 0 - 100
    risk_level = db.Column(db.String(30), default='low')                      # low, moderate, high, severe
    counselor_flagged = db.Column(db.Boolean, default=False)
    last_calculated_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref=db.backref('wellbeing_index', uselist=False))

    @property
    def attendance_deficit_score(self):
        return max(0.0, 100.0 - float(self.attendance_rate or 100.0))

    @property
    def academic_stress_score(self):
        return float(self.assignment_miss_rate or 0.0)

    @property
    def social_isolation_score(self):
        return float(self.isolation_score or 0.0)


class CounselorSessionNote(db.Model):
    __tablename__ = 'counselor_session_notes'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    counselor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    session_date = db.Column(db.DateTime, default=datetime.utcnow)
    observations = db.Column(db.Text, nullable=False)
    action_plan = db.Column(db.Text, nullable=True)
    follow_up_date = db.Column(db.Date, nullable=True)
    confidentiality_level = db.Column(db.String(50), default='strictly_confidential')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref=db.backref('counselor_notes', lazy=True))
    counselor = db.relationship('User', foreign_keys=[counselor_id])


class Assignment(db.Model):
    __tablename__ = 'assignments'

    id = db.Column(db.Integer, primary_key=True)
    faculty_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    department = db.Column(db.String(50), nullable=True)
    semester = db.Column(db.Integer, nullable=True)
    subject = db.Column(db.String(100), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    file_path = db.Column(db.String(255), nullable=True)
    max_score = db.Column(db.Integer, default=100)
    due_date = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    faculty = db.relationship('User', foreign_keys=[faculty_id], backref=db.backref('created_assignments', lazy=True))
    submissions = db.relationship('AssignmentSubmission', backref='assignment', cascade='all, delete-orphan', lazy=True)


class AssignmentSubmission(db.Model):
    __tablename__ = 'assignment_submissions'

    id = db.Column(db.Integer, primary_key=True)
    assignment_id = db.Column(db.Integer, db.ForeignKey('assignments.id', ondelete='CASCADE'), nullable=False)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    file_path = db.Column(db.String(255), nullable=True)
    submission_text = db.Column(db.Text, nullable=True)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_late = db.Column(db.Boolean, default=False)
    score = db.Column(db.Float, nullable=True)
    feedback = db.Column(db.Text, nullable=True)
    graded_at = db.Column(db.DateTime, nullable=True)

    student = db.relationship('User', foreign_keys=[student_id], backref=db.backref('assignment_submissions', lazy=True))


class HostelNightAttendance(db.Model):
    __tablename__ = 'hostel_night_attendance'

    id = db.Column(db.Integer, primary_key=True)
    hostel = db.Column(db.String(50), nullable=False, index=True)
    room = db.Column(db.String(20), nullable=False, index=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    date = db.Column(db.Date, nullable=False, index=True)
    status = db.Column(db.String(30), default='present')                      # present, absent, on_leave, night_out
    remarks = db.Column(db.String(255), nullable=True)
    marked_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref=db.backref('night_attendance_records', lazy=True))
    marked_by = db.relationship('User', foreign_keys=[marked_by_id])


class CaretakerHealthEmergency(db.Model):
    __tablename__ = 'caretaker_health_emergencies'

    id = db.Column(db.Integer, primary_key=True)
    student_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    hostel = db.Column(db.String(50), nullable=False)
    room = db.Column(db.String(20), nullable=False)
    symptoms = db.Column(db.Text, nullable=False)
    severity = db.Column(db.String(30), default='high')                       # moderate, high, critical
    action_taken = db.Column(db.String(100), default='first_aid')             # first_aid, doctor_called, ambulance_called, hospital_referred
    escalated_to_superintendent = db.Column(db.Boolean, default=True)
    status = db.Column(db.String(30), default='open')                         # open, under_observation, resolved
    reported_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    student = db.relationship('User', foreign_keys=[student_id], backref=db.backref('caretaker_health_emergencies', lazy=True))
    reported_by = db.relationship('User', foreign_keys=[reported_by_id])


class Community(db.Model):
    __tablename__ = 'communities'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    slug = db.Column(db.String(150), unique=True, nullable=False, index=True)
    type = db.Column(db.String(50), nullable=False)                           # department, batch, hostel, day_scholar, interest_club
    description = db.Column(db.Text, nullable=True)
    avatar_icon = db.Column(db.String(50), default='bi-people-fill')
    banner_color = db.Column(db.String(30), default='#3b82f6')
    created_by_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    memberships = db.relationship('CommunityMembership', backref='community', cascade='all, delete-orphan', lazy=True)
    posts = db.relationship('CommunityPost', backref='community', cascade='all, delete-orphan', lazy=True, order_by='CommunityPost.created_at.desc()')


class CommunityMembership(db.Model):
    __tablename__ = 'community_memberships'

    id = db.Column(db.Integer, primary_key=True)
    community_id = db.Column(db.Integer, db.ForeignKey('communities.id', ondelete='CASCADE'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    role = db.Column(db.String(30), default='member')                         # member, moderator, admin
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', foreign_keys=[user_id], backref=db.backref('community_memberships', cascade='all, delete-orphan', lazy=True))

    __table_args__ = (
        db.UniqueConstraint('community_id', 'user_id', name='uq_community_user_member'),
    )


class CommunityPost(db.Model):
    __tablename__ = 'community_posts'

    id = db.Column(db.Integer, primary_key=True)
    community_id = db.Column(db.Integer, db.ForeignKey('communities.id', ondelete='CASCADE'), nullable=False, index=True)
    author_id = db.Column(db.Integer, db.ForeignKey('users.id', ondelete='CASCADE'), nullable=False, index=True)
    post_type = db.Column(db.String(50), default='general')                   # general, announcement, assignment_share, event_share
    title = db.Column(db.String(200), nullable=True)
    content = db.Column(db.Text, nullable=False)
    attachment_url = db.Column(db.String(255), nullable=True)
    is_pinned = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    author = db.relationship('User', foreign_keys=[author_id], backref=db.backref('community_posts', lazy=True))


class ExamSchedule(db.Model):
    __tablename__ = 'exam_schedules'

    id = db.Column(db.Integer, primary_key=True)
    department = db.Column(db.String(50), nullable=False)                  # e.g. CSE, ECE, ME
    semester = db.Column(db.Integer, nullable=False)                       # 1 to 8
    subject_code = db.Column(db.String(30), nullable=False)                # e.g. CS501
    subject_name = db.Column(db.String(150), nullable=False)               # e.g. Operating Systems
    exam_date = db.Column(db.Date, nullable=False)
    time_slot = db.Column(db.String(50), default='10:00 AM - 01:00 PM')
    hall_number = db.Column(db.String(50), default='Main Academic Block - LH-1')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<ExamSchedule {self.subject_code} Sem={self.semester}>'


