from datetime import datetime
from flask import render_template, redirect, url_for, flash, request, jsonify, abort
from flask_login import login_required, current_user
from app.extensions import db
from app.models import (
    User, Role, Permission, UserRole, RolePermission,
    StudentProfile, StaffProfile, ApprovalRequest, Notification,
    AuditLog, Complaint, GatePass, Notice, Attendance, DocumentRequest
)
from app.utils.security import role_required, log_audit_action, create_notification
from app.super_admin import super_admin_bp

@super_admin_bp.route('/')
@super_admin_bp.route('/dashboard')
@login_required
@role_required('super_admin', 'admin')
def dashboard():
    total_users = User.query.count()
    active_students = User.query.filter(User.role == 'student', User.status == 'active').count()
    pending_staff = ApprovalRequest.query.filter_by(status='pending').count()
    total_staff = User.query.filter(User.role != 'student').count()

    total_complaints = Complaint.query.count()
    pending_complaints = Complaint.query.filter(Complaint.status.notin_(['resolved', 'closed'])).count()
    pending_passes = GatePass.query.filter_by(status='pending').count()
    pending_docs = DocumentRequest.query.filter_by(status='submitted').count()

    # Recent pending approval requests
    pending_approvals = ApprovalRequest.query.filter_by(status='pending').order_by(ApprovalRequest.created_at.desc()).limit(5).all()

    # Recent activity audit logs
    recent_audits = AuditLog.query.order_by(AuditLog.created_at.desc()).limit(8).all()

    # Role distribution statistics
    role_counts = {
        'Student': User.query.filter(User.role == 'student').count(),
        'Faculty': User.query.filter(User.role == 'faculty').count(),
        'Hostel Warden': User.query.filter(User.role == 'warden').count(),
        'Mess Manager': User.query.filter(User.role == 'mess_manager').count(),
        'Maintenance Staff': User.query.filter(User.role == 'maintenance').count(),
        'Office Staff': User.query.filter(User.role == 'office_staff').count(),
        'Super Admin': User.query.filter(User.role.in_(['super_admin', 'admin'])).count(),
    }

    return render_template(
        'super_admin/dashboard.html',
        total_users=total_users,
        active_students=active_students,
        pending_staff=pending_staff,
        total_staff=total_staff,
        total_complaints=total_complaints,
        pending_complaints=pending_complaints,
        pending_passes=pending_passes,
        pending_docs=pending_docs,
        pending_approvals=pending_approvals,
        recent_audits=recent_audits,
        role_counts=role_counts
    )


@super_admin_bp.route('/approvals')
@login_required
@role_required('super_admin', 'admin')
def staff_approvals():
    status_filter = request.args.get('status', 'pending')
    query = ApprovalRequest.query
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)

    approvals = query.order_by(ApprovalRequest.created_at.desc()).all()
    return render_template('super_admin/staff_approvals.html', approvals=approvals, current_status=status_filter)


@super_admin_bp.route('/approvals/<int:id>/action', methods=['POST'])
@login_required
@role_required('super_admin', 'admin')
def approval_action(id):
    approval = ApprovalRequest.query.get_or_404(id)
    action = request.form.get('action')  # 'approve', 'reject', 'corrections'
    notes = request.form.get('notes', '').strip()

    staff_user = approval.staff_user
    old_status = approval.status

    if action == 'approve':
        approval.status = 'approved'
        approval.reviewed_by = current_user.id
        approval.reviewed_at = datetime.utcnow()
        approval.review_notes = notes or "Account verified and approved."

        staff_user.status = 'active'
        staff_user.is_active = True

        # Assign role
        target_role = Role.query.filter_by(name=approval.requested_role_name).first()
        if target_role and target_role not in staff_user.roles:
            staff_user.roles.append(target_role)
            staff_user.role = target_role.name

        db.session.commit()

        # Audit and notify
        log_audit_action(
            actor_id=current_user.id,
            entity_type='staff_approval',
            entity_id=approval.id,
            action='approved',
            old_status=old_status,
            new_status='approved',
            notes=f"Approved staff {staff_user.name} for role {approval.requested_role_name} by {current_user.name}"
        )
        create_notification(
            user_id=staff_user.id,
            title="Staff Account Approved",
            message=f"Congratulations! Your {approval.requested_role_name.replace('_', ' ').title()} staff account has been approved by administration.",
            category='approval',
            link=url_for('auth.login')
        )
        flash(f"Staff member {staff_user.name} has been APPROVED as {approval.requested_role_name.replace('_', ' ').title()}.", "success")

    elif action == 'reject':
        if not notes:
            flash("Rejection reason is required.", "danger")
            return redirect(url_for('super_admin.staff_approvals'))

        approval.status = 'rejected'
        approval.reviewed_by = current_user.id
        approval.reviewed_at = datetime.utcnow()
        approval.review_notes = notes

        staff_user.status = 'rejected'
        staff_user.is_active = False
        db.session.commit()

        log_audit_action(
            actor_id=current_user.id,
            entity_type='staff_approval',
            entity_id=approval.id,
            action='rejected',
            old_status=old_status,
            new_status='rejected',
            notes=f"Rejected staff {staff_user.name}. Reason: {notes}"
        )
        create_notification(
            user_id=staff_user.id,
            title="Staff Registration Rejected",
            message=f"Your staff registration was rejected. Reason: {notes}",
            category='approval'
        )
        flash(f"Staff member {staff_user.name} application has been REJECTED.", "warning")

    elif action == 'corrections':
        if not notes:
            flash("Correction instructions are required.", "danger")
            return redirect(url_for('super_admin.staff_approvals'))

        approval.status = 'corrections_requested'
        approval.reviewed_by = current_user.id
        approval.reviewed_at = datetime.utcnow()
        approval.review_notes = notes
        db.session.commit()

        log_audit_action(
            actor_id=current_user.id,
            entity_type='staff_approval',
            entity_id=approval.id,
            action='corrections_requested',
            old_status=old_status,
            new_status='corrections_requested',
            notes=f"Requested corrections from {staff_user.name}: {notes}"
        )
        create_notification(
            user_id=staff_user.id,
            title="Profile Correction Requested",
            message=f"Administration requested profile corrections: {notes}",
            category='approval',
            link=url_for('auth.pending_approval')
        )
        flash(f"Corrections requested from {staff_user.name}.", "info")

    return redirect(url_for('super_admin.staff_approvals'))


@super_admin_bp.route('/users')
@login_required
@role_required('super_admin', 'admin')
def user_management():
    role_filter = request.args.get('role', 'all')
    status_filter = request.args.get('status', 'all')
    search_q = request.args.get('q', '').strip()

    query = User.query

    if role_filter != 'all':
        query = query.filter((User.role == role_filter) | (User.roles.any(Role.name == role_filter)))

    if status_filter != 'all':
        query = query.filter(User.status == status_filter)

    if search_q:
        query = query.filter(
            (User.name.ilike(f'%{search_q}%')) |
            (User.email.ilike(f'%{search_q}%')) |
            (User.phone.ilike(f'%{search_q}%')) |
            (User.roll_number.ilike(f'%{search_q}%'))
        )

    users = query.order_by(User.created_at.desc()).all()
    roles = Role.query.all()

    return render_template(
        'super_admin/users.html',
        users=users,
        roles=roles,
        current_role=role_filter,
        current_status=status_filter,
        search_query=search_q
    )


@super_admin_bp.route('/users/<int:id>/toggle-status', methods=['POST'])
@login_required
@role_required('super_admin', 'admin')
def toggle_user_status(id):
    if id == current_user.id:
        flash("You cannot deactivate your own administrative account.", "danger")
        return redirect(url_for('super_admin.user_management'))

    user = User.query.get_or_404(id)
    old_status = user.status
    if user.status == 'active':
        user.status = 'deactivated'
        user.is_active = False
        new_status = 'deactivated'
    else:
        user.status = 'active'
        user.is_active = True
        new_status = 'active'

    db.session.commit()
    log_audit_action(
        actor_id=current_user.id,
        entity_type='user',
        entity_id=user.id,
        action='activation_toggle',
        old_status=old_status,
        new_status=new_status,
        notes=f"User {user.name} ({user.email}) status changed to {new_status} by {current_user.name}"
    )

    flash(f"Account for {user.name} updated to {new_status.upper()}.", "success")
    return redirect(url_for('super_admin.user_management'))


@super_admin_bp.route('/users/<int:id>/change-role', methods=['POST'])
@login_required
@role_required('super_admin', 'admin')
def change_user_role(id):
    user = User.query.get_or_404(id)
    new_role_name = request.form.get('role_name', '').strip()

    target_role = Role.query.filter_by(name=new_role_name).first()
    if not target_role:
        flash("Invalid role selected.", "danger")
        return redirect(url_for('super_admin.user_management'))

    old_role = user.primary_role
    user.role = target_role.name
    user.roles = [target_role]
    db.session.commit()

    log_audit_action(
        actor_id=current_user.id,
        entity_type='user',
        entity_id=user.id,
        action='role_change',
        old_status=old_role,
        new_status=target_role.name,
        notes=f"User {user.name} role changed from {old_role} to {target_role.name} by {current_user.name}"
    )

    flash(f"User {user.name} role updated to {target_role.display_name}.", "success")
    return redirect(url_for('super_admin.user_management'))


@super_admin_bp.route('/users/create-staff', methods=['POST'])
@login_required
@role_required('super_admin')
def create_staff_account():
    import re
    name = request.form.get('name', '').strip()
    email = request.form.get('email', '').strip().lower()
    phone = request.form.get('phone', '').strip()
    role_name = request.form.get('role_name', '').strip()
    temporary_password = request.form.get('temporary_password', '')
    employee_id = request.form.get('employee_id', '').strip().upper()
    department = request.form.get('department', '').strip()
    assigned_hostel = request.form.get('assigned_hostel', '').strip()
    specialization = request.form.get('specialization', '').strip()

    valid_staff_roles = ['faculty', 'warden', 'mess_manager', 'maintenance', 'office_staff', 'super_admin']
    if role_name not in valid_staff_roles:
        flash("Invalid staff role selected.", "danger")
        return redirect(url_for('super_admin.user_management'))

    if not name or not email or not phone or not temporary_password or not employee_id:
        flash("Full name, email, phone, employee ID, and temporary password are required.", "danger")
        return redirect(url_for('super_admin.user_management'))

    if len(temporary_password) < 8 or not re.search(r'[A-Za-z]', temporary_password) or not re.search(r'\d', temporary_password):
        flash("Temporary password must be at least 8 characters long and contain both letters and numbers.", "danger")
        return redirect(url_for('super_admin.user_management'))

    clean_phone = re.sub(r'[\s\-\+]', '', phone)
    if clean_phone.startswith('91') and len(clean_phone) == 12:
        clean_phone = clean_phone[2:]
    if not re.match(r'^[6-9]\d{9}$', clean_phone):
        flash("Please enter a valid 10-digit Indian mobile number starting with 6-9.", "danger")
        return redirect(url_for('super_admin.user_management'))

    # Uniqueness check
    if User.query.filter(User.email.ilike(email)).first():
        flash("An account with this email address already exists.", "warning")
        return redirect(url_for('super_admin.user_management'))

    if User.query.filter((User.phone == phone) | (User.phone.like(f"%{clean_phone}%"))).first():
        flash("An account with this phone number already exists.", "warning")
        return redirect(url_for('super_admin.user_management'))

    if StaffProfile.query.filter_by(employee_id=employee_id).first():
        flash("An account with this Employee ID already exists.", "warning")
        return redirect(url_for('super_admin.user_management'))

    # Create staff user with forced password change on first login
    new_user = User(
        name=name,
        email=email,
        phone=phone,
        role=role_name,
        status='active',
        is_active=True,
        email_verified=True,
        phone_verified=True,
        hostel=assigned_hostel if role_name == 'warden' else None,
        must_change_password=True
    )
    new_user.set_password(temporary_password)

    role_obj = Role.query.filter_by(name=role_name).first()
    if role_obj:
        new_user.roles.append(role_obj)

    db.session.add(new_user)
    db.session.flush()

    staff_prof = StaffProfile(
        user_id=new_user.id,
        employee_id=employee_id,
        department=department or role_name.replace('_', ' ').title(),
        designation=role_name.replace('_', ' ').title(),
        requested_role=role_name,
        assigned_hostel=assigned_hostel if role_name == 'warden' else None,
        specialization=specialization if role_name == 'maintenance' else None
    )
    db.session.add(staff_prof)
    db.session.commit()

    log_audit_action(
        actor_id=current_user.id,
        entity_type='user',
        entity_id=new_user.id,
        action='staff_created',
        notes=f"Super Admin created staff {name} ({role_name}) with forced password change on first login"
    )

    flash(f"Staff account for {name} ({role_name}) created successfully with forced password change on first login.", "success")
    return redirect(url_for('super_admin.user_management'))


@super_admin_bp.route('/roles')
@super_admin_bp.route('/roles-permissions')
@login_required
@role_required('super_admin', 'admin')
def roles_permissions():
    roles = Role.query.order_by(Role.id.asc()).all()
    permissions = Permission.query.order_by(Permission.module.asc(), Permission.code.asc()).all()
    
    # Group permissions by module
    grouped_perms = {}
    for p in permissions:
        grouped_perms.setdefault(p.module.title(), []).append(p)

    return render_template(
        'super_admin/roles_permissions.html',
        roles=roles,
        grouped_permissions=grouped_perms
    )


@super_admin_bp.route('/roles-permissions/toggle', methods=['POST'])
@login_required
@role_required('super_admin', 'admin')
def toggle_role_permission():
    role_id = request.form.get('role_id', type=int)
    perm_id = request.form.get('permission_id', type=int)

    role = Role.query.get_or_404(role_id)
    perm = Permission.query.get_or_404(perm_id)

    if perm in role.permissions:
        role.permissions.remove(perm)
        action = 'revoked'
    else:
        role.permissions.append(perm)
        action = 'granted'

    db.session.commit()
    log_audit_action(
        actor_id=current_user.id,
        entity_type='role_permission',
        entity_id=role.id,
        action='permission_toggled',
        notes=f"Permission '{perm.code}' {action} for role '{role.name}'"
    )

    return jsonify({'success': True, 'action': action, 'role': role.name, 'permission': perm.code})


@super_admin_bp.route('/audit-logs')
@login_required
@role_required('super_admin', 'admin')
def audit_logs():
    entity_filter = request.args.get('entity', 'all')
    action_filter = request.args.get('action', 'all')
    search_q = request.args.get('q', '').strip()

    query = AuditLog.query

    if entity_filter != 'all':
        query = query.filter_by(entity_type=entity_filter)
    if action_filter != 'all':
        query = query.filter_by(action=action_filter)
    if search_q:
        query = query.filter(AuditLog.notes.ilike(f'%{search_q}%'))

    logs = query.order_by(AuditLog.created_at.desc()).limit(150).all()

    return render_template(
        'super_admin/audit_logs.html',
        logs=logs,
        current_entity=entity_filter,
        current_action=action_filter,
        search_query=search_q
    )


@super_admin_bp.route('/employee-codes', methods=['GET', 'POST'])
@login_required
@role_required('super_admin', 'admin')
def employee_codes():
    from app.models import PreApprovedEmployeeCode
    if request.method == 'POST':
        code = request.form.get('code', '').strip().upper()
        role = request.form.get('role', '').strip().lower()
        name = request.form.get('name', '').strip()
        department = request.form.get('department', '').strip()

        ALLOWED_STAFF_ROLES = ['admin', 'super_admin', 'faculty', 'warden', 'mess_manager', 'maintenance', 'office_staff']
        if not code or not role:
            flash("Employee Code and Role are required.", "danger")
            return redirect(url_for('super_admin.employee_codes'))

        if role not in ALLOWED_STAFF_ROLES:
            flash(f"Invalid role '{role}'.", "danger")
            return redirect(url_for('super_admin.employee_codes'))

        if PreApprovedEmployeeCode.query.filter_by(employee_code=code).first():
            flash(f"Employee code '{code}' already exists.", "warning")
            return redirect(url_for('super_admin.employee_codes'))

        new_code = PreApprovedEmployeeCode(
            employee_code=code,
            role=role,
            name=name or None,
            department=department or None,
            status='unused'
        )
        db.session.add(new_code)
        db.session.commit()
        log_audit_action(current_user.id, 'employee_code', new_code.id, 'code_issued', notes=f"Pre-approved employee code '{code}' issued for role '{role}'")
        flash(f"Pre-approved Employee Code '{code}' created successfully.", "success")
        return redirect(url_for('super_admin.employee_codes'))

    codes = PreApprovedEmployeeCode.query.order_by(PreApprovedEmployeeCode.created_at.desc()).all()
    return render_template('super_admin/employee_codes.html', codes=codes)


@super_admin_bp.route('/employee-codes/<int:code_id>/delete', methods=['POST'])
@login_required
@role_required('super_admin', 'admin')
def delete_employee_code(code_id):
    from app.models import PreApprovedEmployeeCode
    code_obj = PreApprovedEmployeeCode.query.get_or_404(code_id)
    if code_obj.status == 'used':
        flash("Cannot revoke an employee code that has already been redeemed.", "danger")
        return redirect(url_for('super_admin.employee_codes'))

    code_val = code_obj.employee_code
    db.session.delete(code_obj)
    db.session.commit()
    log_audit_action(current_user.id, 'employee_code', code_id, 'code_revoked', notes=f"Pre-approved employee code '{code_val}' revoked")
    flash(f"Employee Code '{code_val}' has been revoked.", "info")
    return redirect(url_for('super_admin.employee_codes'))
