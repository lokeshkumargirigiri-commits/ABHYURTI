from flask import Blueprint

super_admin_bp = Blueprint('super_admin', __name__, url_prefix='/super-admin')

from app.super_admin import routes
