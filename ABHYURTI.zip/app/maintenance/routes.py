from datetime import datetime
from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app.extensions import db
from app.models import MaintenanceTicket, Complaint, User
from app.utils.security import role_required, verify_record_access, log_audit_action, create_notification
from app.maintenance import maintenance_bp

@maintenance_bp.route('/')
@maintenance_bp.route('/dashboard')
@login_required
@role_required('maintenance', 'super_admin', 'admin')
def dashboard():
    status_filter = request.args.get('status', 'all')
    
    # Strictly record-level access control: only tickets assigned to this staff member
    query = MaintenanceTicket.query
    if not (current_user.is_super_admin or current_user.role == 'admin'):
        query = query.filter_by(assigned_staff_id=current_user.id)

    if status_filter != 'all':
        query = query.filter_by(status=status_filter)

    tickets = query.order_by(MaintenanceTicket.created_at.desc()).all()

    # Metrics
    assigned_count = MaintenanceTicket.query.filter_by(assigned_staff_id=current_user.id, status='assigned').count()
    in_progress_count = MaintenanceTicket.query.filter_by(assigned_staff_id=current_user.id, status='in_progress').count()
    resolved_count = MaintenanceTicket.query.filter_by(assigned_staff_id=current_user.id, status='resolved').count()

    return render_template(
        'maintenance/dashboard.html',
        tickets=tickets,
        assigned_count=assigned_count,
        in_progress_count=in_progress_count,
        resolved_count=resolved_count,
        current_status=status_filter
    )


@maintenance_bp.route('/tickets/<int:id>', methods=['GET', 'POST'])
@login_required
@role_required('maintenance', 'super_admin', 'admin')
def ticket_detail(id):
    ticket = MaintenanceTicket.query.get_or_404(id)

    # Record-level authorization check: Prevent accessing another staff member's ticket!
    if not verify_record_access(ticket, assigned_attr='assigned_staff_id'):
        flash("Unauthorized: You are not assigned to this maintenance work order.", "danger")
        return abort(403)

    complaint = ticket.complaint

    if request.method == 'POST':
        new_status = request.form.get('status', ticket.status)
        materials = request.form.get('materials_used', '').strip()
        notes = request.form.get('resolution_notes', '').strip()

        old_status = ticket.status
        ticket.status = new_status
        if materials:
            ticket.materials_used = materials
        if notes:
            ticket.resolution_notes = notes

        # Update parent complaint status in sync
        if new_status == 'resolved':
            ticket.resolved_at = datetime.utcnow()
            complaint.status = 'resolved'
            complaint.resolved_at = datetime.utcnow()
            complaint.resolution_notes = f"Fixed by {current_user.name}. Materials: {materials or 'None'}. Notes: {notes or 'Resolved'}"
            
            # Notify the student
            create_notification(
                user_id=complaint.student_id,
                title=f"Complaint #{complaint.id} Resolved",
                message=f"Maintenance staff {current_user.name} resolved your {complaint.category.replace('cat_', '')} issue in Room {complaint.room}.",
                category='complaint',
                link=url_for('student.complaint_detail', id=complaint.id)
            )
        elif new_status == 'in_progress':
            complaint.status = 'in_progress'

        ticket.updated_at = datetime.utcnow()
        db.session.commit()

        log_audit_action(
            actor_id=current_user.id,
            entity_type='maintenance_ticket',
            entity_id=ticket.id,
            action='status_update',
            old_status=old_status,
            new_status=new_status,
            notes=f"Updated by maintenance staff {current_user.name}. Materials: {materials}"
        )

        flash(f"Work order #{ticket.id} status updated to {new_status.replace('_', ' ').title()}.", "success")
        return redirect(url_for('maintenance.ticket_detail', id=ticket.id))

    return render_template('maintenance/ticket_detail.html', ticket=ticket, complaint=complaint)
