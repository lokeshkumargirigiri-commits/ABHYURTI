from datetime import datetime, timedelta
from flask import render_template, request, redirect, url_for, flash, abort, jsonify
from flask_login import login_required, current_user
from app.library import library_bp
from app.extensions import db
from app.models import LibraryBook, LibraryBookRequest, User
from app.utils.security import role_required, log_audit_action, create_notification


def seed_library_books():
    """Ensure baseline library catalog exists."""
    if LibraryBook.query.count() == 0:
        samples = [
            ('978-0262033848', 'Introduction to Algorithms (CLRS)', 'Cormen, Leiserson, Rivest, Stein', 'Computer Science', 6, 5, 'CS-Rack-01A'),
            ('978-1118063330', 'Operating System Concepts (Dinosaur)', 'Silberschatz, Galvin, Gagne', 'Computer Science', 5, 4, 'CS-Rack-02B'),
            ('978-0132126953', 'Computer Networks (5th Edition)', 'Andrew S. Tanenbaum', 'Computer Science', 4, 3, 'CS-Rack-02C'),
            ('978-0138147570', 'Signals and Systems (2nd Edition)', 'Alan V. Oppenheim', 'Electronics', 5, 5, 'EC-Rack-01A'),
            ('978-9352606429', 'Engineering Thermodynamics', 'P. K. Nag', 'Mechanical', 4, 4, 'ME-Rack-01B'),
            ('978-0132350884', 'Clean Code: Handbook of Agile Craft', 'Robert C. Martin', 'General Engineering', 3, 2, 'GEN-Rack-03A')
        ]
        for isbn, title, author, cat, tot, avail, loc in samples:
            db.session.add(LibraryBook(isbn=isbn, title=title, author=author, category=cat, total_copies=tot, available_copies=avail, shelf_location=loc))
        db.session.commit()


def calculate_overdue_fines():
    """Calculate and update late return fines (₹5/day)."""
    now = datetime.utcnow()
    issued_requests = LibraryBookRequest.query.filter_by(status='issued').all()
    for req in issued_requests:
        if req.due_date and now > req.due_date:
            days_overdue = (now - req.due_date).days
            req.fine_amount = max(0.0, float(days_overdue * 5.0))
    db.session.commit()


@library_bp.route('/')
@library_bp.route('/dashboard')
@login_required
@role_required('librarian', 'admin', 'super_admin')
def dashboard():
    seed_library_books()
    calculate_overdue_fines()

    selected_tab = request.args.get('tab', 'student').strip().lower()

    # Separate queues for students vs teachers
    student_queue = LibraryBookRequest.query.filter_by(
        user_type='student'
    ).order_by(LibraryBookRequest.created_at.desc()).all()

    teacher_queue = LibraryBookRequest.query.filter_by(
        user_type='teacher'
    ).order_by(LibraryBookRequest.created_at.desc()).all()

    books = LibraryBook.query.order_by(LibraryBook.title.asc()).all()

    pending_student_count = sum(1 for r in student_queue if r.status == 'requested')
    pending_teacher_count = sum(1 for r in teacher_queue if r.status == 'requested')

    return render_template('library/dashboard.html',
                           student_queue=student_queue,
                           teacher_queue=teacher_queue,
                           books=books,
                           selected_tab=selected_tab,
                           pending_student_count=pending_student_count,
                           pending_teacher_count=pending_teacher_count)


@library_bp.route('/request/<int:id>/issue', methods=['POST'])
@login_required
@role_required('librarian', 'admin', 'super_admin')
def issue_book(id):
    req = LibraryBookRequest.query.get_or_404(id)
    if req.status != 'requested':
        flash("Request is already processed.", "warning")
        return redirect(url_for('library.dashboard', tab=req.user_type))

    book = req.book
    if book.available_copies <= 0:
        flash(f"Cannot issue: '{book.title}' currently has 0 copies available in rack.", "danger")
        return redirect(url_for('library.dashboard', tab=req.user_type))

    # Issue book
    now = datetime.utcnow()
    req.status = 'issued'
    req.issue_date = now
    # 90 days for faculty, 14 days for students
    days = 90 if req.user_type == 'teacher' else 14
    req.due_date = now + timedelta(days=days)

    book.available_copies = max(0, book.available_copies - 1)
    db.session.commit()

    log_audit_action(current_user.id, 'library_book_request', req.id, 'issued',
                     notes=f"Issued {book.title} to {req.user.name} ({req.user_type}) for {days} days")

    create_notification(
        req.user_id,
        "Book Issued by Library",
        f"'{book.title}' has been issued to you! Please collect from {book.shelf_location or 'Main Desk'}. Due Date: {req.due_date.strftime('%d %b %Y')}.",
        link=url_for('library.catalog')
    )

    flash(f"Book issued to {req.user.name}. Due date set to {req.due_date.strftime('%d %b %Y')}.", "success")
    return redirect(url_for('library.dashboard', tab=req.user_type))


@library_bp.route('/request/<int:id>/return', methods=['POST'])
@login_required
@role_required('librarian', 'admin', 'super_admin')
def return_book(id):
    req = LibraryBookRequest.query.get_or_404(id)
    now = datetime.utcnow()

    # Calculate fine
    if req.due_date and now > req.due_date:
        days = (now - req.due_date).days
        req.fine_amount = max(0.0, float(days * 5.0))

    req.status = 'returned'
    req.return_date = now
    req.book.available_copies = min(req.book.total_copies, req.book.available_copies + 1)
    db.session.commit()

    log_audit_action(current_user.id, 'library_book_request', req.id, 'returned',
                     notes=f"Returned {req.book.title} (Fine: Rs {req.fine_amount:.2f})")

    fine_msg = f" Overdue Fine: ₹{req.fine_amount:,.2f}" if req.fine_amount > 0 else " Returned on time with zero fines."
    create_notification(
        req.user_id,
        "Book Returned Confirmed",
        f"Return of '{req.book.title}' has been logged.{fine_msg}",
        link=url_for('library.catalog')
    )

    flash(f"Book return confirmed.{fine_msg}", "success")
    return redirect(url_for('library.dashboard', tab=req.user_type))


@library_bp.route('/request/<int:id>/reject', methods=['POST'])
@login_required
@role_required('librarian', 'admin', 'super_admin')
def reject_request(id):
    req = LibraryBookRequest.query.get_or_404(id)
    req.status = 'rejected'
    db.session.commit()

    create_notification(
        req.user_id,
        "Library Request Declined",
        f"Your request for '{req.book.title}' could not be processed at this time.",
        link=url_for('library.catalog')
    )
    flash("Request marked as rejected.", "info")
    return redirect(url_for('library.dashboard', tab=req.user_type))


@library_bp.route('/book/add', methods=['POST'])
@login_required
@role_required('librarian', 'admin', 'super_admin')
def add_book():
    title = request.form.get('title', '').strip()
    author = request.form.get('author', '').strip()
    isbn = request.form.get('isbn', '').strip()
    category = request.form.get('category', 'General').strip()
    copies = int(request.form.get('total_copies', 5) or 5)
    location = request.form.get('shelf_location', '').strip()

    if not title or not author:
        flash("Title and author are required.", "danger")
        return redirect(url_for('library.dashboard', tab='catalog'))

    book = LibraryBook(
        title=title,
        author=author,
        isbn=isbn if isbn else None,
        category=category,
        total_copies=copies,
        available_copies=copies,
        shelf_location=location if location else 'Main Reading Hall'
    )
    db.session.add(book)
    db.session.commit()

    flash(f"New book '{title}' registered to library catalog.", "success")
    return redirect(url_for('library.dashboard', tab='catalog'))


# ============================================================================
# STUDENT & FACULTY BORROWING PORTAL
# ============================================================================

@library_bp.route('/catalog')
@login_required
def catalog():
    seed_library_books()
    calculate_overdue_fines()

    search_q = request.args.get('q', '').strip()
    query = LibraryBook.query
    if search_q:
        query = query.filter(
            (LibraryBook.title.ilike(f"%{search_q}%")) |
            (LibraryBook.author.ilike(f"%{search_q}%")) |
            (LibraryBook.category.ilike(f"%{search_q}%")) |
            (LibraryBook.isbn.ilike(f"%{search_q}%"))
        )
    books = query.order_by(LibraryBook.title.asc()).all()

    my_requests = LibraryBookRequest.query.filter_by(
        user_id=current_user.id
    ).order_by(LibraryBookRequest.created_at.desc()).all()

    return render_template('library/catalog.html',
                           books=books,
                           search_q=search_q,
                           my_requests=my_requests)


@library_bp.route('/book/<int:id>/request', methods=['POST'])
@library_bp.route('/reserve/<int:id>', methods=['POST'])
@login_required
def request_book(id):
    book = LibraryBook.query.get_or_404(id)
    if book.available_copies <= 0:
        flash("This book is currently out of copies in rack. Please check back soon.", "warning")
        return redirect(url_for('library.catalog'))

    # Check if already requested or actively issued
    existing = LibraryBookRequest.query.filter_by(
        book_id=book.id,
        user_id=current_user.id
    ).filter(LibraryBookRequest.status.in_(['requested', 'issued'])).first()

    if existing:
        flash(f"You already have an active request or borrowing for '{book.title}'.", "info")
        return redirect(url_for('library.catalog'))

    user_type = 'teacher' if current_user.has_role('faculty', 'hod') else 'student'

    req = LibraryBookRequest(
        book_id=book.id,
        user_id=current_user.id,
        user_type=user_type,
        status='requested'
    )
    db.session.add(req)
    db.session.commit()

    flash(f"Book request for '{book.title}' placed in the {user_type.title()} Queue! Librarian will review and confirm.", "success")
    return redirect(url_for('library.catalog'))
