from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app.extensions import db
from app.models import Notification
from app.notifications import notifications_bp

@notifications_bp.route('/')
@login_required
def index():
    category = request.args.get('category', 'all')
    query = Notification.query.filter_by(user_id=current_user.id)
    if category != 'all':
        query = query.filter_by(category=category)

    notifs = query.order_by(Notification.created_at.desc()).limit(50).all()
    unread_count = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()

    return render_template('notifications/index.html', notifications=notifs, unread_count=unread_count, current_category=category)


@notifications_bp.route('/<int:id>/read', methods=['POST'])
@login_required
def mark_read(id):
    notif = Notification.query.filter_by(id=id, user_id=current_user.id).first_or_404()
    notif.is_read = True
    db.session.commit()
    if request.is_json:
        return jsonify({'success': True})
    return redirect(notif.link or url_for('notifications.index'))


@notifications_bp.route('/mark-all-read', methods=['POST'])
@login_required
def mark_all_read():
    Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
    db.session.commit()
    flash("All notifications marked as read.", "success")
    return redirect(url_for('notifications.index'))
