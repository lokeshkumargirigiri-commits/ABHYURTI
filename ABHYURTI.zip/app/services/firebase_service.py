import requests
from flask import current_app
from app.services.settings_service import get_setting

def get_firebase_client_config():
    """Returns frontend Firebase configuration dictionary."""
    return {
        "apiKey": get_setting('FIREBASE_API_KEY', ''),
        "authDomain": get_setting('FIREBASE_AUTH_DOMAIN', 'fretbox-campus.firebaseapp.com'),
        "projectId": get_setting('FIREBASE_PROJECT_ID', 'fretbox-campus'),
        "storageBucket": get_setting('FIREBASE_STORAGE_BUCKET', 'fretbox-campus.appspot.com'),
        "messagingSenderId": get_setting('FIREBASE_MESSAGING_SENDER_ID', '1234567890'),
        "appId": get_setting('FIREBASE_APP_ID', '1:1234567890:web:abcdef'),
        "vapidKey": get_setting('FCM_VAPID_KEY', '')
    }

def test_firebase_connection(api_key=None, project_id=None):
    """
    Tests Firebase Web API key with Google Identity Toolkit endpoint.
    """
    k = api_key or get_setting('FIREBASE_API_KEY')
    p = project_id or get_setting('FIREBASE_PROJECT_ID')

    if not k:
        return {"success": False, "message": "Missing Firebase Web API Key."}

    try:
        url = f"https://identitytoolkit.googleapis.com/v1/accounts:createAuthUri?key={k}"
        resp = requests.post(url, json={"continueUri": "http://localhost"}, timeout=8)
        # Even if continueUri is rejected, 200 or 400 with specific payload verifies key validity
        if resp.status_code in (200, 400):
            data = resp.json()
            err = data.get('error', {})
            if err.get('message') == 'API_KEY_INVALID':
                return {"success": False, "message": "Google Firebase rejected this API Key (Invalid Key)."}
            return {"success": True, "message": f"Firebase project credentials verified successfully (Project: {p or 'Detected'})!"}
        return {"success": False, "message": f"Firebase response {resp.status_code}: {resp.text}"}
    except Exception as e:
        return {"success": False, "message": f"Connection error: {str(e)}"}
