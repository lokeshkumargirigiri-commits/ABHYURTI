import requests
from flask import current_app
from app.services.settings_service import get_setting

# Campus Geographic Data (Coordinates centered on typical university campus)
CAMPUS_CENTER = {
    "lat": 20.2961,
    "lng": 85.8245,
    "name": "ABHYURTI Central Campus Green",
    "zoom": 17
}

CAMPUS_FACILITIES = [
    {
        "id": "hostel_a",
        "name": "Hostel Block A (Boys)",
        "category": "hostels",
        "lat": 20.2975,
        "lng": 85.8230,
        "warden": "Dr. Sharma (+91-9876543211)",
        "capacity": "250 Residents (Rooms 101–420)",
        "curfew": "10:00 PM (10:30 PM Weekends)",
        "status": "Active • RFID/QR Room Inspection Active",
        "description": "Four-story residential hall with solar geysers and high-speed Wi-Fi.",
        "icon": "bi-buildings-fill",
        "color": "#FF6A45"
    },
    {
        "id": "hostel_b",
        "name": "Hostel Block B (Boys)",
        "category": "hostels",
        "lat": 20.2982,
        "lng": 85.8252,
        "warden": "Prof. Roy (+91-9876543212)",
        "capacity": "300 Residents (Rooms 101–450)",
        "curfew": "10:00 PM (10:30 PM Weekends)",
        "status": "Active",
        "description": "Senior undergraduate hostel block with indoor badminton court.",
        "icon": "bi-buildings",
        "color": "#FF6A45"
    },
    {
        "id": "hostel_c",
        "name": "Hostel Block C (Girls)",
        "category": "hostels",
        "lat": 20.2950,
        "lng": 85.8265,
        "warden": "Dr. Gupta (+91-9876543213)",
        "capacity": "280 Residents (Rooms 101–400)",
        "curfew": "09:30 PM",
        "status": "Active • Biometric Check-in Active",
        "description": "Secure residential complex with dedicated reading lounge and 24/7 guard booth.",
        "icon": "bi-shield-check",
        "color": "#E11D48"
    },
    {
        "id": "dining_hall",
        "name": "Central Dining Hall & Mess 1",
        "category": "dining",
        "lat": 20.2968,
        "lng": 85.8240,
        "warden": "Mess Supervisor Rajesh (+91-9876543220)",
        "capacity": "Seating for 800 students",
        "curfew": "Breakfast: 7:30-9:30 AM | Lunch: 12:30-2:30 PM | Dinner: 7:30-9:30 PM",
        "status": "Open",
        "description": "Main campus dining facility serving balanced, nutritious vegetarian and non-vegetarian meals.",
        "icon": "bi-cup-hot-fill",
        "color": "#10B981"
    },
    {
        "id": "night_canteen",
        "name": "Student Center Night Canteen",
        "category": "dining",
        "lat": 20.2960,
        "lng": 85.8232,
        "warden": "Student Affairs Council",
        "capacity": "150 Seats",
        "curfew": "Open 5:00 PM – 2:00 AM",
        "status": "Open Daily",
        "description": "Late-night snack point, tea stall, and cooperative grocery outlet.",
        "icon": "bi-egg-fried",
        "color": "#059669"
    },
    {
        "id": "health_center",
        "name": "Campus Hospital & Health Center",
        "category": "emergency",
        "lat": 20.2948,
        "lng": 85.8225,
        "warden": "Dr. Sen, Resident Medical Officer (Ext 108 / +91-9876500108)",
        "capacity": "10-Bed Triage, 24/7 Dispensary",
        "curfew": "24/7 Emergency Care",
        "status": "24/7 Emergency Active",
        "description": "Immediate first aid, doctor consultation, prescription validation, and ambulance dispatch.",
        "icon": "bi-heart-pulse-fill",
        "color": "#DC2626"
    },
    {
        "id": "main_gate",
        "name": "Main Campus Gate 1 & Security Kiosk",
        "category": "security",
        "lat": 20.2940,
        "lng": 85.8242,
        "warden": "Chief Security Officer (Ext 101)",
        "capacity": "Multi-lane Entry, Automated Boom Barrier",
        "curfew": "24/7 Guarded Exit Point",
        "status": "ABHYURTI Touch Kiosk Operational",
        "description": "Primary vehicle and pedestrian checkpoint. Houses Self-Service Gate Pass Terminal.",
        "icon": "bi-shield-shaded",
        "color": "#2563EB"
    },
    {
        "id": "admin_block",
        "name": "Administrative Tower & Registrar Office",
        "category": "academic",
        "lat": 20.2955,
        "lng": 85.8235,
        "warden": "Dean of Student Affairs (Ext 201)",
        "capacity": "Administrative Directorate",
        "curfew": "9:00 AM – 5:30 PM (Mon-Sat)",
        "status": "Official Staff Office",
        "description": "Registrar, student bonafide certificate verification, fees desk, and warden council chambers.",
        "icon": "bi-bank2",
        "color": "#7C3AED"
    },
    {
        "id": "library",
        "name": "Central Knowledge Hub & Computing Center",
        "category": "academic",
        "lat": 20.2962,
        "lng": 85.8255,
        "warden": "Chief Librarian (Ext 305)",
        "capacity": "1,200 Seats, 150,000 Volumes",
        "curfew": "8:00 AM – 11:00 PM (Exam periods 24/7)",
        "status": "High-Speed Study Zone",
        "description": "Silent reading rooms, digital reference terminals, and thesis archives.",
        "icon": "bi-book-half",
        "color": "#6366F1"
    },
    {
        "id": "maintenance_shed",
        "name": "Estate Maintenance Shed & Workshop",
        "category": "facilities",
        "lat": 20.2985,
        "lng": 85.8220,
        "warden": "Estate Supervisor Ramesh (+91-9876543230)",
        "capacity": "Central Dispatch for Electricians & Plumbers",
        "curfew": "8:00 AM – 8:00 PM (Emergency on-call 24/7)",
        "status": "Tickets Dispatch Active",
        "description": "Repair headquarters for campus infrastructure, sanitary supplies, and carpentry.",
        "icon": "bi-tools",
        "color": "#D97706"
    },
    {
        "id": "sports_complex",
        "name": "Campus Sports Complex & Gymnasium",
        "category": "facilities",
        "lat": 20.2970,
        "lng": 85.8270,
        "warden": "Sports Director (Ext 402)",
        "capacity": "Indoor Courts, Olympic Track, Gym",
        "curfew": "6:00 AM – 9:00 PM",
        "status": "Open for Students",
        "description": "Multi-sport arena, athletics track, basketball court, and weight training center.",
        "icon": "bi-trophy-fill",
        "color": "#0284C7"
    }
]

def get_campus_map_data():
    """
    Returns full campus map configuration, including Google Maps API Key (if set)
    and all POIs with metadata.
    """
    gmaps_key = get_setting('GOOGLE_MAPS_API_KEY')
    return {
        "google_maps_api_key": gmaps_key or "",
        "has_google_maps": bool(gmaps_key and gmaps_key.strip()),
        "center": CAMPUS_CENTER,
        "facilities": CAMPUS_FACILITIES,
        "categories": [
            {"id": "all", "name": "All Locations", "icon": "bi-geo-alt"},
            {"id": "hostels", "name": "Hostels & Quarters", "icon": "bi-buildings"},
            {"id": "dining", "name": "Mess & Dining", "icon": "bi-cup-hot"},
            {"id": "emergency", "name": "Health & Emergency", "icon": "bi-heart-pulse"},
            {"id": "academic", "name": "Academics & Library", "icon": "bi-book"},
            {"id": "security", "name": "Security Gates", "icon": "bi-shield-shaded"},
            {"id": "facilities", "name": "Estate & Sports", "icon": "bi-tools"}
        ]
    }

def test_google_maps_key(api_key):
    """Verifies Google Maps API Key via geocoding check."""
    if not api_key:
        return {"success": False, "message": "No Google Maps API Key provided."}
    try:
        url = f"https://maps.googleapis.com/maps/api/geocode/json?latlng=20.2961,85.8245&key={api_key}"
        resp = requests.get(url, timeout=8)
        data = resp.json()
        if data.get('status') == 'OK':
            return {"success": True, "message": "Google Maps API connection verified successfully!"}
        elif data.get('status') == 'REQUEST_DENIED':
            return {"success": False, "message": f"Google Maps request denied: {data.get('error_message', 'Check key permissions and Geocoding/Maps JS API enablement')}"}
        return {"success": False, "message": f"Status: {data.get('status')} - {data.get('error_message', '')}"}
    except Exception as e:
        return {"success": False, "message": f"Connection error: {str(e)}"}
