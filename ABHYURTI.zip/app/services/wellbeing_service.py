from datetime import datetime, timedelta
from app.extensions import db
from app.models import (
    User, Attendance, Assignment, AssignmentSubmission,
    HostelNightAttendance, StudentWellbeingIndex, CounselorSessionNote
)


def calculate_student_wellbeing_index(student_id):
    """
    Calculate composite Depression/Wellbeing Risk Index (0 - 100):
    Formula:
    Risk Score = 0.35 * (100 - Attendance Rate)
               + 0.25 * (Assignment Miss Rate)
               + 0.20 * (Isolation Score)
               + 0.20 * (Self Distress Score)
    """
    student = User.query.get(student_id)
    if not student or student.role != 'student':
        return None

    index_record = StudentWellbeingIndex.query.filter_by(student_id=student.id).first()
    if not index_record:
        index_record = StudentWellbeingIndex(student_id=student.id)
        db.session.add(index_record)

    # 1. Attendance Rate (0 - 100%)
    total_att = Attendance.query.filter_by(student_id=student.id).count()
    if total_att > 0:
        present_att = Attendance.query.filter_by(student_id=student.id, status='present').count()
        att_rate = (present_att / total_att) * 100.0
    else:
        # Default baseline if zero marked
        att_rate = 85.0
    index_record.attendance_rate = round(att_rate, 1)

    # 2. Assignment Miss Rate (0 - 100%)
    branch = student.branch or 'CSE'
    all_assignments = Assignment.query.filter(
        (Assignment.department == branch) | (Assignment.department.is_(None))
    ).all()
    if all_assignments:
        submitted_count = AssignmentSubmission.query.filter_by(student_id=student.id).count()
        missed = max(0, len(all_assignments) - submitted_count)
        miss_rate = (missed / len(all_assignments)) * 100.0
    else:
        miss_rate = 0.0
    index_record.assignment_miss_rate = round(miss_rate, 1)

    # 3. Isolation Score (0 - 100) based on night absence and curfew irregularities
    night_records = HostelNightAttendance.query.filter_by(student_id=student.id).all()
    if night_records:
        irregular_count = sum(1 for nr in night_records if nr.status in ('absent', 'night_out'))
        isolation_score = min(100.0, (irregular_count / len(night_records)) * 100.0)
    else:
        isolation_score = 15.0
    index_record.isolation_score = round(isolation_score, 1)

    # 4. Self Distress Score (persisted from optional student check-in, default 10.0)
    self_distress = index_record.self_distress_score or 10.0

    # Composite formula
    risk = (
        0.35 * (100.0 - att_rate) +
        0.25 * miss_rate +
        0.20 * isolation_score +
        0.20 * self_distress
    )
    risk = max(0.0, min(100.0, round(risk, 1)))
    index_record.composite_risk_score = risk

    # Categorize risk level
    if risk >= 75.0:
        index_record.risk_level = 'severe'
        index_record.counselor_flagged = True
    elif risk >= 55.0:
        index_record.risk_level = 'high'
    elif risk >= 30.0:
        index_record.risk_level = 'moderate'
    else:
        index_record.risk_level = 'low'

    index_record.last_calculated_at = datetime.utcnow()
    db.session.commit()
    return index_record


def recalculate_all_students_wellbeing():
    """Recalculate wellbeing index across all enrolled students."""
    students = User.query.filter_by(role='student').all()
    records = []
    for s in students:
        rec = calculate_student_wellbeing_index(s.id)
        if rec:
            records.append(rec)
    return records
