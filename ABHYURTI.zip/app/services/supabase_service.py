import requests
from flask import current_app
from app.services.settings_service import get_setting

def test_supabase_connection(project_url=None, anon_key=None):
    """
    Tests connection to Supabase REST API endpoint.
    """
    url = (project_url or get_setting('SUPABASE_URL') or "").rstrip('/')
    key = anon_key or get_setting('SUPABASE_ANON_KEY') or get_setting('SUPABASE_SERVICE_ROLE_KEY')

    if not url or not key:
        return {"success": False, "message": "Missing Supabase Project URL or Anon Key."}

    try:
        # Check standard Supabase PostgREST root endpoint
        rest_endpoint = f"{url}/rest/v1/"
        headers = {
            "apikey": key,
            "Authorization": f"Bearer {key}"
        }
        resp = requests.get(rest_endpoint, headers=headers, timeout=8)
        if resp.status_code in (200, 404):  # 200 or 404 with Supabase payload indicates valid project reach
            return {"success": True, "message": f"Successfully connected to Supabase project at {url}!"}
        return {"success": False, "message": f"Supabase responded with status {resp.status_code}: {resp.text[:120]}"}
    except Exception as e:
        return {"success": False, "message": f"Connection error: {str(e)}"}


def sync_audit_log_to_supabase(audit_entry):
    """
    Optionally syncs an AuditLog record to Supabase cloud storage/table.
    """
    url = (get_setting('SUPABASE_URL') or "").rstrip('/')
    key = get_setting('SUPABASE_SERVICE_ROLE_KEY') or get_setting('SUPABASE_ANON_KEY')

    if not (url and key):
        return None

    try:
        endpoint = f"{url}/rest/v1/fretbox_audit_logs"
        headers = {
            "apikey": key,
            "Authorization": f"Bearer {key}",
            "Content-Type": "application/json",
            "Prefer": "return=minimal"
        }
        payload = {
            "entity_type": audit_entry.entity_type,
            "entity_id": audit_entry.entity_id,
            "action": audit_entry.action,
            "notes": audit_entry.notes,
            "created_at": audit_entry.created_at.isoformat() if audit_entry.created_at else None
        }
        resp = requests.post(endpoint, json=payload, headers=headers, timeout=5)
        return resp.status_code in (200, 201)
    except Exception as e:
        if current_app:
            current_app.logger.warning(f"Supabase sync warning: {e}")
        return False
