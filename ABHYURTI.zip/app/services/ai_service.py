import json
import time
import requests
from datetime import datetime, timedelta
from flask import current_app
from app.services.settings_service import get_setting
from app.models import Complaint, GatePass, User

CAMPUS_KNOWLEDGE_SYSTEM_PROMPT = """
You are the ABHYURTI Campus AI Copilot, an intelligent, empathetic, and knowledgeable assistant for university hostel residents, wardens, and campus staff.
Campus Guidelines:
- Hostels: Hostel A (Boys Block, Warden Dr. Sharma), Hostel B (Boys Block, Warden Prof. Roy), Hostel C (Girls Block, Warden Dr. Gupta).
- Gate Passes: Normal gate passes require warden approval at least 24h prior. Emergency gate passes have an enforceable 30-minute SLA countdown for medical or critical family emergencies, with automated SMS parent notification. Curfew is 10:00 PM on weekdays and 10:30 PM on weekends.
- Maintenance Complaints: Categories are Plumbing, Electrical, Furniture, WiFi/Network, Cleaning, Pest Control, and Civil. Ageing SLAs: Green (0-3 days), Amber (4-7 days), Red (8+ days - critical escalation).
- Mess timings: Breakfast (7:30 - 9:30 AM), Lunch (12:30 - 2:30 PM), Snacks (5:00 - 6:30 PM), Dinner (7:30 - 9:30 PM).
- Emergency Contacts: Campus Health Center (+91-9876500108 / Ext 108), Main Security Gate (Ext 101), Ambulance (102).
- Tone: Helpful, concise, formatted with clear markdown bullet points and emojis. If asked about student's tickets or passes, refer to their active records.
"""

def chat_with_campus_ai(prompt, user=None, history=None):
    """
    Main AI Chat function. Routes to Gemini, OpenAI, or intelligent local campus engine.
    """
    provider = (get_setting('ACTIVE_AI_PROVIDER') or 'gemini').lower()
    gemini_key = get_setting('GEMINI_API_KEY')
    openai_key = get_setting('OPENAI_API_KEY')

    # Build context from current user state
    user_context = ""
    if user and getattr(user, 'is_authenticated', False):
        user_context = f"\nUser Info: Name: {user.name}, Role: {user.role}, Hostel: {user.hostel or 'Hostel A'}, Room: {user.room or 'N/A'}, Roll No: {user.roll_number or 'N/A'}."
        
        # Check active complaints
        try:
            active_cmps = Complaint.query.filter(
                Complaint.student_id == user.id,
                Complaint.status.notin_(['resolved', 'closed'])
            ).order_by(Complaint.created_at.desc()).limit(3).all()
            if active_cmps:
                user_context += "\nActive Complaints: " + "; ".join([f"#{c.id} ({c.category} in Room {c.room}, status: {c.status})" for c in active_cmps])
            
            # Check latest gate pass
            latest_gp = GatePass.query.filter_by(student_id=user.id).order_by(GatePass.created_at.desc()).first()
            if latest_gp:
                user_context += f"\nLatest Gate Pass: #{latest_gp.id} to {latest_gp.destination} (Status: {latest_gp.status}, Emergency: {latest_gp.is_emergency})."
        except Exception:
            pass

    full_system_prompt = CAMPUS_KNOWLEDGE_SYSTEM_PROMPT + user_context

    # 1. Try Gemini
    if provider == 'gemini' and gemini_key:
        try:
            return _call_gemini(prompt, full_system_prompt, gemini_key)
        except Exception as e:
            if current_app:
                current_app.logger.warning(f"Gemini API call failed, falling back to local: {e}")

    # 2. Try OpenAI
    if provider == 'openai' and openai_key:
        try:
            return _call_openai(prompt, full_system_prompt, openai_key)
        except Exception as e:
            if current_app:
                current_app.logger.warning(f"OpenAI API call failed, falling back to local: {e}")

    # 3. Fallback: If other key is available
    if gemini_key:
        try:
            return _call_gemini(prompt, full_system_prompt, gemini_key)
        except Exception:
            pass
    elif openai_key:
        try:
            return _call_openai(prompt, full_system_prompt, openai_key)
        except Exception:
            pass

    # 4. Built-in Smart Local Campus Engine (Guaranteed zero-failure response)
    return _smart_campus_copilot_fallback(prompt, user)


def _call_gemini(prompt, system_prompt, api_key):
    """Invokes Google Gemini REST API."""
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={api_key}"
    payload = {
        "contents": [
            {
                "parts": [
                    {"text": f"{system_prompt}\n\nStudent Query: {prompt}\n\nAssistant Response:"}
                ]
            }
        ],
        "generationConfig": {
            "temperature": 0.4,
            "maxOutputTokens": 600
        }
    }
    resp = requests.post(url, json=payload, headers={"Content-Type": "application/json"}, timeout=12)
    if resp.status_code == 200:
        data = resp.json()
        candidates = data.get("candidates", [])
        if candidates and "content" in candidates[0]:
            parts = candidates[0]["content"].get("parts", [])
            if parts and "text" in parts[0]:
                return {
                    "text": parts[0]["text"].strip(),
                    "source": "Google Gemini 1.5 Flash (Live API)",
                    "status": "online"
                }
    raise Exception(f"Gemini error {resp.status_code}: {resp.text}")


def _call_openai(prompt, system_prompt, api_key):
    """Invokes OpenAI REST API."""
    url = "https://api.openai.com/v1/chat/completions"
    payload = {
        "model": "gpt-4o-mini",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.4,
        "max_tokens": 600
    }
    resp = requests.post(
        url,
        json=payload,
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
        timeout=12
    )
    if resp.status_code == 200:
        data = resp.json()
        choices = data.get("choices", [])
        if choices and "message" in choices[0]:
            return {
                "text": choices[0]["message"]["content"].strip(),
                "source": "OpenAI GPT-4o-mini (Live API)",
                "status": "online"
            }
    raise Exception(f"OpenAI error {resp.status_code}: {resp.text}")


def _smart_campus_copilot_fallback(prompt, user=None):
    """
    Domain-specific rule & NLP response generator when external API keys are not active.
    Ensures 100% functionality on the website under all conditions.
    """
    p = prompt.lower().strip()

    # Personalized Status Check
    if any(k in p for k in ['my complaint', 'my ticket', 'complaint status', 'check complaint', 'status of my']):
        if user and getattr(user, 'is_authenticated', False):
            cmps = Complaint.query.filter_by(student_id=user.id).order_by(Complaint.created_at.desc()).limit(3).all()
            if cmps:
                lines = [f"Here is your recent complaint status, **{user.name}**:"]
                for c in cmps:
                    badge = "🟢" if c.status == 'resolved' else ("🟡" if c.status == 'acknowledged' else "🔵")
                    lines.append(f"- **#{c.id}** ({c.category.replace('cat_', '').title()} in Room {c.room}): {badge} `{c.status.upper()}` (Age: {c.age_label})")
                lines.append("\nYou can view full details in your [Complaints Dashboard](/complaints).")
                return {"text": "\n".join(lines), "source": "Campus Copilot (Local Intelligence Engine)", "status": "simulated"}
            return {"text": "You do not have any open complaints filed right now! You can lodge a new issue using [Report an Issue](/complaints/new).", "source": "Campus Copilot (Local Intelligence Engine)", "status": "simulated"}
        return {"text": "Please log in to your student account to check your live complaint and ticket status.", "source": "Campus Copilot (Local Intelligence Engine)", "status": "simulated"}

    # Gate Pass & Curfew
    if any(k in p for k in ['gate pass', 'leave', 'exit pass', 'curfew', 'out time', 'permission']):
        return {
            "text": """### 🚪 Campus Gate Pass & Curfew Policy
* **Emergency Gate Pass**: Select the 🚨 Emergency checkbox on the [New Gate Pass Form](/gate-pass/new). Features an **enforceable 30-minute SLA countdown**, auto-flags to the warden's priority queue, and triggers instant SMS alerts to parents.
* **Standard Gate Pass**: Submit at least 24 hours prior with destination and verified reason.
* **Curfew Hours**:
  * Weekdays: **10:00 PM**
  * Weekends: **10:30 PM**
* **Kiosk Terminal**: If your phone battery dies or you have no connectivity, log your exit pass via any Campus Touch Kiosk.""",
            "source": "Campus Copilot (Local Intelligence Engine)",
            "status": "simulated"
        }

    # Mess Timings & Menu
    if any(k in p for k in ['mess', 'food', 'breakfast', 'lunch', 'dinner', 'canteen', 'snack']):
        return {
            "text": """### 🍽️ Campus Mess & Dining Schedule
* **Breakfast**: `07:30 AM – 09:30 AM` (Idli/Dosa/Poha, Eggs/Sprouts, Tea/Coffee)
* **Lunch**: `12:30 PM – 02:30 PM` (Dal, Paneer/Chicken, Rice, Roti, Salad)
* **Evening Snacks**: `05:00 PM – 06:30 PM` (Samosa/Pakora, Biscuits, Tea)
* **Dinner**: `07:30 PM – 09:30 PM` (Vegetable Curry, Roti, Rice, Dessert)

💡 *Tip: You can submit mess feedback or rate today's meals directly under [Mess Management](/mess).*""",
            "source": "Campus Copilot (Local Intelligence Engine)",
            "status": "simulated"
        }

    # Medical & Emergencies
    if any(k in p for k in ['doctor', 'hospital', 'medical', 'health', 'ambulance', 'sick', 'emergency', 'fever', 'medicine']):
        return {
            "text": """### 🚑 Campus Health Center & Emergency Contacts
* **Health Center / Dispensary**: Open 24/7 next to Central Administration Block.
* **Resident Medical Officer**: Dr. Sen (+91-9876500108 / Ext 108).
* **Emergency Ambulance Service**: Call **102** or Campus Dispatch at **Ext 100**.
* **Medical Gate Pass**: If you need to visit an off-campus hospital, submit an **Emergency Gate Pass** with OCR medical slip scan for instant 30-minute approval.""",
            "source": "Campus Copilot (Local Intelligence Engine)",
            "status": "simulated"
        }

    # WiFi & IT Issues
    if any(k in p for k in ['wifi', 'internet', 'lan', 'network', 'login wifi', 'speed']):
        return {
            "text": """### 📶 Campus Network & WiFi Troubleshooting
* **SSID**: `CampusNet-Secure` (Use your Student Roll Number and Webmail Password).
* **MAC Registration**: Log in to the captive portal `wifi.campus.internal` to register up to 2 devices.
* **Reporting Outages**: If your room's Ethernet port or hostel floor AP is down, submit a [WiFi Maintenance Complaint](/complaints/new) under category `WiFi / Network`.""",
            "source": "Campus Copilot (Local Intelligence Engine)",
            "status": "simulated"
        }

    # General Campus Assistant Welcome
    return {
        "text": f"""Hello! I am your **ABHYURTI Campus AI Assistant** 🎓

I can help you with:
- 🛠️ **Maintenance**: Auto-classifying complaints and tracking repair turnaround.
- 🚪 **Gate Passes**: Applying for emergency leave with 30-minute warden SLA.
- 🗺️ **Campus Navigation**: Finding hostel rooms, dining halls, and health centers on the [Campus Map](/campus-map).
- 🍽️ **Hostel & Mess**: Checking meal timings, dietary complaints, and hostel rules.
- 📄 **Document OCR**: Auto-extracting info from medical prescriptions and leave slips.

*Ask me anything about campus life, policies, or your tickets!*""",
        "source": "Campus Copilot (Local Intelligence Engine)",
        "status": "simulated"
    }


def classify_complaint_ai(title, description, hostel='Hostel A', room='101'):
    """
    Classifies complaint category, urgency, estimated turnaround time,
    and conducts recurring issue detection across the hostel/room.
    """
    full_text = f"{title} {description}".lower()

    # Rule & Keyword heuristic matrix
    categories_matrix = {
        'cat_plumbing': ['leak', 'tap', 'washbasin', 'pipe', 'flush', 'water', 'geyser', 'drain', 'bathroom', 'toilet', 'shower', 'sink', 'dripping'],
        'cat_electrical': ['light', 'fan', 'switch', 'socket', 'plug', 'mcb', 'power', 'bulb', 'tube', 'short circuit', 'current', 'spark', 'tripping', 'voltage'],
        'cat_furniture': ['bed', 'chair', 'table', 'cupboard', 'almirah', 'wardrobe', 'desk', 'hinge', 'door', 'lock', 'window', 'handle', 'drawer'],
        'cat_wifi': ['wifi', 'internet', 'router', 'network', 'lan', 'cable', 'connection', 'ping', 'slow', 'disconnect', 'portal', 'ethernet'],
        'cat_cleaning': ['clean', 'dust', 'sweep', 'garbage', 'trash', 'dirty', 'sweep', 'mop', 'corridor', 'smell', 'washroom dirty'],
        'cat_pest': ['mosquito', 'cockroach', 'rat', 'rodent', 'pest', 'insect', 'ant', 'termite', 'bedbug', 'snake', 'lizard']
    }

    predicted_category = 'cat_other'
    max_matches = 0
    for cat, keywords in categories_matrix.items():
        matches = sum(1 for kw in keywords if kw in full_text)
        if matches > max_matches:
            max_matches = matches
            predicted_category = cat

    # Urgency detection
    urgency = 'medium'
    sla_hours = 24
    department = 'General Maintenance'

    if any(k in full_text for k in ['spark', 'smoke', 'fire', 'flood', 'overflowing', 'electric shock', 'emergency', 'urgent', 'burst']):
        urgency = 'emergency'
        sla_hours = 2
    elif any(k in full_text for k in ['broken', 'leak', 'no light', 'no water', 'fan not working', 'geyser not working']):
        urgency = 'high'
        sla_hours = 6
    elif any(k in full_text for k in ['clean', 'dust', 'slow', 'mosquito']):
        urgency = 'low'
        sla_hours = 48

    dept_map = {
        'cat_plumbing': 'Plumbing Division',
        'cat_electrical': 'Electrical Division',
        'cat_furniture': 'Carpentry & Estate',
        'cat_wifi': 'IT & Campus Network Center',
        'cat_cleaning': 'Housekeeping & Sanitation',
        'cat_pest': 'Health & Pest Control Unit',
        'cat_other': 'Estate Maintenance Office'
    }
    department = dept_map.get(predicted_category, 'General Maintenance')

    # Recurring Issue Detection:
    # Query database for matching complaints in same hostel + room within last 30 days
    is_recurring = False
    recurring_count = 0
    recurring_details = []

    try:
        thirty_days_ago = datetime.utcnow() - timedelta(days=30)
        past_cmps = Complaint.query.filter(
            Complaint.hostel == hostel,
            Complaint.room == room,
            Complaint.created_at >= thirty_days_ago
        ).order_by(Complaint.created_at.desc()).all()

        for c in past_cmps:
            # Check if same category
            if c.category == predicted_category:
                recurring_count += 1
                recurring_details.append(f"Ticket #{c.id} ({c.status}) on {c.created_at.strftime('%d %b')}")

        if recurring_count > 0:
            is_recurring = True
            # Bump urgency if recurring
            if urgency == 'low':
                urgency = 'medium'
            elif urgency == 'medium':
                urgency = 'high'
    except Exception as e:
        if current_app:
            current_app.logger.warning(f"Error querying recurring complaints: {e}")

    recurring_note = None
    if is_recurring:
        recurring_note = f"⚠️ Recurring Issue Detected: {recurring_count} previous {predicted_category.replace('cat_', '')} ticket(s) logged in {hostel} Room {room} in the past 30 days ({', '.join(recurring_details[:2])}). Priority auto-escalated to {urgency.upper()}!"

    return {
        "category": predicted_category,
        "urgency": urgency,
        "sla_hours": sla_hours,
        "estimated_turnaround": f"{sla_hours} hours",
        "department": department,
        "is_recurring": is_recurring,
        "recurring_count": recurring_count,
        "recurring_note": recurring_note,
        "ai_engine": get_setting('ACTIVE_AI_PROVIDER', 'gemini')
    }
