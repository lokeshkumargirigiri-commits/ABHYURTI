import os
import io
import time
import hashlib
import requests
from flask import current_app
from app.services.settings_service import get_setting

def upload_to_cloudinary(image_bytes, filename="campus_upload.jpg", folder="fretbox_campus"):
    """
    Uploads image bytes directly to Cloudinary using standard REST API with SHA-1 signature.
    Returns secure CDN URL if successful, or None to fall back to local disk.
    """
    cloud_name = get_setting('CLOUDINARY_CLOUD_NAME')
    api_key = get_setting('CLOUDINARY_API_KEY')
    api_secret = get_setting('CLOUDINARY_API_SECRET')

    if not (cloud_name and api_key and api_secret):
        return None  # Cloudinary not configured; fallback to local storage

    try:
        timestamp = int(time.time())
        # Cloudinary signature requires parameters sorted alphabetically: folder, timestamp
        to_sign = f"folder={folder}&timestamp={timestamp}{api_secret}"
        signature = hashlib.sha1(to_sign.encode('utf-8')).hexdigest()

        url = f"https://api.cloudinary.com/v1_1/{cloud_name}/image/upload"
        
        files = {
            'file': (filename, image_bytes, 'image/jpeg')
        }
        data = {
            'api_key': api_key,
            'timestamp': timestamp,
            'folder': folder,
            'signature': signature
        }

        resp = requests.post(url, data=data, files=files, timeout=15)
        if resp.status_code == 200:
            result = resp.json()
            cdn_url = result.get('secure_url') or result.get('url')
            if current_app:
                current_app.logger.info(f"Cloudinary upload successful: {cdn_url}")
            return cdn_url
        else:
            if current_app:
                current_app.logger.warning(f"Cloudinary upload HTTP {resp.status_code}: {resp.text}")
            return None
    except Exception as e:
        if current_app:
            current_app.logger.warning(f"Cloudinary upload exception: {e}")
        return None


def test_cloudinary_connection(cloud_name=None, api_key=None, api_secret=None):
    """
    Tests Cloudinary connection with a 1x1 test image upload and instant delete.
    """
    cn = cloud_name or get_setting('CLOUDINARY_CLOUD_NAME')
    ak = api_key or get_setting('CLOUDINARY_API_KEY')
    asec = api_secret or get_setting('CLOUDINARY_API_SECRET')

    if not (cn and ak and asec):
        return {"success": False, "message": "Missing Cloudinary Cloud Name, API Key, or API Secret."}

    try:
        # Minimal 1x1 GIF bytes
        gif_1x1 = b'GIF89a\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00!\xf9\x04\x01\x00\x00\x00\x00,\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02D\x01\x00;'
        timestamp = int(time.time())
        to_sign = f"folder=fretbox_ping&timestamp={timestamp}{asec}"
        signature = hashlib.sha1(to_sign.encode('utf-8')).hexdigest()

        url = f"https://api.cloudinary.com/v1_1/{cn}/image/upload"
        files = {'file': ('ping.gif', gif_1x1, 'image/gif')}
        data = {'api_key': ak, 'timestamp': timestamp, 'folder': 'fretbox_ping', 'signature': signature}

        resp = requests.post(url, data=data, files=files, timeout=10)
        if resp.status_code == 200:
            res = resp.json()
            return {"success": True, "message": f"Connected to Cloudinary cloud '{cn}'! Test asset created: {res.get('public_id')}"}
        else:
            return {"success": False, "message": f"Cloudinary error {resp.status_code}: {resp.text}"}
    except Exception as e:
        return {"success": False, "message": f"Connection error: {str(e)}"}
