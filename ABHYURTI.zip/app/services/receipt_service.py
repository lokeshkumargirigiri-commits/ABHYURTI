import hmac
import hashlib
import secrets
from flask import current_app


def generate_receipt_token():
    """Generate a high-entropy URL-safe receipt token."""
    return f"FRET-RCP-{secrets.token_urlsafe(18).upper()}"


def compute_receipt_signature(payment_id, student_id, amount, transaction_ref, paid_at_str):
    """Compute HMAC-SHA256 cryptographic signature for fee payment receipt."""
    secret = current_app.config.get('SECRET_KEY', 'campus-os-secure-secret').encode('utf-8')
    payload = f"PAY:{payment_id}|STUDENT:{student_id}|AMT:{amount:.2f}|TXN:{transaction_ref}|TIME:{paid_at_str}".encode('utf-8')
    return hmac.new(secret, payload, hashlib.sha256).hexdigest()


def sign_fee_payment(payment):
    """Sign and assign receipt token & signature to FeePayment model."""
    if not payment.receipt_token:
        payment.receipt_token = generate_receipt_token()
    paid_str = payment.paid_at.isoformat() if payment.paid_at else ""
    payment.receipt_signature = compute_receipt_signature(
        payment.id or 0,
        payment.student_id,
        payment.total_payable,
        payment.transaction_ref or "TXN-MOCK",
        paid_str
    )
    return payment.receipt_signature


def verify_fee_payment(payment):
    """Verify cryptographic authenticity of a fee payment receipt."""
    if not payment or not payment.receipt_signature or not payment.receipt_token:
        return False
    paid_str = payment.paid_at.isoformat() if payment.paid_at else ""
    expected = compute_receipt_signature(
        payment.id,
        payment.student_id,
        payment.total_payable,
        payment.transaction_ref or "TXN-MOCK",
        paid_str
    )
    return hmac.compare_digest(expected, payment.receipt_signature)
