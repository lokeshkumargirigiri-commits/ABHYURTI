import os
from flask import current_app
from app.extensions import db
from app.models import SystemSetting

DEFAULT_INTEGRATIONS_CONFIG = [
    # AI Providers
    {
        'key': 'GEMINI_API_KEY',
        'name': 'Google Gemini API Key',
        'category': 'ai',
        'is_secret': True,
        'description': 'Powers Campus AI Chatbot Copilot, smart complaint classification/routing, and recurring issue detection.',
        'placeholder': 'AIzaSy...'
    },
    {
        'key': 'OPENAI_API_KEY',
        'name': 'OpenAI API Key',
        'category': 'ai',
        'is_secret': True,
        'description': 'Alternative AI engine for chatbot and complaint triage (e.g. GPT-4o-mini).',
        'placeholder': 'sk-proj-...'
    },
    {
        'key': 'ACTIVE_AI_PROVIDER',
        'name': 'Active AI Provider',
        'category': 'ai',
        'is_secret': False,
        'description': 'Choose active AI provider: "gemini" or "openai".',
        'placeholder': 'gemini'
    },
    # Google Maps
    {
        'key': 'GOOGLE_MAPS_API_KEY',
        'name': 'Google Maps API Key',
        'category': 'maps',
        'is_secret': True,
        'description': 'Hostel/campus location, navigation, facility locations, and interactive routing.',
        'placeholder': 'AIzaSy...'
    },
    # Firebase & FCM
    {
        'key': 'FIREBASE_API_KEY',
        'name': 'Firebase Web API Key',
        'category': 'firebase',
        'is_secret': True,
        'description': 'Firebase client SDK key for authentication, notifications, and storage sync.',
        'placeholder': 'AIzaSy...'
    },
    {
        'key': 'FIREBASE_PROJECT_ID',
        'name': 'Firebase Project ID',
        'category': 'firebase',
        'is_secret': False,
        'description': 'Firebase project identifier.',
        'placeholder': 'fretbox-campus-prod'
    },
    {
        'key': 'FIREBASE_APP_ID',
        'name': 'Firebase App ID',
        'category': 'firebase',
        'is_secret': False,
        'description': 'Firebase Application identifier (1:12345:web:...):',
        'placeholder': '1:1000000000:web:abcd'
    },
    {
        'key': 'FCM_SERVER_KEY',
        'name': 'Firebase Cloud Messaging (FCM) Server Key',
        'category': 'firebase',
        'is_secret': True,
        'description': 'FCM server key or bearer token for real-time mobile and web push notifications.',
        'placeholder': 'AAAA...'
    },
    {
        'key': 'FCM_VAPID_KEY',
        'name': 'FCM VAPID Public Key',
        'category': 'firebase',
        'is_secret': False,
        'description': 'VAPID public key for browser push notification registration.',
        'placeholder': 'BEl...'
    },
    # Cloudinary
    {
        'key': 'CLOUDINARY_CLOUD_NAME',
        'name': 'Cloudinary Cloud Name',
        'category': 'storage',
        'is_secret': False,
        'description': 'Cloudinary cloud name for media assets, complaint photos, and medical proofs.',
        'placeholder': 'campus-cloud'
    },
    {
        'key': 'CLOUDINARY_API_KEY',
        'name': 'Cloudinary API Key',
        'category': 'storage',
        'is_secret': False,
        'description': 'Cloudinary public API key.',
        'placeholder': '123456789012345'
    },
    {
        'key': 'CLOUDINARY_API_SECRET',
        'name': 'Cloudinary API Secret',
        'category': 'storage',
        'is_secret': True,
        'description': 'Cloudinary private API secret for authenticated secure uploads.',
        'placeholder': 'abCdEf...'
    },
    # Twilio (SMS & WhatsApp)
    {
        'key': 'TWILIO_ACCOUNT_SID',
        'name': 'Twilio Account SID',
        'category': 'sms',
        'is_secret': False,
        'description': 'Twilio Account SID for SMS and WhatsApp gate pass emergency alerts.',
        'placeholder': 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    },
    {
        'key': 'TWILIO_AUTH_TOKEN',
        'name': 'Twilio Auth Token',
        'category': 'sms',
        'is_secret': True,
        'description': 'Twilio Auth Token for signing API dispatches.',
        'placeholder': 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    },
    {
        'key': 'TWILIO_PHONE_NUMBER',
        'name': 'Twilio SMS From Phone Number',
        'category': 'sms',
        'is_secret': False,
        'description': 'Twilio provisioned phone number (e.g. +1234567890).',
        'placeholder': '+1234567890'
    },
    {
        'key': 'TWILIO_WHATSAPP_NUMBER',
        'name': 'Twilio WhatsApp From Number',
        'category': 'sms',
        'is_secret': False,
        'description': 'Twilio WhatsApp sender number (e.g. +14155238886).',
        'placeholder': '+14155238886'
    },
    # Resend & SendGrid (Email)
    {
        'key': 'RESEND_API_KEY',
        'name': 'Resend Email API Key',
        'category': 'email',
        'is_secret': True,
        'description': 'Resend modern transactional email API key.',
        'placeholder': 're_123...'
    },
    {
        'key': 'SENDGRID_API_KEY',
        'name': 'SendGrid API Key',
        'category': 'email',
        'is_secret': True,
        'description': 'SendGrid email delivery API key.',
        'placeholder': 'SG.123...'
    },
    {
        'key': 'MAIL_FROM',
        'name': 'From Email Address',
        'category': 'email',
        'is_secret': False,
        'description': 'Sender email for official student and staff notifications.',
        'placeholder': 'notifications@campus-fretbox.edu'
    },
    # Supabase
    {
        'key': 'SUPABASE_URL',
        'name': 'Supabase Project URL',
        'category': 'database',
        'is_secret': False,
        'description': 'Supabase Project URL for cloud database, auth, and remote storage backup.',
        'placeholder': 'https://xyzcompany.supabase.co'
    },
    {
        'key': 'SUPABASE_ANON_KEY',
        'name': 'Supabase Anon Public Key',
        'category': 'database',
        'is_secret': True,
        'description': 'Supabase public anon API key.',
        'placeholder': 'eyJhbGci...'
    },
    # OCR API
    {
        'key': 'OCR_API_KEY',
        'name': 'OCR Space / Vision API Key',
        'category': 'ocr',
        'is_secret': True,
        'description': 'Extracts text and structured medical data from uploaded prescription & pass slips.',
        'placeholder': 'K87899142388957'
    }
]

def get_setting(key, default=None):
    """
    Fetches a setting value.
    Checks SQLite SystemSetting table first, then environment variable.
    """
    try:
        row = SystemSetting.query.filter_by(key=key).first()
        if row and row.value is not None and row.value.strip() != "":
            return row.value.strip()
    except Exception:
        pass
    
    val = os.environ.get(key)
    if val is not None and val.strip() != "":
        return val.strip()
    return default


def set_setting(key, value, category=None, is_secret=None, description=None):
    """
    Updates or inserts setting in database and memory os.environ.
    """
    val_to_store = value.strip() if value else ""
    os.environ[key] = val_to_store

    try:
        row = SystemSetting.query.filter_by(key=key).first()
        if not row:
            # find default meta
            meta = next((m for m in DEFAULT_INTEGRATIONS_CONFIG if m['key'] == key), None)
            cat = category or (meta['category'] if meta else 'general')
            sec = is_secret if is_secret is not None else (meta['is_secret'] if meta else False)
            desc = description or (meta['description'] if meta else '')
            row = SystemSetting(key=key, value=val_to_store, category=cat, is_secret=sec, description=desc)
            db.session.add(row)
        else:
            row.value = val_to_store
            if category:
                row.category = category
            if is_secret is not None:
                row.is_secret = is_secret
            if description:
                row.description = description
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        if current_app:
            current_app.logger.warning(f"Error persisting setting {key}: {e}")

    # Also persist to .env file for permanent persistence
    _sync_to_env_file(key, val_to_store)
    return True


def _sync_to_env_file(key, value):
    """Helper to update key in root .env file."""
    try:
        env_path = os.path.join(os.path.abspath(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))), '.env')
        lines = []
        found = False
        if os.path.exists(env_path):
            with open(env_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
        
        new_lines = []
        for line in lines:
            if line.strip().startswith(f"{key}=") or line.strip() == key:
                new_lines.append(f"{key}={value}\n")
                found = True
            else:
                new_lines.append(line)
        if not found:
            new_lines.append(f"{key}={value}\n")
        
        with open(env_path, 'w', encoding='utf-8') as f:
            f.writelines(new_lines)
    except Exception:
        pass


def get_all_integrations_summary():
    """
    Returns high-level status of all 10 third-party integrations.
    """
    settings_map = {}
    try:
        rows = SystemSetting.query.all()
        for r in rows:
            settings_map[r.key] = r
    except Exception:
        pass

    results = []
    for item in DEFAULT_INTEGRATIONS_CONFIG:
        k = item['key']
        db_row = settings_map.get(k)
        raw_val = db_row.value if db_row and db_row.value else os.environ.get(k, '')
        has_val = bool(raw_val and raw_val.strip())

        masked = ""
        if has_val:
            if item['is_secret']:
                masked = (raw_val[:4] + "••••••••" + raw_val[-4:]) if len(raw_val) > 8 else "••••••••"
            else:
                masked = raw_val

        results.append({
            'key': k,
            'name': item['name'],
            'category': item['category'],
            'is_secret': item['is_secret'],
            'description': item['description'],
            'placeholder': item['placeholder'],
            'has_value': has_val,
            'display_value': masked,
            'status': 'configured' if has_val else 'simulated'
        })
    return results
