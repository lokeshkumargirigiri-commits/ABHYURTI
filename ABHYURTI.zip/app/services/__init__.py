# ABHYURTI Campus OS Services Package
from app.services.settings_service import (
    get_setting, set_setting, get_all_integrations_summary
)
get_all_settings = get_all_integrations_summary
