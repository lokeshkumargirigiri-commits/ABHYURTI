import requests
from datetime import datetime
from flask import current_app
from app.extensions import db
from app.models import Notification, FCMSubscription, AuditLog, User
from app.services.settings_service import get_setting

# ------------------------------------------------------------------------------
# 1. TWILIO SMS & WHATSAPP
# ------------------------------------------------------------------------------
def send_sms(to_phone, message):
    """
    Sends an SMS via Twilio if configured, or falls back to an in-app simulated log.
    """
    sid = get_setting('TWILIO_ACCOUNT_SID')
    token = get_setting('TWILIO_AUTH_TOKEN')
    from_num = get_setting('TWILIO_PHONE_NUMBER')

    clean_phone = _format_phone(to_phone)

    if sid and token and from_num:
        try:
            url = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
            resp = requests.post(
                url,
                data={'From': from_num, 'To': clean_phone, 'Body': message},
                auth=(sid, token),
                timeout=10
            )
            if resp.status_code in (200, 201):
                data = resp.json()
                return {"success": True, "provider": "Twilio (Live SMS)", "sid": data.get("sid")}
            else:
                if current_app:
                    current_app.logger.warning(f"Twilio SMS error {resp.status_code}: {resp.text}")
        except Exception as e:
            if current_app:
                current_app.logger.warning(f"Twilio connection error: {e}")

    # Fallback: Simulated SMS Log
    _log_simulated_dispatch("SMS", clean_phone, message)
    return {"success": True, "provider": "Simulated SMS Gateway", "status": "logged_to_audit"}


def send_whatsapp(to_phone, message):
    """
    Sends a WhatsApp message via Twilio if configured, or falls back to simulated log.
    """
    sid = get_setting('TWILIO_ACCOUNT_SID')
    token = get_setting('TWILIO_AUTH_TOKEN')
    whatsapp_from = get_setting('TWILIO_WHATSAPP_NUMBER') or "whatsapp:+14155238886"

    clean_phone = _format_phone(to_phone)
    dest = clean_phone if clean_phone.startswith('whatsapp:') else f"whatsapp:{clean_phone}"

    if sid and token:
        try:
            url = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
            resp = requests.post(
                url,
                data={'From': whatsapp_from, 'To': dest, 'Body': message},
                auth=(sid, token),
                timeout=10
            )
            if resp.status_code in (200, 201):
                return {"success": True, "provider": "Twilio WhatsApp (Live)", "sid": resp.json().get("sid")}
        except Exception as e:
            if current_app:
                current_app.logger.warning(f"Twilio WhatsApp error: {e}")

    _log_simulated_dispatch("WhatsApp", dest, message)
    return {"success": True, "provider": "Simulated WhatsApp Gateway", "status": "logged_to_audit"}


def test_twilio_connection(sid=None, token=None):
    """Tests Twilio account credentials."""
    s = sid or get_setting('TWILIO_ACCOUNT_SID')
    t = token or get_setting('TWILIO_AUTH_TOKEN')
    if not (s and t):
        return {"success": False, "message": "Missing Twilio Account SID or Auth Token."}
    try:
        url = f"https://api.twilio.com/2010-04-01/Accounts/{s}.json"
        resp = requests.get(url, auth=(s, t), timeout=8)
        if resp.status_code == 200:
            name = resp.json().get('friendly_name', 'Twilio Account')
            return {"success": True, "message": f"Successfully verified Twilio Account: {name}"}
        return {"success": False, "message": f"Twilio authentication failed: {resp.text}"}
    except Exception as e:
        return {"success": False, "message": f"Connection error: {str(e)}"}


# ------------------------------------------------------------------------------
# 2. EMAIL (RESEND & SENDGRID)
# ------------------------------------------------------------------------------
def send_email(to_email, subject, html_content, text_content=None):
    """
    Sends transactional email via Resend, SendGrid, or fallback simulator.
    """
    mail_from = get_setting('MAIL_FROM') or "notifications@campus-abhyurti.edu"
    resend_key = get_setting('RESEND_API_KEY')
    sendgrid_key = get_setting('SENDGRID_API_KEY')

    # 1. Try Resend
    if resend_key:
        try:
            url = "https://api.resend.com/emails"
            headers = {"Authorization": f"Bearer {resend_key}", "Content-Type": "application/json"}
            payload = {
                "from": mail_from,
                "to": [to_email],
                "subject": subject,
                "html": html_content
            }
            resp = requests.post(url, json=payload, headers=headers, timeout=10)
            if resp.status_code in (200, 201):
                return {"success": True, "provider": "Resend (Live Email)", "id": resp.json().get("id")}
        except Exception as e:
            if current_app:
                current_app.logger.warning(f"Resend error: {e}")

    # 2. Try SendGrid
    if sendgrid_key:
        try:
            url = "https://api.sendgrid.com/v3/mail/send"
            headers = {"Authorization": f"Bearer {sendgrid_key}", "Content-Type": "application/json"}
            payload = {
                "personalizations": [{"to": [{"email": to_email}]}],
                "from": {"email": mail_from, "name": "ABHYURTI Campus OS"},
                "subject": subject,
                "content": [{"type": "text/html", "value": html_content}]
            }
            resp = requests.post(url, json=payload, headers=headers, timeout=10)
            if resp.status_code in (200, 202):
                return {"success": True, "provider": "SendGrid (Live Email)"}
        except Exception as e:
            if current_app:
                current_app.logger.warning(f"SendGrid error: {e}")

    # Fallback: Simulated Email Log
    _log_simulated_dispatch("Email", to_email, f"[{subject}] {text_content or html_content[:100]}...")
    return {"success": True, "provider": "Simulated Email Gateway", "status": "logged_to_audit"}


def test_email_service(provider='resend', api_key=None):
    """Tests Resend or SendGrid API credentials."""
    if provider == 'resend':
        k = api_key or get_setting('RESEND_API_KEY')
        if not k:
            return {"success": False, "message": "Missing Resend API Key."}
        try:
            resp = requests.get("https://api.resend.com/api-keys", headers={"Authorization": f"Bearer {k}"}, timeout=8)
            if resp.status_code == 200:
                return {"success": True, "message": "Resend API connection authenticated successfully!"}
            return {"success": False, "message": f"Resend error {resp.status_code}: {resp.text}"}
        except Exception as e:
            return {"success": False, "message": f"Connection error: {str(e)}"}
    elif provider == 'sendgrid':
        k = api_key or get_setting('SENDGRID_API_KEY')
        if not k:
            return {"success": False, "message": "Missing SendGrid API Key."}
        try:
            resp = requests.get("https://api.sendgrid.com/v3/user/profile", headers={"Authorization": f"Bearer {k}"}, timeout=8)
            if resp.status_code == 200:
                return {"success": True, "message": "SendGrid API connection authenticated successfully!"}
            return {"success": False, "message": f"SendGrid error {resp.status_code}: {resp.text}"}
        except Exception as e:
            return {"success": False, "message": f"Connection error: {str(e)}"}
    return {"success": False, "message": "Unknown email provider."}


# ------------------------------------------------------------------------------
# 3. FIREBASE CLOUD MESSAGING (FCM) & PUSH NOTIFICATIONS
# ------------------------------------------------------------------------------
def send_push_notification(user_id, title, body, url=None, data=None):
    """
    Dispatches FCM Web/Mobile push notification to all user's registered tokens,
    and inserts an in-app notification record in the SQLite database.
    """
    # 1. Always create in-app notification in DB
    try:
        notif = Notification(
            user_id=user_id,
            title=title,
            message=body,
            link=url or '/notifications',
            category='gate_pass' if 'Gate Pass' in title else ('complaint' if 'Complaint' in title else 'system')
        )
        db.session.add(notif)
        db.session.commit()
    except Exception as e:
        if current_app:
            current_app.logger.warning(f"Error creating in-app notification: {e}")

    # 2. Check FCM Subscriptions
    fcm_key = get_setting('FCM_SERVER_KEY')
    tokens = []
    try:
        subs = FCMSubscription.query.filter_by(user_id=user_id).all()
        tokens = [s.token for s in subs if s.token]
    except Exception:
        pass

    if fcm_key and tokens:
        try:
            fcm_endpoint = "https://fcm.googleapis.com/fcm/send"
            headers = {
                "Authorization": f"key={fcm_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "registration_ids": tokens,
                "notification": {
                    "title": title,
                    "body": body,
                    "icon": "/static/img/icon-192.png",
                    "click_action": url or "/"
                },
                "data": data or {}
            }
            resp = requests.post(fcm_endpoint, json=payload, headers=headers, timeout=8)
            if resp.status_code == 200:
                return {"success": True, "provider": "Firebase Cloud Messaging (FCM)", "sent_count": len(tokens)}
        except Exception as e:
            if current_app:
                current_app.logger.warning(f"FCM push error: {e}")

    return {"success": True, "provider": "In-App Notification Center (FCM Fallback)", "tokens": len(tokens)}


def test_fcm_connection(server_key=None):
    """Validates FCM Server Key against Google endpoint."""
    k = server_key or get_setting('FCM_SERVER_KEY')
    if not k:
        return {"success": False, "message": "Missing FCM Server Key."}
    try:
        resp = requests.post(
            "https://fcm.googleapis.com/fcm/send",
            headers={"Authorization": f"key={k}", "Content-Type": "application/json"},
            json={"registration_ids": ["dummy_token_for_ping_test"]},
            timeout=8
        )
        # Even if token is invalid, 200 OK means server key authenticated!
        if resp.status_code == 200:
            return {"success": True, "message": "FCM Server Key verified successfully with Google Firebase Cloud Messaging!"}
        return {"success": False, "message": f"FCM authentication failed: {resp.text}"}
    except Exception as e:
        return {"success": False, "message": f"Connection error: {str(e)}"}


# ------------------------------------------------------------------------------
# 4. DOMAIN EVENT DISPATCHERS
# ------------------------------------------------------------------------------
def notify_emergency_gate_pass_raised(gate_pass, student):
    """Called when an emergency gate pass is created."""
    # 1. Alert student & parent
    msg = f"🚨 EMERGENCY PASS #{gate_pass.id} LOGGED: {student.name} requested leave to {gate_pass.destination}. 30-min warden SLA activated."
    if gate_pass.parent_notified and student.phone:
        send_sms(student.phone, msg)
        send_whatsapp(student.phone, msg)

    # 2. Email confirmation
    email_html = f"""
    <div style="font-family: sans-serif; padding: 20px; border-left: 6px solid #ef4444; background: #fef2f2;">
        <h2 style="color: #991b1b; margin-top:0;">🚨 Emergency Gate Pass Submitted (#{gate_pass.id})</h2>
        <p>Dear {student.name},</p>
        <p>Your emergency gate pass to <strong>{gate_pass.destination}</strong> has been flagged at the very top of the warden emergency queue.</p>
        <p><strong>Reason:</strong> {gate_pass.emergency_reason or gate_pass.reason}</p>
        <p><strong>Strict SLA:</strong> 30-Minute countdown active.</p>
        <p><em>ABHYURTI Campus Operations Layer</em></p>
    </div>
    """
    send_email(student.email, f"🚨 Emergency Gate Pass #{gate_pass.id} Submitted", email_html)

    # 3. Notify Wardens in this hostel
    try:
        wardens = User.query.filter(User.hostel == student.hostel, User.role == 'warden').all()
        for w in wardens:
            send_push_notification(
                w.id,
                f"🚨 Emergency Gate Pass #{gate_pass.id}",
                f"{student.name} ({student.room}) requested emergency leave to {gate_pass.destination}!",
                url=f"/admin/gate-passes"
            )
    except Exception:
        pass


def notify_gate_pass_status_changed(gate_pass, student, new_status, approver_name=None):
    """Called when warden approves or rejects gate pass."""
    status_label = "APPROVED ✅" if new_status == 'approved' else "REJECTED ❌"
    title = f"Gate Pass #{gate_pass.id} {status_label}"
    body = f"Your gate pass to {gate_pass.destination} was {new_status} by {approver_name or 'Hostel Warden'}."

    # 1. Push + In-App
    send_push_notification(student.id, title, body, url=f"/gate-pass/{gate_pass.id}")

    # 2. SMS alert
    if student.phone:
        sms_text = f"ABHYURTI: Gate Pass #{gate_pass.id} to {gate_pass.destination} has been {new_status.upper()}. Details: /gate-pass/{gate_pass.id}"
        send_sms(student.phone, sms_text)

    # 3. Official Email Receipt
    email_html = f"""
    <div style="font-family: sans-serif; padding: 20px; border: 1px solid #e2e8f0; border-radius: 8px;">
        <h2 style="color: {'#16a34a' if new_status == 'approved' else '#dc2626'}; margin-top:0;">Gate Pass #{gate_pass.id}: {status_label}</h2>
        <p>Student: <strong>{student.name}</strong> ({student.roll_number})</p>
        <p>Destination: <strong>{gate_pass.destination}</strong></p>
        <p>Valid From: {gate_pass.from_date.strftime('%d %b %Y, %I:%M %p')} to {gate_pass.to_date.strftime('%d %b %Y, %I:%M %p')}</p>
        <p>Actioned By: {approver_name or 'Warden Office'}</p>
        <hr style="border:none; border-top: 1px solid #e2e8f0; margin: 16px 0;">
        <p style="font-size: 0.85rem; color: #64748b;">Show your digital QR code at Main Security Gate 1 upon exit.</p>
    </div>
    """
    send_email(student.email, f"Campus Gate Pass #{gate_pass.id}: {status_label}", email_html)


def notify_complaint_status_changed(complaint, student, new_status, notes=None):
    """Called on maintenance complaint status progression."""
    title = f"Complaint #{complaint.id} Status: {new_status.replace('_', ' ').title()}"
    body = f"Your {complaint.category.replace('cat_', '').title()} issue in Room {complaint.room} is now {new_status}."
    if notes:
        body += f" Note: {notes}"
    send_push_notification(student.id, title, body, url=f"/complaints/{complaint.id}")


# ------------------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------------------
def _format_phone(phone_str):
    if not phone_str:
        return ""
    p = "".join(filter(str.isdigit, str(phone_str)))
    if len(p) == 10:
        return f"+91{p}"
    elif len(p) > 10 and not phone_str.startswith('+'):
        return f"+{p}"
    return phone_str


def _log_simulated_dispatch(channel, recipient, content):
    """Persists simulated notification to AuditLog for verifiable traceability."""
    try:
        log = AuditLog(
            actor_id=None,
            entity_type='notification_dispatch',
            entity_id=0,
            action=f'{channel.lower()}_dispatched',
            new_status='simulated_success',
            notes=f"[{channel} to {recipient}] {content[:200]}"
        )
        db.session.add(log)
        db.session.commit()
    except Exception:
        pass
