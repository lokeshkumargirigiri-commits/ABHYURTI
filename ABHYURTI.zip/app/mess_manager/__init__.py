from flask import Blueprint

mess_manager_bp = Blueprint('mess_manager', __name__, url_prefix='/mess-manager')

from app.mess_manager import routes
