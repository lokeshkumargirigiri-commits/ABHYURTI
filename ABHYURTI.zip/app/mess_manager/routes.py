from datetime import datetime
from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from sqlalchemy import func
from app.extensions import db
from app.models import MessMenu, MessFeedback, Notice, Complaint
from app.utils.security import role_required, log_audit_action, create_notification
from app.mess_manager import mess_manager_bp

@mess_manager_bp.route('/')
@mess_manager_bp.route('/dashboard')
@login_required
@role_required('mess_manager', 'super_admin', 'admin')
def dashboard():
    # Days of week menus
    menus = MessMenu.query.order_by(MessMenu.day_of_week.asc()).all()

    # Feedback overview
    feedbacks = MessFeedback.query.order_by(MessFeedback.created_at.desc()).limit(20).all()
    total_feedbacks = MessFeedback.query.count()
    avg_rating = db.session.query(func.avg(MessFeedback.rating)).scalar() or 0.0

    # Categorized breakdown
    cat_counts = {
        'food_quality': MessFeedback.query.filter_by(category='food_quality').count(),
        'cleanliness': MessFeedback.query.filter_by(category='cleanliness').count(),
        'portion_size': MessFeedback.query.filter_by(category='portion_size').count(),
        'staff_behavior': MessFeedback.query.filter_by(category='staff_behavior').count(),
        'punctuality': MessFeedback.query.filter_by(category='punctuality').count()
    }

    # Mess notices
    notices = Notice.query.filter(Notice.title.ilike('%mess%') | (Notice.created_by == current_user.id)).order_by(Notice.published_at.desc()).limit(5).all()

    return render_template(
        'mess_manager/dashboard.html',
        menus=menus,
        feedbacks=feedbacks,
        total_feedbacks=total_feedbacks,
        avg_rating=round(avg_rating, 1),
        cat_counts=cat_counts,
        notices=notices
    )


@mess_manager_bp.route('/menu/edit', methods=['GET', 'POST'])
@login_required
@role_required('mess_manager', 'super_admin', 'admin')
def edit_menu():
    if request.method == 'POST':
        day = request.form.get('day_of_week', 'Monday').strip()
        meal = request.form.get('meal_type', 'Lunch').strip()
        items = request.form.get('items_description', '').strip()
        diet_notes = request.form.get('special_diet_notes', '').strip()

        if not items:
            flash("Menu items description is required.", "danger")
            return redirect(url_for('mess_manager.edit_menu'))

        menu_item = MessMenu.query.filter_by(day_of_week=day, meal_type=meal).first()
        if menu_item:
            menu_item.items_description = items
            menu_item.special_diet_notes = diet_notes
            menu_item.updated_at = datetime.utcnow()
        else:
            menu_item = MessMenu(
                day_of_week=day,
                meal_type=meal,
                items_description=items,
                special_diet_notes=diet_notes,
                created_by=current_user.id
            )
            db.session.add(menu_item)

        db.session.commit()
        log_audit_action(current_user.id, 'mess_menu', menu_item.id, 'menu_updated', notes=f"Updated {day} {meal} menu")
        flash(f"{day} {meal} menu updated successfully!", "success")
        return redirect(url_for('mess_manager.dashboard'))

    days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    meals = ['Breakfast', 'Lunch', 'Snacks', 'Dinner']
    return render_template('mess_manager/menu_form.html', days=days, meals=meals)


@mess_manager_bp.route('/feedback/<int:id>/respond', methods=['POST'])
@login_required
@role_required('mess_manager', 'super_admin', 'admin')
def respond_feedback(id):
    fb = MessFeedback.query.get_or_404(id)
    response_notes = request.form.get('response_notes', '').strip()

    if not response_notes:
        flash("Response notes are required.", "danger")
        return redirect(url_for('mess_manager.dashboard'))

    fb.response_notes = response_notes
    fb.responded_by = current_user.id
    fb.status = 'action_taken'
    db.session.commit()

    log_audit_action(current_user.id, 'mess_feedback', fb.id, 'responded', notes=response_notes)
    create_notification(
        user_id=fb.student_id,
        title="Mess Feedback Response",
        message=f"Mess Manager responded to your {fb.category.replace('_', ' ')} feedback: {response_notes}",
        category='mess',
        link=url_for('student.mess_stub')
    )

    flash("Feedback response logged and student notified.", "success")
    return redirect(url_for('mess_manager.dashboard'))


@mess_manager_bp.route('/notices/new', methods=['GET', 'POST'])
@login_required
@role_required('mess_manager', 'super_admin', 'admin')
def notice_new():
    if request.method == 'POST':
        title = request.form.get('title', '').strip()
        body = request.form.get('body', '').strip()

        if not title or not body:
            flash("Title and content are required.", "danger")
            return render_template('mess_manager/notice_form.html')

        notice = Notice(
            title=f"[Mess Update] {title}",
            body=body,
            created_by=current_user.id,
            status='published'
        )
        db.session.add(notice)
        db.session.commit()

        log_audit_action(current_user.id, 'notice', notice.id, 'published', notes=f"Mess Notice published: {title}")
        flash("Mess notice published to students!", "success")
        return redirect(url_for('mess_manager.dashboard'))

    return render_template('mess_manager/notice_form.html')
