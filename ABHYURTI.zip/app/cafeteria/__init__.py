from flask import Blueprint

cafeteria_bp = Blueprint('cafeteria', __name__, url_prefix='/cafeteria')

from app.cafeteria import routes
