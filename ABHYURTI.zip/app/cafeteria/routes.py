import secrets
from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, abort, jsonify
from flask_login import login_required, current_user
from app.cafeteria import cafeteria_bp
from app.extensions import db
from app.models import CafeteriaItem, CafeteriaOrder, CafeteriaOrderItem, User
from app.utils.security import role_required, log_audit_action, create_notification


def seed_cafeteria_menu():
    """Ensure baseline cafeteria menu exists."""
    if CafeteriaItem.query.count() == 0:
        items = [
            # Meals
            ('Paneer Butter Masala Thali', 'meal', 110.0, True, 'Paneer curry, dal tadka, 3 butter rotis, jeera rice & gulab jamun.'),
            ('Special Veg Biryani Combo', 'meal', 90.0, True, 'Aromatic basmati biryani with spiced raita and mirchi ka salan.'),
            ('South Indian Masala Dosa', 'meal', 60.0, True, 'Crispy dosa with spiced potato filling, sambar and fresh coconut chutney.'),
            ('Chole Bhature Platter', 'meal', 80.0, False, 'Spicy Amritsari chole with 2 fluffy bhature and pickled onions.'),  # Out of stock demo
            # Snacks
            ('Cheese Grilled Sandwich', 'snack', 50.0, True, 'Triple-layer sandwich with cheddar cheese, vegetables & green chutney.'),
            ('Paneer Tikka Roll', 'snack', 65.0, True, 'Charcoal smoked paneer rolled in flaky paratha with mint mayo.'),
            ('Crispy Peri Peri Fries', 'snack', 55.0, True, 'Golden potato fries seasoned with peri-peri spice dust.'),
            ('Samosa Pav (2 Pcs)', 'snack', 30.0, False, 'Crispy potato samosas inside buttered pav with spicy garlic chutney.'), # Out of stock demo
            # Beverages
            ('Special Masala Cutting Chai', 'beverage', 15.0, True, 'Freshly brewed tea with crushed ginger and aromatic cardamom.'),
            ('Thick Cold Coffee with Scoop', 'beverage', 45.0, True, 'Chilled blended espresso topped with vanilla ice cream.'),
            ('Fresh Mint Lime Soda', 'beverage', 30.0, True, 'Refreshing sweet & salted lime soda with fresh mint leaves.'),
            # Desserts
            ('Warm Gulab Jamun (2 pcs)', 'dessert', 30.0, True, 'Traditional cottage cheese dumplings soaked in rose sugar syrup.'),
            ('Hot Chocolate Walnut Brownie', 'dessert', 55.0, True, 'Rich dark chocolate brownie served with chocolate fudge sauce.')
        ]
        for name, cat, price, avail, desc in items:
            db.session.add(CafeteriaItem(name=name, category=cat, price=price, is_available=avail, description=desc))
        db.session.commit()


@cafeteria_bp.route('/')
@cafeteria_bp.route('/dashboard')
@login_required
@role_required('cafeteria_staff', 'admin', 'super_admin')
def dashboard():
    seed_cafeteria_menu()
    items = CafeteriaItem.query.order_by(CafeteriaItem.category.asc(), CafeteriaItem.name.asc()).all()

    # Active orders pipeline
    active_orders = CafeteriaOrder.query.filter(
        CafeteriaOrder.status.in_(['placed', 'preparing', 'ready'])
    ).order_by(CafeteriaOrder.created_at.asc()).all()

    completed_orders = CafeteriaOrder.query.filter_by(
        status='delivered'
    ).order_by(CafeteriaOrder.updated_at.desc()).limit(15).all()

    return render_template('cafeteria/dashboard.html',
                           items=items,
                           active_orders=active_orders,
                           completed_orders=completed_orders)


@cafeteria_bp.route('/item/toggle/<int:id>', methods=['POST'])
@cafeteria_bp.route('/item/<int:id>/toggle-stock', methods=['POST'])
@login_required
@role_required('cafeteria_staff', 'admin', 'super_admin')
def toggle_availability(id):
    item = CafeteriaItem.query.get_or_404(id)
    item.is_available = not item.is_available
    db.session.commit()

    log_audit_action(current_user.id, 'cafeteria_item', item.id, 'toggle_availability',
                     notes=f"Toggled {item.name} availability to {item.is_available}")

    state_str = "Available" if item.is_available else "Not Available (Sold Out)"
    flash(f"'{item.name}' marked as {state_str}.", "info")
    return redirect(url_for('cafeteria.dashboard'))


@cafeteria_bp.route('/item/add', methods=['POST'])
@login_required
@role_required('cafeteria_staff', 'admin', 'super_admin')
def add_item():
    name = request.form.get('name', '').strip()
    category = request.form.get('category', 'meal').strip().lower()
    price = float(request.form.get('price', 0.0) or 0.0)
    description = request.form.get('description', '').strip()

    if not name or price <= 0:
        flash("Please provide a valid item name and price.", "danger")
        return redirect(url_for('cafeteria.dashboard'))

    item = CafeteriaItem(name=name, category=category, price=price, is_available=True, description=description)
    db.session.add(item)
    db.session.commit()

    log_audit_action(current_user.id, 'cafeteria_item', item.id, 'created', notes=f"Added {name} (Rs {price})")
    flash(f"New menu item '{name}' added successfully.", "success")
    return redirect(url_for('cafeteria.dashboard'))


@cafeteria_bp.route('/order/<int:id>/status', methods=['POST'])
@login_required
@role_required('cafeteria_staff', 'admin', 'super_admin')
def update_order_status(id):
    order = CafeteriaOrder.query.get_or_404(id)
    new_status = request.form.get('status', '').strip().lower()

    if new_status in ('preparing', 'ready', 'delivered', 'cancelled'):
        order.status = new_status
        db.session.commit()

        # Notify student
        msg_map = {
            'preparing': f"Your cafeteria order {order.order_token} is now being prepared in the kitchen.",
            'ready': f"🎉 Order {order.order_token} is READY for pickup at the cafeteria counter!",
            'delivered': f"Order {order.order_token} has been collected. Thank you for dining with us!",
            'cancelled': f"Order {order.order_token} was cancelled."
        }
        create_notification(
            order.student_id,
            f"Cafeteria Order: {new_status.title()}",
            msg_map.get(new_status, f"Order status updated to {new_status}"),
            link=url_for('cafeteria.student_order_detail', id=order.id)
        )

        flash(f"Order {order.order_token} status set to {new_status.title()}.", "success")
    return redirect(url_for('cafeteria.dashboard'))


# ============================================================================
# STUDENT-FACING CAFETERIA ROUTES
# ============================================================================

@cafeteria_bp.route('/menu')
@login_required
def student_menu():
    seed_cafeteria_menu()
    available_items = CafeteriaItem.query.filter_by(is_available=True).order_by(CafeteriaItem.name.asc()).all()
    unavailable_items = CafeteriaItem.query.filter_by(is_available=False).order_by(CafeteriaItem.name.asc()).all()

    # User active orders
    my_active_orders = CafeteriaOrder.query.filter(
        CafeteriaOrder.student_id == current_user.id,
        CafeteriaOrder.status.in_(['placed', 'preparing', 'ready'])
    ).order_by(CafeteriaOrder.created_at.desc()).all()

    # Group available items by category
    categories = {'meal': [], 'snack': [], 'beverage': [], 'dessert': []}
    for it in available_items:
        categories.setdefault(it.category, []).append(it)

    return render_template('cafeteria/student_menu.html',
                           categories=categories,
                           unavailable_items=unavailable_items,
                           my_active_orders=my_active_orders)


@cafeteria_bp.route('/student/order', methods=['POST'])
@cafeteria_bp.route('/order', methods=['POST'])
@login_required
def place_order():
    item_ids = request.form.getlist('item_id')
    quantities = request.form.getlist('quantity')
    payment_method = request.form.get('payment_method', 'mock_upi').strip()
    special_notes = request.form.get('special_instructions', '').strip()

    order_items_data = []
    total = 0.0

    if item_ids and quantities:
        for i_id, qty_str in zip(item_ids, quantities):
            try:
                qty = int(qty_str)
                if qty > 0:
                    item = CafeteriaItem.query.get(int(i_id))
                    if item and item.is_available:
                        order_items_data.append((item, qty))
                        total += (item.price * qty)
            except (ValueError, TypeError):
                continue
    else:
        for key, val in request.form.items():
            if key.startswith('qty_'):
                try:
                    i_id = int(key.split('_')[1])
                    qty = int(val)
                    if qty > 0:
                        item = CafeteriaItem.query.get(i_id)
                        if item and item.is_available:
                            order_items_data.append((item, qty))
                            total += (item.price * qty)
                except (ValueError, TypeError):
                    continue

    if not order_items_data:
        flash("Please select at least one available item to place an order.", "warning")
        return redirect(url_for('cafeteria.student_menu'))

    token = f"CAF-{secrets.randbelow(8999) + 1000}"

    order = CafeteriaOrder(
        order_token=token,
        student_id=current_user.id,
        total_amount=total,
        payment_status='paid',
        payment_method=payment_method,
        status='placed',
        special_instructions=special_notes if special_notes else None
    )
    db.session.add(order)
    db.session.flush()

    for item, qty in order_items_data:
        db.session.add(CafeteriaOrderItem(
            order_id=order.id,
            item_id=item.id,
            quantity=qty,
            unit_price=item.price
        ))

    db.session.commit()

    log_audit_action(current_user.id, 'cafeteria_order', order.id, 'placed',
                     notes=f"Order {token} placed for Rs {total:.2f}")

    create_notification(
        current_user.id,
        "Cafeteria Order Placed",
        f"Your order {token} (₹{total:,.2f}) has been placed. You will be notified when it is ready!",
        link=url_for('cafeteria.student_order_detail', id=order.id)
    )

    flash(f"Order #{token} placed successfully! Please check the tracker below.", "success")
    return redirect(url_for('cafeteria.student_order_detail', id=order.id))


@cafeteria_bp.route('/student/order/<int:id>')
@login_required
def student_order_detail(id):
    order = CafeteriaOrder.query.get_or_404(id)
    if order.student_id != current_user.id and not current_user.has_role('cafeteria_staff', 'admin', 'super_admin'):
        abort(403)

    return render_template('cafeteria/order_detail.html', order=order)
