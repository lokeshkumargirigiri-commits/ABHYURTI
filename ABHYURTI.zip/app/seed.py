import os
from datetime import datetime
from app.extensions import db
from app.models import Role, Permission
from app import create_app

def seed_database():
    app = create_app()
    with app.app_context():
        print("Rebuilding schema, system roles, and permissions...")
        db.create_all()

        now = datetime.utcnow()

        # =========================================================
        # 1. CREATE SYSTEM ROLES (IF NOT PRESENT)
        # =========================================================
        roles_data = [
            ('student', 'Student', 'Enrolled undergraduate or postgraduate student with campus privileges'),
            ('faculty', 'Faculty / Teacher', 'Teaching faculty managing course attendance, notices, and leave signoffs'),
            ('warden', 'Hostel Warden', 'Residential warden managing block complaints, room QR, and gate leaves'),
            ('mess_manager', 'Mess Manager', 'Catering manager scheduling menus and addressing student dining feedback'),
            ('maintenance', 'Maintenance Staff', 'Technical staff executing repair tickets, plumbing, and electrical works'),
            ('office_staff', 'Office / Admin Staff', 'Academic registrar processing bonafide certificates, NOC, and dues'),
            ('super_admin', 'Super Admin', 'Full administrative authority over users, approvals, roles, and audits'),
            ('hod', 'Head of Department', 'Academic head overseeing faculty, departmental exams, and assignments'),
            ('account_staff', 'Accounts & Fees Staff', 'Finance officer handling fee collections, concessions, and audit receipts'),
            ('exam_staff', 'Examination Staff', 'Exam controller managing hall tickets, fee clearances, and test schedules'),
            ('cafeteria_staff', 'Cafeteria Staff', 'Cafeteria manager handling live stock availability and order fulfillments'),
            ('cyber_cafe_staff', 'Cyber Cafe Staff', 'Computer center and Xerox staff handling scholarship applications and terminal slots'),
            ('librarian', 'Librarian', 'Library manager overseeing book inventory, issuance queues, and overdue fines'),
            ('event_coordinator', 'Event Coordinator', 'Campus activity coordinator handling cultural and tech event registrations'),
            ('sports_coordinator', 'Sports Coordinator', 'Athletics coordinator managing tournament matches and live scoreboard'),
            ('counselor', 'Student Wellbeing Counselor', 'Licensed mental health counselor monitoring wellbeing index and confidential notes'),
            ('caretaker', 'Hostel Caretaker', 'Hostel supervisor logging nightly roll-call attendance and health emergencies'),
            ('superintendent', 'Hostel Superintendent', 'Senior residential head conducting room reviews and authorizing student gate passes')
        ]

        roles_dict = {}
        for r_name, r_display, r_desc in roles_data:
            role_obj = Role.query.filter_by(name=r_name).first()
            if not role_obj:
                role_obj = Role(name=r_name, display_name=r_display, description=r_desc, is_system_role=True)
                db.session.add(role_obj)
            roles_dict[r_name] = role_obj
        db.session.commit()

        # =========================================================
        # 2. CREATE SYSTEM PERMISSIONS
        # =========================================================
        perms_data = [
            # Academic module
            ('attendance.view_own', 'View Personal Attendance', 'academic'),
            ('attendance.mark', 'Mark Subject Attendance', 'academic'),
            ('class.publish_updates', 'Publish Class Notices', 'academic'),
            ('leave.request', 'Apply for Class Leave', 'academic'),
            ('leave.approve', 'Approve Student Leaves', 'academic'),
            ('classes.view_assigned', 'View Assigned Class Students', 'academic'),

            # Hostel & Complaints module
            ('complaint.submit', 'Submit Hostel Issue', 'hostel'),
            ('complaint.view_own', 'Track Personal Complaints', 'hostel'),
            ('complaint.triage', 'Review Hostel Complaints', 'hostel'),
            ('complaint.assign', 'Assign to Maintenance', 'hostel'),
            ('hostel.manage_rooms', 'Manage Rooms & Inspection QR', 'hostel'),

            # Gate Pass module
            ('gatepass.request', 'Request Campus Gate Pass', 'gate_pass'),
            ('gatepass.approve', 'Approve/Reject Gate Passes', 'gate_pass'),
            ('gatepass.mark_return', 'Log Gate Entry & Return', 'gate_pass'),

            # Maintenance module
            ('ticket.view_assigned', 'View Assigned Repair Tickets', 'maintenance'),
            ('ticket.resolve', 'Update Work Order & Resolve', 'maintenance'),

            # Mess module
            ('mess.view_menu', 'View Daily Mess Menu', 'mess'),
            ('mess.manage_menu', 'Create & Edit Menus', 'mess'),
            ('mess.submit_feedback', 'Submit Meal Feedback', 'mess'),
            ('mess.respond_feedback', 'Respond to Mess Feedback', 'mess'),
            ('mess.analytics', 'View Dining Feedback Analytics', 'mess'),

            # Documents & Dues module
            ('document.request', 'Request Certificates & NOC', 'documents'),
            ('document.process', 'Approve & Issue Certificates', 'documents'),
            ('dues.view_own', 'View Fee & Clearance Dues', 'documents'),
            ('dues.manage', 'Review Institutional Dues', 'documents'),

            # Notices module
            ('notice.view', 'View Targeted Notices', 'notices'),
            ('notice.publish_campus', 'Publish Campus-Wide Notice', 'notices'),

            # Administrative module
            ('staff.approve', 'Review & Approve Staff Users', 'admin'),
            ('user.manage', 'Manage Users & Credentials', 'admin'),
            ('permission.configure', 'Configure Role Permissions', 'admin'),
            ('audit.view', 'Inspect Immutable Audit Trail', 'admin')
        ]

        perms_dict = {}
        for p_code, p_name, p_mod in perms_data:
            p_obj = Permission.query.filter_by(code=p_code).first()
            if not p_obj:
                p_obj = Permission(code=p_code, name=p_name, module=p_mod)
                db.session.add(p_obj)
            perms_dict[p_code] = p_obj
        db.session.commit()

        # Map Permissions to Roles
        role_perm_mapping = {
            'student': [
                'attendance.view_own', 'leave.request', 'complaint.submit', 'complaint.view_own',
                'gatepass.request', 'mess.view_menu', 'mess.submit_feedback', 'document.request',
                'dues.view_own', 'notice.view'
            ],
            'faculty': [
                'attendance.mark', 'class.publish_updates', 'leave.approve', 'classes.view_assigned',
                'notice.view'
            ],
            'warden': [
                'complaint.triage', 'complaint.assign', 'hostel.manage_rooms', 'gatepass.approve',
                'gatepass.mark_return', 'notice.view'
            ],
            'mess_manager': [
                'mess.view_menu', 'mess.manage_menu', 'mess.respond_feedback', 'mess.analytics',
                'notice.view'
            ],
            'maintenance': [
                'ticket.view_assigned', 'ticket.resolve', 'notice.view'
            ],
            'office_staff': [
                'document.process', 'dues.manage', 'notice.view'
            ],
            'super_admin': list(perms_dict.keys())
        }

        for r_name, p_codes in role_perm_mapping.items():
            r_obj = roles_dict[r_name]
            existing_perm_codes = {p.code for p in r_obj.permissions}
            for p_code in p_codes:
                if p_code in perms_dict and p_code not in existing_perm_codes:
                    r_obj.permissions.append(perms_dict[p_code])
        db.session.commit()

        # =========================================================
        # 3. SEED PRE-APPROVED EMPLOYEE CODES
        # =========================================================
        from app.models import PreApprovedEmployeeCode
        sample_codes = [
            ('EMP-ADMIN-001', 'super_admin', 'Dean / Super Admin Office', 'Central Administration'),
            ('EMP-ADMIN-002', 'admin', 'Administrative Officer', 'Administration'),
            ('EMP-FACULTY-101', 'faculty', 'Prof. Computer Science', 'CSE'),
            ('EMP-FACULTY-102', 'faculty', 'Prof. Electrical Eng', 'EE'),
            ('EMP-FACULTY-103', 'faculty', 'Prof. Mechanical Eng', 'ME'),
            ('EMP-WARDEN-201', 'warden', 'Chief Hostel Warden', 'Hostel Administration'),
            ('EMP-WARDEN-202', 'warden', 'Hostel B Superintendent', 'Hostel Administration'),
            ('EMP-MESS-301', 'mess_manager', 'Chief Catering Supervisor', 'Mess & Catering'),
            ('EMP-MAINT-401', 'maintenance', 'Lead Electrician & Repairs', 'Estate & Maintenance'),
            ('EMP-OFFICE-501', 'office_staff', 'Registrar Academic Officer', 'Academic Section'),
            ('EMP-HOD-601', 'hod', 'Head of Dept CSE', 'Computer Science'),
            ('EMP-ACC-701', 'account_staff', 'Accounts Senior Officer', 'Finance & Accounts'),
            ('EMP-EXAM-801', 'exam_staff', 'Controller of Examinations', 'Examination Cell'),
            ('EMP-CAFE-901', 'cafeteria_staff', 'Campus Cafeteria Lead', 'Hospitality & Dining'),
            ('EMP-CYBER-101', 'cyber_cafe_staff', 'Cyber Cafe & Xerox Head', 'Student IT Services'),
            ('EMP-LIB-111', 'librarian', 'Chief Librarian', 'Central Library'),
            ('EMP-EVENT-121', 'event_coordinator', 'Student Activity Head', 'Cultural & Events'),
            ('EMP-SPORT-131', 'sports_coordinator', 'Physical Director', 'Sports & Games'),
            ('EMP-COUNS-141', 'counselor', 'Senior Student Counselor', 'Student Wellbeing'),
            ('EMP-CARE-151', 'caretaker', 'Hostel Caretaker', 'Hostel Operations'),
            ('EMP-SUPT-161', 'superintendent', 'Hostel Superintendent', 'Hostel Operations'),
        ]
        for e_code, e_role, e_name, e_dept in sample_codes:
            if not PreApprovedEmployeeCode.query.filter_by(employee_code=e_code).first():
                db.session.add(PreApprovedEmployeeCode(
                    employee_code=e_code,
                    role=e_role,
                    name=e_name,
                    department=e_dept,
                    status='unused'
                ))
        db.session.commit()

        print("SUCCESS: 7 system roles, 31 permissions, and pre-approved employee codes configured.")
        print("Zero demo accounts seeded. Use 'flask create-superadmin' to configure the initial administrator.")

if __name__ == '__main__':
    seed_database()
