from datetime import datetime
from flask import render_template, request, redirect, url_for, flash, abort, jsonify
from flask_login import login_required, current_user
from app.communities import communities_bp
from app.extensions import db
from app.models import Community, CommunityMembership, CommunityPost, User
from app.utils.security import log_audit_action, create_notification


def ensure_system_communities():
    """Ensure standard base communities exist."""
    default_data = [
        ('CSE Department Hub', 'cse-hub', 'department', 'Official academic hub for Computer Science & Engineering students and faculty.', 'bi-code-slash', '#2563eb'),
        ('ECE Department Hub', 'ece-hub', 'department', 'Academic exchange and lab discussions for Electronics & Communication.', 'bi-cpu', '#0284c7'),
        ('Mechanical Eng Hub', 'me-hub', 'department', 'Workshop notices, design challenges, and department discussions.', 'bi-gear-wide-connected', '#d97706'),
        ('Batch of 2024 Hub', 'batch-2024', 'batch', 'Class updates, placement discussions, and student coordination.', 'bi-mortarboard', '#7c3aed'),
        ('Aryabhata Hostel Community', 'aryabhata-hostel', 'hostel', 'Residential life, maintenance discussions, and floor coordination.', 'bi-building', '#059669'),
        ('Raman Hostel Community', 'raman-hostel', 'hostel', 'Block announcements, sports events, and room-level discussions.', 'bi-houses', '#0d9488'),
        ('Day Scholars Hub', 'day-scholars', 'day_scholar', 'Transport routes, bus schedules, and commuting student life.', 'bi-bus-front', '#ea580c'),
        ('Campus Coding Club', 'coding-club', 'interest_club', 'Hackathons, algorithmic puzzles, open-source projects, and dev workshops.', 'bi-terminal', '#10b981'),
        ('Robotics & AI Society', 'robotics-ai', 'interest_club', 'Hardware builds, autonomous bot competitions, and ML research.', 'bi-robot', '#6366f1'),
        ('Literary & Debate Club', 'literary-club', 'interest_club', 'MUN, parliamentary debate, creative writing, and campus magazine.', 'bi-book-half', '#db2777'),
        ('Campus Sports Union', 'sports-union', 'interest_club', 'Inter-department leagues, practice sessions, and sports updates.', 'bi-trophy', '#e11d48'),
        ('Faculty Central Forum', 'faculty-forum', 'department', 'Inter-departmental faculty teaching discussions and research initiatives.', 'bi-person-workspace', '#4f46e5')
    ]
    for name, slug, c_type, desc, icon, color in default_data:
        if not Community.query.filter_by(slug=slug).first():
            c = Community(name=name, slug=slug, type=c_type, description=desc, avatar_icon=icon, banner_color=color)
            db.session.add(c)
    db.session.commit()


def auto_enroll_user(user):
    """Automatically enroll user into their department, batch, hostel, and role groups."""
    if not user:
        return
    ensure_system_communities()

    # Map user branch
    branch_map = {'CSE': 'cse-hub', 'ECE': 'ece-hub', 'ME': 'me-hub'}
    slugs_to_join = []
    if user.branch and user.branch in branch_map:
        slugs_to_join.append(branch_map[user.branch])
    
    # Map user hostel
    if user.hostel:
        h_lower = user.hostel.lower()
        if 'arya' in h_lower:
            slugs_to_join.append('aryabhata-hostel')
        elif 'raman' in h_lower:
            slugs_to_join.append('raman-hostel')
        elif 'day' in h_lower:
            slugs_to_join.append('day-scholars')
    else:
        slugs_to_join.append('day-scholars')

    if user.role == 'faculty':
        slugs_to_join.append('faculty-forum')
    else:
        slugs_to_join.append('batch-2024')

    for slug in slugs_to_join:
        comm = Community.query.filter_by(slug=slug).first()
        if comm:
            exists = CommunityMembership.query.filter_by(community_id=comm.id, user_id=user.id).first()
            if not exists:
                db.session.add(CommunityMembership(community_id=comm.id, user_id=user.id, role='member'))
    db.session.commit()


@communities_bp.route('/')
@login_required
def index():
    auto_enroll_user(current_user)
    my_memberships = CommunityMembership.query.filter_by(user_id=current_user.id).all()
    my_community_ids = {m.community_id for m in my_memberships}
    my_communities = [m.community for m in my_memberships]

    # Discoverable open communities
    all_communities = Community.query.order_by(Community.name.asc()).all()
    discoverable = [c for c in all_communities if c.id not in my_community_ids]

    # Recent posts across user's communities
    recent_posts = CommunityPost.query.filter(
        CommunityPost.community_id.in_(my_community_ids)
    ).order_by(CommunityPost.created_at.desc()).limit(15).all() if my_community_ids else []

    return render_template('communities/index.html',
                           my_communities=my_communities,
                           discoverable=discoverable,
                           recent_posts=recent_posts)


def get_community_or_404(identifier):
    comm = Community.query.filter_by(slug=str(identifier)).first()
    if not comm and str(identifier).isdigit():
        comm = Community.query.get(int(identifier))
    if not comm:
        abort(404)
    return comm


@communities_bp.route('/<slug>')
@login_required
def detail(slug):
    comm = get_community_or_404(slug)
    membership = CommunityMembership.query.filter_by(community_id=comm.id, user_id=current_user.id).first()
    posts = CommunityPost.query.filter_by(community_id=comm.id).order_by(CommunityPost.is_pinned.desc(), CommunityPost.created_at.desc()).all()
    member_count = CommunityMembership.query.filter_by(community_id=comm.id).count()

    return render_template('communities/detail.html',
                           community=comm,
                           membership=membership,
                           posts=posts,
                           member_count=member_count)


@communities_bp.route('/<slug>/join', methods=['POST'])
@login_required
def join(slug):
    comm = get_community_or_404(slug)
    existing = CommunityMembership.query.filter_by(community_id=comm.id, user_id=current_user.id).first()
    if not existing:
        db.session.add(CommunityMembership(community_id=comm.id, user_id=current_user.id, role='member'))
        db.session.commit()
        flash(f"You have joined {comm.name}!", "success")
    return redirect(url_for('communities.detail', slug=comm.slug))


@communities_bp.route('/<slug>/leave', methods=['POST'])
@login_required
def leave(slug):
    comm = get_community_or_404(slug)
    mem = CommunityMembership.query.filter_by(community_id=comm.id, user_id=current_user.id).first()
    if mem:
        db.session.delete(mem)
        db.session.commit()
        flash(f"You have left {comm.name}.", "info")
    return redirect(url_for('communities.index'))


@communities_bp.route('/<slug>/post', methods=['POST'])
@login_required
def create_post(slug):
    comm = get_community_or_404(slug)
    mem = CommunityMembership.query.filter_by(community_id=comm.id, user_id=current_user.id).first()
    if not mem and not current_user.has_role('admin', 'super_admin'):
        flash("You must be a member of this community to post.", "warning")
        return redirect(url_for('communities.detail', slug=comm.slug))

    title = request.form.get('title', '').strip()
    content = request.form.get('content', '').strip()
    post_type = request.form.get('post_type', 'general').strip()
    attachment_url = request.form.get('attachment_url', '').strip()

    if not content:
        flash("Post content cannot be empty.", "danger")
        return redirect(url_for('communities.detail', slug=slug))

    # Only faculty/admin can post official announcements
    if post_type == 'announcement' and not (current_user.has_role('faculty', 'admin', 'super_admin', 'hod') or (mem and mem.role in ('moderator', 'admin'))):
        post_type = 'general'

    post = CommunityPost(
        community_id=comm.id,
        author_id=current_user.id,
        post_type=post_type,
        title=title if title else None,
        content=content,
        attachment_url=attachment_url if attachment_url else None
    )
    db.session.add(post)
    db.session.commit()
    flash("Post published successfully!", "success")
    return redirect(url_for('communities.detail', slug=slug))


@communities_bp.route('/<slug>/pin/<int:post_id>', methods=['POST'])
@login_required
def toggle_pin(slug, post_id):
    comm = Community.query.filter_by(slug=slug).first_or_404()
    post = CommunityPost.query.filter_by(id=post_id, community_id=comm.id).first_or_404()
    mem = CommunityMembership.query.filter_by(community_id=comm.id, user_id=current_user.id).first()

    if not (current_user.has_role('faculty', 'admin', 'super_admin') or (mem and mem.role in ('moderator', 'admin'))):
        abort(403)

    post.is_pinned = not post.is_pinned
    db.session.commit()
    flash(f"Post {'pinned to top' if post.is_pinned else 'unpinned'}.", "info")
    return redirect(url_for('communities.detail', slug=slug))


@communities_bp.route('/create', methods=['POST'])
@login_required
def create_club():
    name = request.form.get('name', '').strip()
    description = request.form.get('description', '').strip()
    c_type = request.form.get('type', 'interest_club').strip()
    avatar_icon = request.form.get('avatar_icon', 'bi-people-fill').strip()
    banner_color = request.form.get('banner_color', '#3b82f6').strip()

    if not name:
        flash("Community name is required.", "danger")
        return redirect(url_for('communities.index'))

    # Generate slug
    slug = name.lower().replace(' ', '-').replace('&', 'and')
    slug = "".join([c for c in slug if c.isalnum() or c == '-'])
    if Community.query.filter_by(slug=slug).first():
        slug = f"{slug}-{int(datetime.utcnow().timestamp())}"

    comm = Community(
        name=name,
        slug=slug,
        type=c_type,
        description=description,
        avatar_icon=avatar_icon,
        banner_color=banner_color,
        created_by_id=current_user.id
    )
    db.session.add(comm)
    db.session.flush()

    # Creator becomes admin of this community
    db.session.add(CommunityMembership(community_id=comm.id, user_id=current_user.id, role='admin'))
    db.session.commit()
    flash(f"Community '{name}' created successfully!", "success")
    return redirect(url_for('communities.detail', slug=slug))
