from flask import Blueprint

communities_bp = Blueprint('communities', __name__, url_prefix='/communities')

from app.communities import routes
