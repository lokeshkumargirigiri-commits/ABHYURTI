from datetime import datetime, date
from flask import render_template, request, redirect, url_for, flash, abort, jsonify
from flask_login import login_required, current_user
from app.cyber_cafe import cyber_cafe_bp
from app.extensions import db
from app.models import CyberCafeRequest, User
from app.utils.security import role_required, log_audit_action, create_notification

MAX_DAILY_TERMINAL_SLOTS = 20


@cyber_cafe_bp.route('/')
@cyber_cafe_bp.route('/dashboard')
@login_required
@role_required('cyber_cafe_staff', 'admin', 'super_admin')
def dashboard():
    today = date.today()
    selected_tab = request.args.get('tab', 'all').strip().lower()

    # Slot count for today
    today_slots_booked = CyberCafeRequest.query.filter(
        CyberCafeRequest.request_type == 'terminal_slot',
        CyberCafeRequest.slot_date == today,
        CyberCafeRequest.status.notin_(['cancelled', 'rejected'])
    ).count()

    query = CyberCafeRequest.query

    if selected_tab == 'scholarship':
        query = query.filter_by(request_type='scholarship')
    elif selected_tab == 'terminal_slot':
        query = query.filter_by(request_type='terminal_slot')
    elif selected_tab == 'print_xerox':
        query = query.filter_by(request_type='print_xerox')

    # Order by priority asc (1 first), then created_at asc
    requests_list = query.order_by(CyberCafeRequest.priority.asc(), CyberCafeRequest.created_at.desc()).all()

    # Priority 1 (Scholarship) count
    p1_count = CyberCafeRequest.query.filter_by(request_type='scholarship', status='pending').count()
    p2_count = CyberCafeRequest.query.filter_by(request_type='terminal_slot', status='pending').count()
    p3_count = CyberCafeRequest.query.filter_by(request_type='print_xerox', status='pending').count()

    return render_template('cyber_cafe/dashboard.html',
                           requests_list=requests_list,
                           today_slots_booked=today_slots_booked,
                           max_slots=MAX_DAILY_TERMINAL_SLOTS,
                           selected_tab=selected_tab,
                           p1_count=p1_count,
                           p2_count=p2_count,
                           p3_count=p3_count)


@cyber_cafe_bp.route('/request/<int:id>/status', methods=['POST'])
@login_required
@role_required('cyber_cafe_staff', 'admin', 'super_admin')
def update_status(id):
    req = CyberCafeRequest.query.get_or_404(id)
    new_status = request.form.get('status', '').strip().lower()
    staff_notes = request.form.get('staff_notes', '').strip()

    if new_status in ('in_progress', 'completed', 'rejected'):
        req.status = new_status
        if staff_notes:
            req.staff_notes = staff_notes
        db.session.commit()

        log_audit_action(current_user.id, 'cyber_cafe_request', req.id, 'status_update',
                         notes=f"Updated status to {new_status}")

        create_notification(
            req.user_id,
            f"Cyber Cafe: {req.title}",
            f"Your request '{req.title}' status is now {new_status.title()}. {staff_notes}",
            link=url_for('cyber_cafe.student_portal')
        )
        flash(f"Request #{req.id} marked as {new_status.title()}.", "success")
    return redirect(url_for('cyber_cafe.dashboard'))


@cyber_cafe_bp.route('/request/<int:id>/reschedule', methods=['POST'])
@login_required
@role_required('cyber_cafe_staff', 'admin', 'super_admin')
def reschedule_slot(id):
    req = CyberCafeRequest.query.get_or_404(id)
    new_date_str = request.form.get('slot_date', '').strip()
    new_time = request.form.get('slot_time', '').strip()
    reason = request.form.get('reason', 'Rescheduled by staff').strip()

    if new_date_str and new_time:
        try:
            req.slot_date = datetime.strptime(new_date_str, '%Y-%m-%d').date()
            req.slot_time = new_time
            req.status = 'rescheduled'
            req.staff_notes = f"Rescheduled: {reason}"
            db.session.commit()

            create_notification(
                req.user_id,
                "Cyber Cafe Slot Rescheduled",
                f"Your terminal slot was rescheduled to {new_date_str} at {new_time}. Contact: {req.contact_phone or 'Cyber Cafe Counter'}",
                link=url_for('cyber_cafe.student_portal')
            )
            flash("Slot successfully rescheduled and student notified.", "success")
        except ValueError:
            flash("Invalid date format.", "danger")
    return redirect(url_for('cyber_cafe.dashboard'))


# ============================================================================
# STUDENT / USER FACING CYBER CAFE PORTAL
# ============================================================================

@cyber_cafe_bp.route('/portal')
@login_required
def student_portal():
    today = date.today()
    today_slots_booked = CyberCafeRequest.query.filter(
        CyberCafeRequest.request_type == 'terminal_slot',
        CyberCafeRequest.slot_date == today,
        CyberCafeRequest.status.notin_(['cancelled', 'rejected'])
    ).count()

    slots_remaining = max(0, MAX_DAILY_TERMINAL_SLOTS - today_slots_booked)

    my_requests = CyberCafeRequest.query.filter_by(
        user_id=current_user.id
    ).order_by(CyberCafeRequest.created_at.desc()).all()

    return render_template('cyber_cafe/student_portal.html',
                           today_slots_booked=today_slots_booked,
                           slots_remaining=slots_remaining,
                           max_slots=MAX_DAILY_TERMINAL_SLOTS,
                           my_requests=my_requests)


@cyber_cafe_bp.route('/submit/scholarship', methods=['POST'])
@login_required
def submit_scholarship():
    title = request.form.get('title', '').strip()
    scheme_name = request.form.get('scheme_name', '').strip()
    description = request.form.get('description', '').strip()
    phone = request.form.get('contact_phone', current_user.phone or '').strip()
    doc_path = request.form.get('document_path', '').strip()

    if not title or not scheme_name:
        flash("Please provide application title and scholarship scheme.", "danger")
        return redirect(url_for('cyber_cafe.student_portal'))

    req = CyberCafeRequest(
        user_id=current_user.id,
        request_type='scholarship',
        title=f"Scholarship: {scheme_name} - {title}",
        description=description,
        priority=1,  # Highest priority
        contact_phone=phone,
        document_path=doc_path if doc_path else None,
        status='pending'
    )
    db.session.add(req)
    db.session.commit()

    log_audit_action(current_user.id, 'cyber_cafe_request', req.id, 'created_scholarship',
                     notes=f"Submitted P1 scholarship application for {scheme_name}")

    flash("Priority 1 Scholarship Assistance request registered successfully!", "success")
    return redirect(url_for('cyber_cafe.student_portal'))


@cyber_cafe_bp.route('/submit/slot', methods=['POST'])
@cyber_cafe_bp.route('/book-slot', methods=['POST'])
@login_required
def book_slot():
    date_str = (request.form.get('slot_date') or request.form.get('booking_date') or '').strip()
    time_slot = (request.form.get('slot_time') or request.form.get('time_slot') or '11:00 AM - 12:00 PM').strip()
    purpose = request.form.get('purpose', '').strip()
    phone = request.form.get('contact_phone', current_user.phone or '').strip()

    if not date_str:
        flash("Please pick a slot date.", "danger")
        return redirect(url_for('cyber_cafe.student_portal'))

    try:
        s_date = datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        flash("Invalid date format.", "danger")
        return redirect(url_for('cyber_cafe.student_portal'))

    # Check 20 slots limit for that day
    current_count = CyberCafeRequest.query.filter(
        CyberCafeRequest.request_type == 'terminal_slot',
        CyberCafeRequest.slot_date == s_date,
        CyberCafeRequest.status.notin_(['cancelled', 'rejected'])
    ).count()

    if current_count >= MAX_DAILY_TERMINAL_SLOTS:
        flash(f"Daily terminal slot limit reached ({MAX_DAILY_TERMINAL_SLOTS}/20) for {date_str}. Please choose another date.", "warning")
        return redirect(url_for('cyber_cafe.student_portal'))

    req = CyberCafeRequest(
        user_id=current_user.id,
        request_type='terminal_slot',
        title=f"Terminal PC Booking ({time_slot})",
        description=purpose or "Academic browsing / document portal access",
        priority=2,
        slot_date=s_date,
        slot_time=time_slot,
        contact_phone=phone,
        status='scheduled'
    )
    db.session.add(req)
    db.session.commit()

    flash(f"Terminal slot successfully booked for {date_str} at {time_slot}!", "success")
    return redirect(url_for('cyber_cafe.student_portal'))


@cyber_cafe_bp.route('/submit/print', methods=['POST'])
@login_required
def submit_print():
    title = request.form.get('title', '').strip()
    pages = int(request.form.get('pages', 1) or 1)
    is_color = request.form.get('is_color') == 'yes'
    notes = request.form.get('notes', '').strip()
    doc_path = request.form.get('document_path', '').strip()

    if not title:
        flash("Document title is required.", "danger")
        return redirect(url_for('cyber_cafe.student_portal'))

    req = CyberCafeRequest(
        user_id=current_user.id,
        request_type='print_xerox',
        title=f"Print Job: {title}",
        description=notes,
        priority=3,
        pages=pages,
        is_color=is_color,
        document_path=doc_path if doc_path else None,
        status='pending'
    )
    db.session.add(req)
    db.session.commit()

    flash(f"Printing request for {pages} page(s) submitted to Xerox counter queue.", "success")
    return redirect(url_for('cyber_cafe.student_portal'))
