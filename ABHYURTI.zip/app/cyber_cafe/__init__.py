from flask import Blueprint

cyber_cafe_bp = Blueprint('cyber_cafe', __name__, url_prefix='/cyber-cafe')

from app.cyber_cafe import routes
