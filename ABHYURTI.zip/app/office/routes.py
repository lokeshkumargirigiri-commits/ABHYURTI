from datetime import datetime
from flask import render_template, redirect, url_for, flash, request, abort
from flask_login import login_required, current_user
from app.extensions import db
from app.models import DocumentRequest, User, StudentProfile, AuditLog
from app.utils.security import role_required, log_audit_action, create_notification
from app.office import office_bp

@office_bp.route('/')
@office_bp.route('/dashboard')
@login_required
@role_required('office_staff', 'super_admin', 'admin')
def dashboard():
    status_filter = request.args.get('status', 'all')
    type_filter = request.args.get('type', 'all')

    query = DocumentRequest.query
    if status_filter != 'all':
        query = query.filter_by(status=status_filter)
    if type_filter != 'all':
        query = query.filter_by(document_type=type_filter)

    requests_list = query.order_by(DocumentRequest.created_at.desc()).all()

    # Metrics
    pending_count = DocumentRequest.query.filter_by(status='submitted').count()
    under_review_count = DocumentRequest.query.filter_by(status='under_review').count()
    completed_count = DocumentRequest.query.filter_by(status='completed').count()

    # Students with fee dues
    students_with_dues = StudentProfile.query.filter(StudentProfile.fee_dues > 0).all()

    # Audit logs for documents processed
    recent_office_audits = AuditLog.query.filter_by(entity_type='document_request').order_by(AuditLog.created_at.desc()).limit(10).all()

    return render_template(
        'office/dashboard.html',
        requests_list=requests_list,
        pending_count=pending_count,
        under_review_count=under_review_count,
        completed_count=completed_count,
        students_with_dues=students_with_dues,
        recent_office_audits=recent_office_audits,
        current_status=status_filter,
        current_type=type_filter
    )


@office_bp.route('/requests/<int:id>/process', methods=['POST'])
@login_required
@role_required('office_staff', 'super_admin', 'admin')
def process_request(id):
    doc_req = DocumentRequest.query.get_or_404(id)
    action = request.form.get('action')  # 'approve', 'reject', 'complete', 'review'
    remarks = request.form.get('remarks', '').strip()

    old_status = doc_req.status
    doc_req.processed_by = current_user.id
    doc_req.updated_at = datetime.utcnow()

    if action == 'approve':
        doc_req.status = 'approved'
        doc_req.remarks = remarks or "Document request approved. Certificate being generated."
        msg = f"Your request for {doc_req.document_type.replace('_', ' ').title()} was approved."
    elif action == 'complete':
        doc_req.status = 'completed'
        doc_req.remarks = remarks or "Certificate signed, stamped, and ready for counter pickup."
        msg = f"Your {doc_req.document_type.replace('_', ' ').title()} is ready for counter pickup at Academic Office."
    elif action == 'reject':
        if not remarks:
            flash("Rejection reason remarks are required.", "danger")
            return redirect(url_for('office.dashboard'))
        doc_req.status = 'rejected'
        doc_req.remarks = remarks
        msg = f"Your document request was rejected. Reason: {remarks}"
    elif action == 'review':
        doc_req.status = 'under_review'
        doc_req.remarks = remarks or "Application under administrative review."
        msg = f"Your document request is now under verification by the office staff."

    db.session.commit()

    log_audit_action(
        actor_id=current_user.id,
        entity_type='document_request',
        entity_id=doc_req.id,
        action=f"status_to_{doc_req.status}",
        old_status=old_status,
        new_status=doc_req.status,
        notes=f"Processed by office staff {current_user.name}. Remarks: {remarks}"
    )

    create_notification(
        user_id=doc_req.student_id,
        title=f"Document Request Update ({doc_req.document_type.title()})",
        message=msg,
        category='document',
        link=url_for('student.certificates_stub')
    )

    flash(f"Document request #{doc_req.id} marked as {doc_req.status.replace('_', ' ').upper()}.", "success")
    return redirect(url_for('office.dashboard'))
